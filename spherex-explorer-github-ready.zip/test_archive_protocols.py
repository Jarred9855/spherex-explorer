import unittest
import data_access as archive

class ArchiveProtocols(unittest.TestCase):
    def test_semantic_names_override_numbered_ids(self):
        content=b'''<?xml version="1.0"?><VOTABLE version="1.3" xmlns="http://www.ivoa.net/xml/VOTable/v1.3"><RESOURCE type="results"><INFO name="QUERY_STATUS" value="OK"/><TABLE>
<FIELD ID="f1" name="obs_id" datatype="char" arraysize="*"/><FIELD ID="f2" name="t_min" datatype="double"/><FIELD ID="f3" name="access_url" datatype="char" arraysize="*"/><FIELD ID="f4" name="energy_bandpassname" datatype="char" arraysize="*"/><FIELD ID="f5" name="obs_collection" datatype="char" arraysize="*"/>
<DATA><TABLEDATA><TR><TD>test_exposure</TD><TD>61000</TD><TD>https://irsa.ipac.caltech.edu/ibe/data/spherex/dr1/example.fits</TD><TD>SPHEREx-D1</TD><TD>spherex_dr1</TD></TR></TABLEDATA></DATA></TABLE></RESOURCE></VOTABLE>'''
        result=archive.sia_dataset_from_votable(content,archive.Region(10,20))
        self.assertEqual(len(result['records']),1)
        self.assertEqual(result['records'][0]['mjd'],61000)
        self.assertFalse(result['result_truncated'])

    def test_unmapped_nonempty_table_is_not_empty_sky(self):
        from astropy.table import Table
        with self.assertRaises(ValueError):archive.dataset_from_table(Table({'wrong_column':[1]}),archive.Region(10,20))

if __name__=='__main__':unittest.main()
