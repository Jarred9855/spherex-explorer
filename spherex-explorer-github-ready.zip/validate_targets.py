"""Real benchmark validation; coadded contexts never count as time epochs."""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse
import io
import json
import math
import os

import numpy as np
import requests
from astropy.io import fits
from astropy.table import Table
from astropy.coordinates import SkyCoord,ICRS
from astropy.wcs import WCS
from astropy_healpix import HEALPix
import astropy.units as u

import data_access as archive
import targets


class HTTPRangeFile(io.RawIOBase):
    """Small block cache for public uncompressed FITS sections, not full cubes."""
    def __init__(self,url,block_size=262144):
        super().__init__()
        self.url=url;self.name=url;self.mode="rb";self.position=0
        self.block_size=block_size;self.blocks={};self.requests=0;self.downloaded_bytes=0
        self.session=requests.Session()
        response=self.session.head(url,timeout=(10,40))
        response.raise_for_status()
        self.length=int(response.headers["Content-Length"])
    def readable(self):return True
    def seekable(self):return True
    def tell(self):return self.position
    def seek(self,offset,whence=0):
        position=offset if whence==0 else self.position+offset if whence==1 else self.length+offset
        if position<0:raise ValueError("Negative file offset")
        self.position=int(position);return self.position
    def _block(self,index):
        if index not in self.blocks:
            first=index*self.block_size;last=min(first+self.block_size,self.length)-1
            with self.session.get(self.url,headers={"Range":f"bytes={first}-{last}"},stream=True,timeout=(10,60)) as response:
                response.raise_for_status()
                if response.status_code!=206:raise OSError("The server did not honor a byte-range request; refusing a full cube download.")
                if not response.headers.get("Content-Range","").startswith(f"bytes {first}-"):
                    raise OSError("The server returned a different byte range.")
                data=b"".join(response.iter_content(65536))
            if len(data)!=last-first+1:raise OSError("Incomplete FITS byte range")
            self.blocks[index]=data;self.requests+=1;self.downloaded_bytes+=len(data)
        return self.blocks[index]
    def read(self,size=-1):
        if size is None or size<0:size=self.length-self.position
        size=min(int(size),max(0,self.length-self.position))
        if size>16*1024*1024:raise OSError("Use lazy FITS sections instead of loading the full 300MB cube.")
        parts=[];remaining=size
        while remaining:
            index=self.position//self.block_size;offset=self.position%self.block_size
            block=self._block(index);take=min(remaining,len(block)-offset)
            if take<=0:break
            parts.append(block[offset:offset+take]);self.position+=take;remaining-=take
        return b"".join(parts)
    def readinto(self,buffer):
        data=self.read(len(buffer));buffer[:len(data)]=data;return len(data)
    def close(self):
        self.session.close();super().close()


def context_url(ra,dec):
    hp=HEALPix(nside=32,order="nested",frame=ICRS())
    pixel=int(hp.lonlat_to_healpix(ra*u.deg,dec*u.deg))
    directory=pixel//10000*10000
    return f"https://nasa-irsa-spherex.s3.amazonaws.com/dr1/hips5_cube/hips_20261026/Norder5/Dir{directory}/Npix{pixel}_cube.fits",pixel


def fetch_context(target,output_dir,layers=(8,25,42,65,85,100),radius_pixels=24):
    """Save real multiwavelength coadded cutouts with no observation-date claim."""
    output_dir=Path(output_dir);output_dir.mkdir(parents=True,exist_ok=True)
    manifest=output_dir/f"{target['key']}_context.json"
    if manifest.is_file():
        cached=json.loads(manifest.read_text(encoding="utf-8"))
        if {item['layer'] for item in cached.get('layers',[])}==set(layers) and all(Path(item['path']).is_file() for item in cached['layers']):
            return cached
    ra,dec=target["query_ra_deg"],target["query_dec_deg"]
    url,pixel=context_url(ra,dec)
    summaries=[]
    with HTTPRangeFile(url) as remote:
        with fits.open(remote,memmap=False,lazy_load_hdus=True) as hdul:
            image_hdu=hdul["IMAGE"]
            spatial=WCS(image_hdu.header,fobj=hdul).celestial
            x,y=map(float,spatial.world_to_pixel(SkyCoord(ra,dec,unit="deg")))
            ny,nx=image_hdu.shape[1:]
            if not (-.5<=x<nx-.5 and -.5<=y<ny-.5):raise ValueError("The resolved coordinate is outside its expected HiPS tile.")
            ix,iy=int(round(x)),int(round(y))
            x0,x1=max(0,ix-radius_pixels),min(nx,ix+radius_pixels+1)
            y0,y1=max(0,iy-radius_pixels),min(ny,iy+radius_pixels+1)
            cut_header=spatial.slice((slice(y0,y1),slice(x0,x1))).to_header()
            spectral=Table(hdul["SPECTRAL_CHANNELS"].data)
            print(json.dumps({"target":target["key"],"tile":pixel,"wave_columns":spectral.colnames,"target_pixel":[x,y]}),flush=True)
            for layer in layers:
                data=np.asarray(image_hdu.section[layer,y0:y1,x0:x1],dtype=float)
                hits=np.asarray(hdul["NHITS"].section[layer,y0:y1,x0:x1],dtype=np.int32)
                flags=np.asarray(hdul["FLAGS"].section[layer,y0:y1,x0:x1],dtype=np.int32)
                wave_row={name:float(spectral[name][layer]) for name in spectral.colnames}
                header=cut_header.copy();header["BUNIT"]=image_hdu.header.get("BUNIT","MJy/sr")
                header["COADDED"]=(True,"A mosaic across exposures, not an observing epoch")
                header["LAYER"]=(layer,"Zero-based spectral cube layer")
                header["ORIGIN"]="NASA/IPAC IRSA SPHEREx DR1"
                primary=fits.PrimaryHDU()
                primary.header["DATATYPE"]="COADDED_CONTEXT"
                primary.header["SRCURL"]=url
                path=output_dir/f"{target['key']}_coadded_layer{layer:03d}.fits"
                fits.HDUList([primary,fits.ImageHDU(data.astype(np.float32),header=header,name="IMAGE"),
                    fits.ImageHDU(hits,name="NHITS"),fits.ImageHDU(flags,name="FLAGS")]).writeto(path,overwrite=True)
                centre=(iy-y0,ix-x0)
                summaries.append({"layer":layer,"path":str(path),"wavelength_metadata":wave_row,
                    "finite_fraction":float(np.isfinite(data).mean()),"centre_finite":bool(np.isfinite(data[centre])),
                    "centre_hits":int(hits[centre]),"centre_flags":int(flags[centre]),
                    "surface_brightness_unit":header["BUNIT"],"date":None})
        downloaded=remote.downloaded_bytes;request_count=remote.requests
    # A quick-look view is a context image, not a flux or detection measurement.
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from astropy.visualization import simple_norm
    preview=output_dir/f"{target['key']}_context.png"
    preferred=next((s for s in summaries if s["layer"]==85),summaries[-1])
    with fits.open(preferred["path"]) as image:
        data=image["IMAGE"].data;wcs=WCS(image["IMAGE"].header)
        fig=plt.figure(figsize=(6,5),layout="constrained");ax=fig.add_subplot(111,projection=wcs)
        if np.isfinite(data).any():ax.imshow(data,origin="lower",cmap="gray",norm=simple_norm(data,"asinh",percent=99))
        ax.scatter([ix-x0],[iy-y0],s=160,facecolors="none",edgecolors="#20c9d2",linewidths=1.5)
        ax.set_title(target["label"]+"\nDR1 coadded context; not a time epoch")
        ax.set_xlabel("Right Ascension");ax.set_ylabel("Declination")
        fig.savefig(preview,dpi=140);plt.close(fig)
    result={"available":True,"type":"coadded_context","source_url":url,"healpix_order":5,
        "healpix_pixel":pixel,"preview_path":str(preview),"layers":summaries,
        "downloaded_bytes":downloaded,"range_requests":request_count,
        "covered_layers":sum(s["centre_hits"]>0 and s["centre_finite"] for s in summaries),
        "notes":["These are real DR1 multiwavelength coadded mosaic pixels, not individual dated observations.",
                 "NHITS and FLAGS are retained. No VARIANCE is supplied by the cube; no source-detection significance, proper motion, light curve or single-exposure photometry is inferred from this context."]}
    manifest.write_text(json.dumps(result,indent=2,allow_nan=False),encoding="utf-8")
    return result


def validate_one(target,root,network=True,context=True):
    key=target["key"]
    item={"key":key,"label":target["label"],"resolved":target,"frames":[],"measurements":[],"notes":[],"query":{"status":"not_attempted","record_count":0}}
    if not target.get("available"):
        item["status"]="catalogue_unavailable";return item
    region=archive.Region(target["query_ra_deg"],target["query_dec_deg"],4.)
    if network:
        try:
            query=archive.load_saved_query(region.ra,region.dec,archive.COLLECTIONS,root/"data/query_cache");last_error=None
            if query is None:
                for collection in archive.COLLECTIONS:
                    subset=archive.load_saved_query(region.ra,region.dec,[collection],root/"data/query_cache")
                    if subset is not None:
                        query=subset
                        item["notes"].append("The available sample uses "+collection+" only; the combined-release query was unavailable. This is not complete coverage of all releases.")
                        break
            used_saved_query=query is not None
            for attempt in range(3 if query is None else 0):
                try:
                    query=archive.search_with_recovery(region.ra,region.dec,archive.COLLECTIONS,root/"data/query_cache")
                    break
                except Exception as error:
                    last_error=error
                    print(json.dumps({"target":key,"search_attempt":attempt+1,"reason":str(error)[:200]}),flush=True)
            if query is None:raise last_error
            archive.save_query(query,root/"data/query_cache")
            item["query"]={"status":"success","record_count":len(query["records"]),"raw_count":query["raw_count"],"method":query.get("query_method",query.get("source_label")),"region":query["region"],"collections":query["collections"],"used_saved_query":used_saved_query,"metadata_fetched_at":query.get("fetched_at",query.get("saved_at"))}
            # Three well-separated epochs of a common detector, plus other bands.
            records=query["records"]
            preferred="SPHEREx-D1" if key!="wise_0855" else "SPHEREx-D6"
            counts={band:sum(r["detector"]==band for r in records) for band in {r["detector"] for r in records}}
            if counts and counts.get(preferred,0)<2:preferred=max(counts,key=counts.get)
            movie=[r for r in records if r["detector"]==preferred]
            chosen=[movie[i] for i in sorted(set(np.linspace(0,len(movie)-1,min(3,len(movie))).astype(int)))] if movie else []
            for detector in sorted({r["detector"] for r in records}):
                if detector!=preferred:chosen.append(next(r for r in records if r["detector"]==detector))
            for record in chosen:
                try:item["frames"].append(archive.download_cutout(record,region,root/"data/cutout_cache"))
                except Exception as error:item["notes"].append("Cutout unavailable: "+str(error)[:200])
            if item["frames"]:
                import measurement_workflow
                item["measurements"]=measurement_workflow.measure_series(item["frames"],region.ra,region.dec,catalogue=target,aperture_arcsec=12.,annulus_inner=18.,annulus_outer=30.,follow_centroid=False)
        except Exception as error:
            item["query"]={"status":"unavailable","record_count":0,"region":{"ra":region.ra,"dec":region.dec,"fov_arcmin":4.},"methods_attempted":["IRSA SIA2","IRSA TAP"],"reason":str(error)[:600]}
    if context:
        try:item["context"]=fetch_context(target,root/"data/targets/contexts")
        except Exception as error:item["context"]={"available":False,"reason":str(error)[:600]}
    else:
        # Recheck dated-image search without discarding verified coadded evidence.
        previous=targets.load_benchmark_report(root)
        old=next((row for row in (previous or {}).get("targets",[]) if row.get("key")==key),None)
        if old is not None and old.get("context",{}).get("available"):
            item["context"]=old["context"]
    dates=sorted({f["record"]["mjd"] for f in item["frames"]})
    item["independent_times"]=len(dates)
    item["time_baseline_days"]=(dates[-1]-dates[0]) if len(dates)>1 else None
    item["status"]="dated_samples_available" if len(dates)>1 else "coadded_context_only" if item.get("context",{}).get("available") else "archive_unavailable"
    item["detection_status"]="Measured samples available; inspect per-frame quality" if item["measurements"] else "Not assessed: no individual dated images were retrieved; context coverage is not a source detection"
    return item


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--root",type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument("--skip-search",action="store_true");parser.add_argument("--skip-context",action="store_true")
    args=parser.parse_args();root=args.root
    destination=root/"data/targets";destination.mkdir(parents=True,exist_ok=True)
    catalogue=[targets.resolve_target(t["key"],destination) for t in targets.TARGETS]
    (destination/"catalogue.json").write_text(json.dumps({"targets":catalogue},indent=2,allow_nan=False),encoding="utf-8")
    result=[]
    with ThreadPoolExecutor(max_workers=3) as executor:
        futures={executor.submit(validate_one,target,root,not args.skip_search,not args.skip_context):target for target in catalogue}
        for future in as_completed(futures):
            row=future.result();result.append(row)
            print(json.dumps({"key":row["key"],"status":row["status"],"context":row.get("context",{}).get("available"),"dated_frames":len(row["frames"])}),flush=True)
    order={t["key"]:i for i,t in enumerate(targets.TARGETS)};result.sort(key=lambda r:order[r["key"]])
    report={"generated_at":datetime.now(timezone.utc).isoformat(),"targets":result,
        "summary":{"catalogues_resolved":sum(r["resolved"].get("available",False) for r in result),
                   "coadded_contexts":sum(r.get("context",{}).get("available",False) for r in result),
                   "targets_with_multiple_dates":sum(r["independent_times"]>=2 for r in result)},
        "limitations":["Coadded spectral layers are not time epochs.","An archive failure is not a nondetection or absence of sky coverage.","All physical estimates require source association and quality checks."]}
    def convert(value):
        if isinstance(value,np.ndarray):return value.tolist()
        if isinstance(value,np.generic):return value.item()
        if isinstance(value,Path):return str(value)
        raise TypeError(type(value).__name__)
    (destination/"validation.json").write_text(json.dumps(report,indent=2,default=convert,allow_nan=False),encoding="utf-8")
    lines=["# Five-target SPHEREx validation","",f"Generated: {report['generated_at']}","", "| Target | Catalogue | Dated images | Coadded context | Status |","|---|---|---:|---|---|"]
    for row in result:
        lines.append(f"| {row['label']} | {row['resolved'].get('source_catalogue','unavailable')} | {len(row['frames'])} | {'available' if row.get('context',{}).get('available') else 'unavailable'} | {row['status']} |")
    lines += ["","## Interpretation","","Catalogue coordinates are epoch-tagged and propagated to2025.5 with supplied proper motion. Observer-dependent annual parallax is omitted from this approximate query centre.","","The HiPS contexts contain real DR1 coadded FITS pixels at several wavelengths. They have no single observation date and are excluded from movies/light curves/motion fits. NHITS and FLAGS are retained. Source detection is not established by a finite central pixel.",""]
    for row in result:
        lines += ["## "+row["label"],"",f"Query status: {row['query']['status']}; records: {row['query']['record_count']}.",f"Source: {row['resolved'].get('source_url','Unavailable')}",row["detection_status"],""]
        if row["query"].get("reason"):lines += [row["query"]["reason"],""]
        lines += row["resolved"].get("notes",[])+[""]
    (destination/"validation.md").write_text("\n".join(lines),encoding="utf-8")
    print(json.dumps(report["summary"]),flush=True)


if __name__=="__main__":main()
