"""Named challenge targets, provenance and real-data validation evidence."""
from dataclasses import asdict
import json
from pathlib import Path

import streamlit as st
import numpy as np
import plotly.graph_objects as go
from astropy.io import fits
from astropy.wcs import WCS
from astropy.coordinates import SkyCoord
import data_access as archive
import targets


def render_target_picker(root,query_cache_dir):
    with st.expander("Five challenge targets",expanded=False):
        choices={target["key"]:target["label"] for target in targets.TARGETS}
        key=st.selectbox("Required target",list(choices),format_func=choices.get,key="challenge_target_choice")
        st.caption("Names are resolved to epoch-tagged catalogue positions. Fast-moving objects are propagated to the SPHEREx observing period.")
        if st.button("Load this target",key="load_challenge_target",type="primary"):
            try:
                with st.spinner("Resolving the target and finding its real SPHEREx observations..."):
                    catalogue=targets.resolve_target(key,Path(root)/"data"/"targets",reference_epoch=2025.5,allow_network=True)
                    if not catalogue.get("available"):raise ValueError(catalogue.get("reason",catalogue.get("status","The catalogue position is unavailable.")))
                    region=archive.Region(float(catalogue["query_ra_deg"]),float(catalogue["query_dec_deg"]),6.)
                    st.session_state.draft_ra=region.ra;st.session_state.draft_dec=region.dec;st.session_state.draft_fov=region.fov_arcmin
                    st.session_state.draft_collections=list(archive.COLLECTIONS)
                    dataset=archive.load_saved_query(region.ra,region.dec,archive.COLLECTIONS,query_cache_dir)
                    if dataset is None:
                        for collection in archive.COLLECTIONS:
                            dataset=archive.load_saved_query(region.ra,region.dec,[collection],query_cache_dir)
                            if dataset is not None:
                                dataset=dict(dataset,source_notice="Saved "+collection+" observations only; combined-release coverage was unavailable in this validation run.")
                                break
                    if dataset is None:dataset=archive.search_with_recovery(region.ra,region.dec,archive.COLLECTIONS,query_cache_dir)
                    else:dataset=dict(dataset,source="saved")
                    dataset=dict(dataset,region=asdict(region),target_key=key)
                    st.session_state.draft_collections=list(dataset["collections"])
                    st.session_state.sky_dataset=dataset
                    st.session_state.sky_frame=None
                    st.session_state.active_target_catalogue=dict(catalogue,target_key=key)
                    for name in ("analysis_bundle","source_measurements"):st.session_state.pop(name,None)
                    st.query_params.update(dict(target=key,ra=f"{region.ra:.8f}",dec=f"{region.dec:.8f}",fov="6",collections=",".join(dataset["collections"])))
            except Exception as error:
                st.warning(str(error))
                st.caption("The coordinate form may contain the resolved target, but the active images remain labelled with their actual region until a search succeeds.")


def render_validation(root):
    st.subheader("Five-target validation")
    st.write("This report records actual archive requests, downloaded images, measurement outcomes and remaining data limitations. An unavailable archive query is not a non-detection and does not imply no sky coverage.")
    report=targets.load_benchmark_report(root)
    if not report:
        st.info("No validation report has been generated yet. Run validate_targets.py to collect current evidence.")
        return
    st.caption("Validation run: "+str(report.get("generated_at","Unknown")))
    rows=[]
    for target in report.get("targets",[]):
        query=target.get("query",{})
        measurements=target.get("measurements",[])
        if isinstance(measurements,dict):measurements=measurements.get("rows",[])
        context=target.get("context",{})
        rows.append({"Target":target["label"],"Status":target.get("status"),
                     "Archive records":str(query.get("record_count",query.get("records_count",query.get("count","Unknown")))) if query.get("status")=="success" else "Unavailable",
                     "Downloaded cutouts":len(target.get("frames",[])),
                     "Coadded spectral layers":len(context.get("layers",[])) if context.get("available") else 0,
                     "Usable fluxes":str(sum(bool(r.get("usable_flux")) for r in measurements)) if measurements else "Not assessed",
                     "Detections":str(sum(bool(r.get("detected")) for r in measurements)) if measurements else "Not assessed"})
    st.dataframe(rows,hide_index=True,width="stretch")
    for target in report.get("targets",[]):
        with st.expander(target["label"]+" — "+str(target.get("status","Unknown"))):
            resolved=target.get("resolved",{})
            st.write({key:resolved.get(key) for key in ("source_catalogue","source_id","epoch_jyear","query_epoch_jyear","coordinate_method","parallax_mas","parallax_error_mas")})
            if resolved.get("source_url"):st.link_button("Catalogue provenance",resolved["source_url"],key="catalogue_link_"+target["key"])
            for note in resolved.get("notes",[])+target.get("notes",[]):st.write("• "+str(note))
            context=target.get("context",{})
            if target.get("frames"):
                if st.button("Open these downloaded samples in the explorer",key="open_samples_"+target["key"],type="primary"):
                    st.session_state.pending_target_sample=target
                    st.rerun()
                render_dated_samples(root,target)
            if context.get("available"):
                render_coadded_context(root,target)
            st.json({"query":target.get("query"),"evidence_notes":target.get("notes",[])},expanded=False)
    st.download_button("Download full target validation JSON",json.dumps(report,indent=2,allow_nan=False),file_name="spherex_five_target_validation.json",mime="application/json")


def render_dated_samples(root,target):
    import explorer_ui
    import sequence
    import measurement_workflow
    st.write("**Individual dated observations and measurement quality**")
    rows=target.get("measurements",[])
    st.dataframe([{k:row.get(k) for k in ("date","detector","wavelength_um","flux_ujy","flux_err_ujy","detected","usable_flux","status","warnings")} for row in rows],hide_index=True)
    frames=target["frames"]
    labels=[str(f["meta"].get("date",f["record"].get("date")))+" · "+f["record"]["detector"] for f in frames]
    chosen=st.selectbox("Dated sample image",range(len(frames)),format_func=labels.__getitem__,key="dated_sample_"+target["key"])
    frame=dict(frames[chosen])
    path=Path(frame["path"])
    if not path.is_absolute():path=Path(root)/path
    if path.is_file():
        frame["path"]=str(path)
        try:
            native=sequence.load_native_frame(frame)
            image=native["image"]
            if np.isfinite(image).any():
                fig=explorer_ui.stack_figure(image,"Dated native cutout · "+labels[chosen])
                prediction=measurement_workflow.predicted_position(target["resolved"],frame["record"]["mjd"])
                if prediction is not None:
                    x,y=WCS(native["header"]).celestial.world_to_pixel(SkyCoord(*prediction,unit="deg"))
                    fig.add_trace(go.Scatter(x=[float(x)],y=[float(y)],mode="markers",name="Catalogue-predicted position",marker=dict(symbol="circle-open",size=18,color="#21bec5")))
                st.plotly_chart(fig,key="dated_target_image_"+target["key"],width="stretch",config={"displaylogo":False})
                st.caption("Native detector orientation; the circle is the predicted source position for this date. A finite or bright pixel alone is not a confirmed detection.")
        except (ValueError,OSError,KeyError) as error:st.info("Sample preview unavailable: "+str(error))
    good=[r for r in rows if r.get("usable_flux") and r.get("flux_ujy") is not None and r.get("wavelength_um") is not None]
    if good:
        graph=go.Figure(go.Scatter(x=[r["wavelength_um"] for r in good],y=[r["flux_ujy"] for r in good],error_y=dict(type="data",array=[r["flux_err_ujy"] for r in good]),mode="markers",text=[r["date"] for r in good]))
        graph.update_layout(title="Dated sample fluxes passing current quality checks",xaxis_title="Wavelength (μm)",yaxis_title="Preliminary aperture flux density (μJy)")
        st.plotly_chart(graph,key="dated_target_spectrum_"+target["key"],width="stretch",config={"displaylogo":False})
    st.download_button("Download dated sample measurements",explorer_ui.csv_data(rows),file_name=target["key"]+"_dated_measurements.csv",mime="text/csv",key="dated_target_csv_"+target["key"])


def render_coadded_context(root,target):
    """A separately labelled spectral context: never turned into observing epochs."""
    import explorer_ui
    context=target["context"]
    layers=context.get("layers",[])
    if not layers:return
    st.info("Real SPHEREx DR1 coadded context. These images combine exposures; their spectral layers are not different dates. They cannot establish a light curve, motion or parallax.")
    labels=[f"Layer {item['layer']}: {item['wavelength_metadata'].get('WAVELENGTH',float('nan')):.3f} μm" for item in layers]
    chosen=st.selectbox("Coadded wavelength layer",range(len(layers)),format_func=labels.__getitem__,key="context_layer_"+target["key"])
    sampled=[]
    for item in layers:
        path=Path(root)/"data"/"targets"/"contexts"/Path(item["path"]).name
        if not path.is_file():continue
        with fits.open(path,memmap=False) as hdul:
            data=np.asarray(hdul["IMAGE"].data,dtype=float)
            hits=np.asarray(hdul["NHITS"].data,dtype=int)
            flags=np.asarray(hdul["FLAGS"].data,dtype=np.int64)
            spatial=WCS(hdul["IMAGE"].header).celestial
            resolved=target["resolved"]
            x,y=spatial.world_to_pixel(SkyCoord(resolved["query_ra_deg"],resolved["query_dec_deg"],unit="deg"))
            ix,iy=int(round(float(x))),int(round(float(y)))
            inside=0<=ix<data.shape[1] and 0<=iy<data.shape[0]
            value=float(data[iy,ix]) if inside and hits[iy,ix]>0 and np.isfinite(data[iy,ix]) else None
            sampled.append({"wavelength_um":item["wavelength_metadata"].get("WAVELENGTH"),"centre_surface_brightness_MJy_sr":value,
                            "contributing_exposures":int(hits[iy,ix]) if inside else 0,"centre_flag_bitmask":int(flags[iy,ix]) if inside else None})
            if item is layers[chosen]:
                image=np.where(hits>0,data,np.nan)
                if np.isfinite(image).any():
                    figure=explorer_ui.stack_figure(image,target["label"]+" · "+labels[chosen]+" · coadded")
                    figure.add_trace(go.Scatter(x=[float(x)],y=[float(y)],mode="markers",name="Catalogue-predicted coordinate",marker=dict(symbol="circle-open",size=18,color="#21bec5")))
                    st.plotly_chart(figure,key="target_context_"+target["key"],width="stretch",config={"displaylogo":False})
                else:st.info("This spectral layer has no valid coverage in the displayed cutout.")
                st.caption("The circle marks the propagated query coordinate, not a confirmed detection. Zero-hit pixels are blank; quality flags must still be inspected.")
    if sampled:
        st.dataframe(sampled,hide_index=True)
        flux=[r for r in sampled if r["centre_surface_brightness_MJy_sr"] is not None]
        if flux:
            graph=go.Figure(go.Scatter(x=[r["wavelength_um"] for r in flux],y=[r["centre_surface_brightness_MJy_sr"] for r in flux],mode="markers",
                customdata=[[r["contributing_exposures"],r["centre_flag_bitmask"]] for r in flux],hovertemplate="%{x:.3f} μm<br>%{y:.4g} MJy/sr<br>NHITS=%{customdata[0]}<br>FLAGS=%{customdata[1]}<extra></extra>"))
            graph.update_layout(title="Coadded central-pixel surface brightness",xaxis_title="Wavelength (μm)",yaxis_title="Surface brightness (MJy/sr)")
            st.plotly_chart(graph,key="target_context_spectrum_"+target["key"],width="stretch",config={"displaylogo":False})
        st.caption("This graph samples a sky pixel across the downloaded coadded wavelengths. It is not background-subtracted source photometry, has no formal source-flux error bars and does not establish a detection. Missing layers are omitted.")
    if context.get("source_url"):st.link_button("Original NASA DR1 coadded FITS cube",context["source_url"],key="context_source_"+target["key"])
