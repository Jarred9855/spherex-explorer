# Release validation evidence

Target data run: 2026-11-15T14:53:30.175187+00:00

| Target | Archive records | Dated cutouts | Distinct sample times | Usable aperture fluxes | Significant image measurements |
|---|---:|---:|---:|---:|---:|
| Barnard's Star | 358 | 8 | 5 | 0 | 0 |
| Epsilon Indi B (Ba/Bb blend) | 120 | 6 | 4 | 5 | 5 |
| WISE 0855−0714 | 258 | 8 | 5 | 1 | 1 |
| RW Aurigae | 335 | 8 | 5 | 2 | 2 |
| R Draconis | 539 | 8 | 5 | 0 | 0 |

All five have real DR1 coadded spectral context as well. Coadded wavelength layers are not observing dates.

Epsilon Indi B's dated sample uses the recovered QR3-only query. It does not imply complete DR1/QR3 coverage.

Usable and detected are conservative image-quality classifications, not confirmations of source identity or scientific discoveries. Rejected saturated, blended, bad-flag or unstable-background measurements remain in the evidence JSON. A target with zero usable aperture fluxes still has downloaded images and a documented quality outcome.

Automated validation includes numerical equation/unit tests, mask/PSF/registration/stack invariants, source identity and import guards, complete-app integration with real data, and a five-target sample-opening check. Individual test results are recorded during release preparation.
