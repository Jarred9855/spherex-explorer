# Five-target SPHEREx validation

Generated: 2026-11-15T14:53:30.175187+00:00

| Target | Catalogue | Dated images | Coadded context | Status |
|---|---|---:|---|---|
| Barnard's Star | SIMBAD (Harvard mirror) | 8 | available | dated_samples_available |
| Epsilon Indi B (Ba/Bb blend) | SIMBAD (Harvard mirror) | 6 | available | dated_samples_available |
| WISE 0855−0714 | SIMBAD (Harvard mirror) | 8 | available | dated_samples_available |
| RW Aurigae | SIMBAD (Harvard mirror) | 8 | available | dated_samples_available |
| R Draconis | SIMBAD (Harvard mirror) | 8 | available | dated_samples_available |

## Interpretation

Catalogue coordinates are epoch-tagged and propagated to2025.5 with supplied proper motion. Observer-dependent annual parallax is omitted from this approximate query centre.

The HiPS contexts contain real DR1 coadded FITS pixels at several wavelengths. They have no single observation date and are excluded from movies/light curves/motion fits. NHITS and FLAGS are retained. Source detection is not established by a finite central pixel.

## Barnard's Star

Query status: success; records: 358.
Source: https://simbad.harvard.edu/simbad/sim-id?Ident=Barnard%27s+Star&output.format=ASCII
Measured samples available; inspect per-frame quality


## Epsilon Indi B (Ba/Bb blend)

Query status: success; records: 120.
Source: https://simbad.harvard.edu/simbad/sim-id?Ident=eps+Ind+B&output.format=ASCII
Measured samples available; inspect per-frame quality

This is the B brown-dwarf pair, not epsilon Indi A. SPHEREx does not resolve Ba/Bb; component motion/blending can affect the centroid.
Gaia DR3 RUWE=4.296 exceeds the app's conservative 1.4 quality gate; a single-star astrometric fit may be inadequate.
The brown-dwarf pair is blended; component orbital motion affects interpretation.

## WISE 0855−0714

Query status: success; records: 258.
Source: https://simbad.harvard.edu/simbad/sim-id?Ident=WISE+J085510.83-071442.5&output.format=ASCII
Measured samples available; inspect per-frame quality

The challenge's RA08h55m10.831s/Dec−07d14m42.53s is a discovery/name coordinate. The catalogue supplies a different epoch-J2000 position; propagate the epoch-tagged astrometry before selecting current observations.

## RW Aurigae

Query status: success; records: 335.
Source: https://simbad.harvard.edu/simbad/sim-id?Ident=RW+Aur&output.format=ASCII
Measured samples available; inspect per-frame quality

Parallax S/N is below10: do not estimate distance by a simple reciprocal.
The parallax does not meet the chosen positive, S/N≥10 inverse-distance gate.

## R Draconis

Query status: success; records: 539.
Source: https://simbad.harvard.edu/simbad/sim-id?Ident=R+Dra&output.format=ASCII
Measured samples available; inspect per-frame quality

SIMBAD radial velocity has low quality and is retained as raw provenance, not prefilled as a reliable velocity.
