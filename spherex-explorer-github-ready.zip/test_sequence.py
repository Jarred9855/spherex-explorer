"""Regression checks for fixed-sky geometry, coverage and preview safeguards."""

from pathlib import Path
import math
import unittest

import numpy as np
import astropy.units as u
from astropy.coordinates import SkyCoord
from astropy.io import fits
from astropy.wcs import WCS

import sequence


class SequenceTests(unittest.TestCase):
    def test_time_sampling_prefers_dates_and_preserves_detectors(self):
        records = []
        for i, day in enumerate([0, .001, .002, 1, 200, 400]):
            records.append({"mjd": 60000 + day, "obs_id": str(i), "detector": "SPHEREx-D1", "collection": "spherex_dr1"})
        records.append({"mjd": 60200, "obs_id": "other-band", "detector": "SPHEREx-D4"})
        chosen = sequence.choose_sequence_records(records, "SPHEREx-D1", 3)
        self.assertEqual([r["mjd"] for r in chosen], [60000, 60200, 60400])
        self.assertEqual(chosen, sequence.choose_sequence_records(list(reversed(records)), "SPHEREx-D1", 3))

    def test_grid_orientation_and_cap(self):
        grid = sequence.make_common_grid({"ra": 359.999, "dec": 30, "fov_arcmin": 30}, pixel_scale_arcsec=.1)
        self.assertEqual(grid["shape"], (384, 384))
        self.assertAlmostEqual(grid["pixel_scale_arcsec"], 1800 / 384)
        x, y = (np.array(grid["shape"]) - 1) / 2
        centre = grid["wcs"].pixel_to_world(x, y)
        north = grid["wcs"].pixel_to_world(x, y + 1)
        east = grid["wcs"].pixel_to_world(x - 1, y)
        self.assertGreater(north.dec.deg, centre.dec.deg)
        east_offset, _ = centre.spherical_offsets_to(east)
        self.assertGreater(east_offset.to_value(u.arcsec), 0)
        with self.assertRaises(ValueError):
            sequence.make_common_grid({"ra": 0, "dec": 0, "fov_arcmin": 6}, max_pixels=385)

    def test_bandpass_guard_is_not_detector_guard(self):
        matched = [{"detector": "D1", "wavelength_um": .753, "bandwidth_um": .0176},
                   {"detector": "D1", "wavelength_um": .755, "bandwidth_um": .0178}]
        self.assertTrue(sequence.wavelength_compatibility(matched)["compatible"])
        mismatched = matched + [{"detector": "D1", "wavelength_um": .9, "bandwidth_um": .022}]
        self.assertFalse(sequence.wavelength_compatibility(mismatched)["compatible"])
        self.assertFalse(sequence.wavelength_compatibility([{"detector": "D1"}])["compatible"])

    @staticmethod
    def make_fixture(path, size, angle, centre, stars, mjd):
        scale = 6.15 / 3600
        theta = math.radians(angle)
        wcs = WCS(naxis=2)
        wcs.wcs.crpix = [(size + 1) / 2, (size + 1) / 2]
        wcs.wcs.crval = [centre.ra.deg, centre.dec.deg]
        wcs.wcs.cd = [[-scale * math.cos(theta), scale * math.sin(theta)],
                      [scale * math.sin(theta), scale * math.cos(theta)]]
        wcs.wcs.ctype = ["RA---TAN", "DEC--TAN"]
        wcs.wcs.radesys = "ICRS"
        yy, xx = np.indices((size, size))
        image = np.full((size, size), 2.0)
        for star, amplitude in zip(stars, [10, 7]):
            x, y = wcs.world_to_pixel(star)
            image += amplitude * np.exp(-((xx-x)**2+(yy-y)**2)/(2*1.6**2))
        header = wcs.to_header(relax=True)
        header["BUNIT"] = "MJy / sr"
        header["PSF_FWHM"] = (2.354820045 * 1.6 * 6.15, "[arcsec] synthetic circular Gaussian PSF")
        flag_header = fits.Header()
        flag_header["MSKN0000"] = "SOURCE"
        flag_header["MSKM0000"] = 1
        fits.HDUList([fits.PrimaryHDU(), fits.ImageHDU(image.astype('f4'),header=header,name='IMAGE'),
                      fits.ImageHDU(np.full_like(image,.04),name='VARIANCE'),
                      fits.ImageHDU(np.ones(image.shape,dtype='i4'),header=flag_header,name='FLAGS')]).writeto(path,overwrite=True)
        return {"path":str(path),"record":{"mjd":mjd,"date":"synthetic","detector":"D1","obs_id":path.stem},
                "meta":{"wavelength_um":.753,"bandwidth_um":.0176}}

    @staticmethod
    def centroid(image, x, y, radius=4):
        x, y = float(x), float(y)
        x0, x1 = int(round(x))-radius, int(round(x))+radius+1
        y0, y1 = int(round(y))-radius, int(round(y))+radius+1
        patch = image[y0:y1,x0:x1]
        yy, xx = np.indices(patch.shape)
        weight = np.clip(patch-2.,0,None)
        return np.array([(weight*(xx+x0)).sum(),(weight*(yy+y0)).sum()])/weight.sum()

    def test_rotated_wcs_fixed_sources_and_missing_coverage(self):
        root = Path(__file__).resolve().parent.parent / 'tmp' / 'sequence-regression'
        root.mkdir(parents=True,exist_ok=True)
        centre = SkyCoord(210,30,unit='deg')
        stars = [centre.spherical_offsets_by(25*u.arcsec,15*u.arcsec),
                 centre.spherical_offsets_by(-55*u.arcsec,40*u.arcsec)]
        frame0 = self.make_fixture(root/'native-0.fits',81,0,centre,stars,60000)
        offset = centre.spherical_offsets_by(12*u.arcsec,-8*u.arcsec)
        frame1 = self.make_fixture(root/'native-1.fits',49,33,offset,stars,60200)
        result = sequence.align_sequence([frame1,frame0],{"ra":210,"dec":30,"fov_arcmin":8})
        self.assertEqual([m['mjd'] for m in result['metadata']],[60000,60200])
        common = WCS(result['header']).celestial
        for star in stars:
            x,y = common.world_to_pixel(star)
            pos0 = self.centroid(result['images'][0],x,y)
            pos1 = self.centroid(result['images'][1],x,y)
            self.assertLess(np.linalg.norm(pos0-pos1),.2)
        invalid = result['footprints']==0
        self.assertTrue(invalid.any())
        self.assertTrue(np.isnan(result['images'][invalid]).all())
        # Nonzero SOURCE-like flags are preserved, rather than blanket-masked.
        native = sequence.load_native_frame(frame0)
        self.assertTrue(np.isfinite(native['image']).all())
        self.assertTrue((native['flags']==1).all())
        self.assertTrue(native['valid_mask'].all())
        self.assertTrue(native['metadata']['quality_flags_known'])
        # This geometry fixture contains two stars, fewer than the strict
        # registration check's three-reference minimum. Its unchecked products
        # test coverage semantics; strict PSF/registration paths have their own
        # multi-star invariants in test_reliability.py.
        stack = sequence.preview_stack(result, match_psf=False, require_registration=False)
        residual = sequence.preview_difference(result, match_psf=False, require_registration=False)
        self.assertTrue(stack['diagnostic_only'] and residual['diagnostic_only'])
        self.assertTrue(np.isnan(stack['image'][~stack['coverage']]).all())
        self.assertTrue(np.isnan(residual['image'][~residual['coverage']]).all())
        result['metadata'][1]['wavelength_um']=.9
        with self.assertRaises(ValueError):
            sequence.preview_difference(result, match_psf=False, require_registration=False)
        with self.assertRaises(ValueError):
            sequence.preview_stack(result, match_psf=False, require_registration=False)


if __name__ == '__main__':
    unittest.main(verbosity=2)
