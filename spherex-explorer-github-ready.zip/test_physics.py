"""Numerical acceptance checks for equations and unsupported-data gates."""
import math
import numpy as np
import physics as p


def check():
    offsets = p.angular_offsets([359.9999, .0001], [0., 0.])
    assert offsets["available"]
    assert np.isclose(offsets["separation_arcsec"][1], .72, rtol=1e-8)
    time = np.array([60000., 60050., 60150., 60365.25])
    years = (time-time[0])/365.25
    motion = p.fit_apparent_motion(time, 2+.5*years, -3-.3*years,
                                   np.full(4, .02), np.full(4, .02))
    assert motion["available"]
    assert np.isclose(motion["mu_x_arcsec_per_year"], .5, rtol=1e-10)
    assert np.isclose(motion["mu_y_arcsec_per_year"], -.3, rtol=1e-10)
    assert motion["mu_error"] > 0
    assert not p.fit_apparent_motion([60000,60000],[0,1],[0,1])["available"]
    mean = p.weighted_mean([2,4],[1,1])
    assert mean["mean"] == 3 and np.isclose(mean["error"], 1/math.sqrt(2))
    change = p.brightness_change(100,200,2,3)
    assert np.isclose(change["delta_magnitude"], -.752574989159953)
    assert np.isclose(change["change_score"], 100/math.sqrt(13))
    assert p.brightness_change(-1,2,1,1)["delta_magnitude"] is None
    assert not p.brightness_change(1,2,1,1,covariance=2)["available"]
    distance = p.distance_from_parallax(100,1)
    assert distance["distance_pc"] == 10 and np.isclose(distance["distance_error_pc"], .1)
    assert not p.distance_from_parallax(5,1)["available"]
    speed = p.transverse_speed(.5,10,.01,.1)
    assert np.isclose(speed["transverse_kms"],23.70235)
    assert np.isclose(p.space_speed(3,4)["space_kms"],5)
    assert p.doppler_velocity(1.0001,1)["radial_kms"] > 0
    assert p.doppler_velocity(.9999,1)["radial_kms"] < 0
    assert not p.doppler_velocity(2,1)["available"]
    # Constant F_nu has an analytic integral F_nu*(nu_max-nu_min).
    band = p.integrate_band_flux([1,2],[100,100],[10,10])
    expected = 100e-32*p.c.value*(1/1e-6-1/2e-6)
    assert band["available"] and np.isclose(band["flux_w_m2"], expected, rtol=1e-12, atol=0)
    assert not p.integrate_band_flux([1,1],[100,100])["available"]
    light = p.luminosity(1,1e-16)
    assert np.isclose(light["luminosity_w"],4*math.pi*p.PC_M**2*1e-16)
    orbit = p.kepler_period(1,1)
    assert orbit["available"] and abs(orbit["period_years"]-1)<1e-4
    axis = p.kepler_semimajor_axis(orbit["period_years"],1)
    assert np.isclose(axis["semimajor_axis_au"],1,rtol=1e-12)
    # Irregular, well-sampled synthetic variability with a known period.
    rng = np.random.default_rng(417)
    t = np.sort(rng.uniform(0,120,180))
    e = np.full(len(t),.03)
    f = 10+.5*np.sin(2*np.pi*t/7.5)+rng.normal(0,e)
    period = p.candidate_period(60000+t,f,e)
    assert period["available"] and abs(period["period_days"]-7.5)<.05
    assert period["false_alarm_probability"] is None or period["false_alarm_probability"]<.01
    assert not p.candidate_period([1,2,3],[1,2,1],[.1,.1,.1])["available"]
    # Thermal peak within versus outside the observed wavelength interval.
    wavelength = np.geomspace(.6,5.,24)
    pivot = float(np.exp(np.mean(np.log(wavelength))))
    model = 100*p._blackbody_shape(wavelength,3000.,pivot)
    thermal = p.fit_blackbody_fnu(wavelength,model,model*.02)
    assert thermal["available"] and abs(thermal["temperature_k"]-3000)<.01
    cold = 100*p._blackbody_shape(wavelength,500.,pivot)
    unbracketed = p.fit_blackbody_fnu(wavelength,cold,cold*.02)
    assert not unbracketed["available"] and "outside" in unbracketed["reason"]
    print("PASS: wrapped coordinates; weighted apparent motion; averaging; covariance-aware change; parallax gate; velocity components; units-correct flux integral; luminosity; Kepler inversion; irregular period recovery; thermal-fit and peak-coverage gates.")


if __name__ == "__main__":
    check()
