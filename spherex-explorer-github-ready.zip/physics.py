"""Unit-explicit numerical analysis for the SPHEREx exploratory viewer.

These functions calculate estimates from supplied measurements. They do not
identify a planet, perform a catalogue crossmatch, measure a new parallax, or
turn visualization-level wavelength calibration into precision spectroscopy.
All public functions return ``available`` and, when unavailable, ``reason``.
Array-valued results are NumPy arrays so the interface can plot them directly.
"""

from __future__ import annotations

import math
import numpy as np
import astropy.units as u
from astropy.coordinates import SkyCoord
from astropy.constants import c, h, k_B, G, M_sun, L_sun

YEAR_DAYS = 365.25
PC_M = u.pc.to(u.m)
AU_M = u.au.to(u.m)
YEAR_S = u.yr.to(u.s)
C_KMS = c.to_value(u.km / u.s)
FNU_UJY_TO_SI = 1e-32


def _unavailable(reason, **details):
    return dict(available=False, reason=reason, **details)


def _number(value):
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def _vectors(*values):
    arrays = [np.asarray(v, dtype=float).reshape(-1) for v in values]
    if len({len(v) for v in arrays}) != 1:
        raise ValueError("Measurement arrays must have equal lengths.")
    return arrays


def angular_offsets(ra_deg, dec_deg, origin_ra_deg=None, origin_dec_deg=None):
    """Sky offsets/separation in arcseconds; invalid rows remain NaN.

    Uses spherical coordinates rather than subtracting RA near the 0/360 wrap.
    The origin defaults to the first finite valid coordinate. Offsets are on a
    sky-offset frame; for a small field x is approximately delta-RA*cos(dec).
    """
    ra, dec = _vectors(ra_deg, dec_deg)
    valid = np.isfinite(ra) & np.isfinite(dec) & (dec >= -90) & (dec <= 90)
    if not valid.any():
        return _unavailable("No valid celestial positions were supplied.")
    if (origin_ra_deg is None) != (origin_dec_deg is None):
        return _unavailable("Supply both coordinates of the reference position.")
    if origin_ra_deg is None:
        reference_ra, reference_dec = ra[valid][0], dec[valid][0]
    else:
        reference_ra, reference_dec = _number(origin_ra_deg), _number(origin_dec_deg)
        if reference_ra is None or reference_dec is None or not -90 <= reference_dec <= 90:
            return _unavailable("The reference coordinate is invalid.")
    origin = SkyCoord(reference_ra, reference_dec, unit="deg", frame="icrs")
    coordinates = SkyCoord(ra[valid], dec[valid], unit="deg", frame="icrs")
    dx, dy = origin.spherical_offsets_to(coordinates)
    x = np.full(len(ra), np.nan)
    y = np.full(len(ra), np.nan)
    separation = np.full(len(ra), np.nan)
    x[valid], y[valid] = dx.to_value(u.arcsec), dy.to_value(u.arcsec)
    separation[valid] = origin.separation(coordinates).to_value(u.arcsec)
    return dict(available=True, x_arcsec=x, y_arcsec=y,
                separation_arcsec=separation, valid_mask=valid,
                origin_ra_deg=float(origin.ra.deg), origin_dec_deg=float(origin.dec.deg))


def _linear_fit(years, values, errors):
    design = np.column_stack((np.ones(len(years)), years))
    weights = np.ones(len(years)) if errors is None else 1 / errors**2
    normal = design.T @ (weights[:, None] * design)
    covariance = np.linalg.inv(normal)
    parameters = covariance @ (design.T @ (weights * values))
    predicted = design @ parameters
    residual = values - predicted
    if errors is None:
        covariance = covariance * np.sum(residual**2) / (len(years)-2) if len(years) > 2 else None
    return parameters, covariance, predicted, residual


def fit_apparent_motion(mjd, x_arcsec, y_arcsec, sigma_x_arcsec=None, sigma_y_arcsec=None):
    """Fit linear sky offsets against time, returning apparent arcsec/year.

    Quoted errors assume independent coordinate/epoch measurements. The fit
    does not remove annual parallax, differential chromatic shifts, blending,
    orbital motion, or instrumental registration/calibration systematics.
    """
    time, x, y = _vectors(mjd, x_arcsec, y_arcsec)
    sx = None if sigma_x_arcsec is None else np.asarray(sigma_x_arcsec, dtype=float).reshape(-1)
    sy = None if sigma_y_arcsec is None else np.asarray(sigma_y_arcsec, dtype=float).reshape(-1)
    if (sx is not None and len(sx) != len(time)) or (sy is not None and len(sy) != len(time)):
        raise ValueError("Position error arrays must match the measurement arrays.")
    valid = np.isfinite(time) & np.isfinite(x) & np.isfinite(y)
    if sx is not None:
        valid &= np.isfinite(sx) & (sx > 0)
    if sy is not None:
        valid &= np.isfinite(sy) & (sy > 0)
    indices = np.flatnonzero(valid)
    if len(indices) < 2 or len(np.unique(time[valid])) < 2:
        return _unavailable("At least two distinct observing times and reliable positions are needed.")
    indices = indices[np.argsort(time[indices], kind="stable")]
    time, x, y = time[indices], x[indices], y[indices]
    sx = None if sx is None else sx[indices]
    sy = None if sy is None else sy[indices]
    t0 = float(np.mean(time))
    years = (time - t0) / YEAR_DAYS
    try:
        px, cx, model_x, residual_x = _linear_fit(years, x, sx)
        py, cy, model_y, residual_y = _linear_fit(years, y, sy)
    except np.linalg.LinAlgError:
        return _unavailable("The time samples do not support a stable linear-motion fit.")
    mx, my = float(px[1]), float(py[1])
    mu = math.hypot(mx, my)
    ex = None if cx is None else float(np.sqrt(max(0., cx[1, 1])))
    ey = None if cy is None else float(np.sqrt(max(0., cy[1, 1])))
    emu = None
    if mu > 0 and ex is not None and ey is not None:
        emu = math.sqrt((mx*ex)**2 + (my*ey)**2) / mu
    return dict(
        available=True, kind="apparent linear angular motion", t0_mjd=t0,
        mjd=time, x_arcsec=x, y_arcsec=y, valid_indices=indices,
        model_x_arcsec=model_x, model_y_arcsec=model_y,
        residual_x_arcsec=residual_x, residual_y_arcsec=residual_y,
        mu_x_arcsec_per_year=mx, mu_y_arcsec_per_year=my,
        mu_arcsec_per_year=mu, mu_x_error=ex, mu_y_error=ey, mu_error=emu,
        intercept_x_arcsec=float(px[0]), intercept_y_arcsec=float(py[0]),
        baseline_days=float(time[-1]-time[0]), n=len(time),
        rms_residual_arcsec=float(np.sqrt(np.mean(residual_x**2+residual_y**2))),
        warning="Apparent motion includes parallax and possible instrumental or colour-dependent shifts. Formal fit errors exclude these systematics.",
    )


def weighted_mean(values, errors):
    """Inverse-variance mean and uncertainty for independent compatible data."""
    values, errors = _vectors(values, errors)
    valid = np.isfinite(values) & np.isfinite(errors) & (errors > 0)
    if not valid.any():
        return _unavailable("No finite measurements with positive uncertainties are available.")
    weight = 1 / errors[valid]**2
    return dict(available=True, mean=float(np.sum(weight*values[valid])/np.sum(weight)),
                error=float(1/np.sqrt(np.sum(weight))), n=int(valid.sum()),
                warning="Combine only compatible bandpasses and time bins. Shared errors reduce the ideal precision gain.")


def brightness_change(f1, f2, error1, error2, covariance=0.0):
    """Flux difference, change/noise score, and positive-flux magnitude change.

    Fluxes/errors must share one unit and effective bandpass. Covariance has
    squared-flux units. No classification probability is inferred.
    """
    values = [_number(v) for v in (f1, f2, error1, error2, covariance)]
    if any(v is None for v in values):
        return _unavailable("Finite fluxes, uncertainties and covariance are required.")
    f1, f2, e1, e2, cov = values
    if e1 <= 0 or e2 <= 0 or abs(cov) > e1*e2*(1+1e-12):
        return _unavailable("Uncertainties must be positive and covariance must be physically consistent.")
    variance = e1**2+e2**2-2*cov
    if variance <= 0:
        return _unavailable("The supplied errors do not give a positive difference variance.")
    sigma = math.sqrt(variance)
    dm = dm_error = ratio = None
    if f1 > 0 and f2 > 0:
        ratio = f2/f1
        dm = -2.5*math.log10(ratio)
        dm_variance = (2.5/math.log(10))**2*(e1**2/f1**2+e2**2/f2**2-2*cov/(f1*f2))
        dm_error = math.sqrt(max(0., dm_variance))
    return dict(available=True, delta_flux=f2-f1, delta_flux_error=sigma,
                change_score=(f2-f1)/sigma, flux_ratio=ratio,
                delta_magnitude=dm, delta_magnitude_error=dm_error,
                warning="A statistical difference alone does not establish astrophysical variability. Match effective bandpasses and assess calibration, PSF and blending changes.")


def candidate_period(mjd, flux, errors, minimum_period_days=None, maximum_period_days=None):
    """Candidate Lomb-Scargle repeat timescale, in days; never an orbit claim.

    A conservative default searches periods between max(2*median gap,
    baseline/100) and baseline/2. Thus at least two proposed cycles fit within
    the baseline. This is a bounded exploratory search, not a universal cadence
    criterion. Explicit bounds may be supplied; an excessive grid is rejected.
    """
    from astropy.timeseries import LombScargle

    time, flux, errors = _vectors(mjd, flux, errors)
    valid = np.isfinite(time) & np.isfinite(flux) & np.isfinite(errors) & (errors > 0)
    time, flux, errors = time[valid], flux[valid], errors[valid]
    if len(np.unique(time)) < 12:
        return _unavailable("Period searches require at least 12 distinct time samples in a compatible wavelength band.")
    order = np.argsort(time, kind="stable")
    time, flux, errors = time[order], flux[order], errors[order]
    baseline = float(np.ptp(time))
    gaps = np.diff(np.unique(time))
    cadence = float(np.median(gaps))
    if not baseline > 0 or not cadence > 0:
        return _unavailable("A positive observing baseline and sample spacing are needed.")
    minimum = max(2*cadence, baseline/100) if minimum_period_days is None else _number(minimum_period_days)
    maximum = baseline/2 if maximum_period_days is None else _number(maximum_period_days)
    if minimum is None or maximum is None or minimum <= 0 or maximum <= minimum:
        return _unavailable("The chosen period interval is invalid or unsupported by the baseline.")
    if maximum > baseline/2*(1+1e-12):
        return _unavailable("Restrict the longest candidate period to half the observing baseline so two cycles can be covered.")
    if np.ptp(flux) <= max(np.max(np.abs(flux)), 1.)*1e-12:
        return _unavailable("The supplied light curve has no resolved brightness variation.")
    fmin, fmax = 1/maximum, 1/minimum
    grid_size = max(1000, int(math.ceil((fmax-fmin)*baseline*5))+1)
    if grid_size > 50000:
        return _unavailable("This period interval needs a much finer frequency grid. Narrow the period range before searching.")
    frequency = np.linspace(fmin, fmax, grid_size)
    relative_time = time-time[0]
    ls = LombScargle(relative_time, flux, errors, fit_mean=True, center_data=True)
    power = np.asarray(ls.power(frequency, normalization="standard"), dtype=float)
    finite = np.isfinite(power)
    if not finite.any():
        return _unavailable("The periodogram could not be estimated from these samples.")
    peak = int(np.nanargmax(power))
    period = float(1/frequency[peak])
    false_alarm = None
    try:
        probability = float(ls.false_alarm_probability(power[peak], method="baluev",
                            minimum_frequency=fmin, maximum_frequency=fmax,
                            samples_per_peak=5))
        if math.isfinite(probability):
            false_alarm = probability
    except (ValueError, RuntimeError, FloatingPointError):
        pass
    phase = np.mod(relative_time/period, 1)
    model_time = np.linspace(0, period, 250)
    warning = "Candidate only. Survey cadence creates aliases; false-alarm probability is conditional on the noise model and is not the probability this period is correct."
    if peak in (0, len(power)-1):
        warning += " The peak is at a search boundary; change the search interval before interpretation."
    if np.max(gaps) > baseline/4:
        warning += " Large gaps make the sampling particularly ambiguous."
    return dict(available=True, period_days=period, frequency_per_day=frequency,
                power=power, peak_power=float(power[peak]), false_alarm_probability=false_alarm,
                mjd=time, flux=flux, errors=errors, phase=phase,
                model_phase=model_time/period,
                model_flux=np.asarray(ls.model(model_time, frequency[peak])),
                baseline_days=baseline, median_gap_days=cadence,
                minimum_period_days=minimum, maximum_period_days=maximum,
                search_boundary=peak in (0, len(power)-1), warning=warning)


def distance_from_parallax(parallax_mas, parallax_error_mas, min_snr=10.0):
    """Approximate inverse-parallax distance, gated to reliable positive values.

    Inputs: milliarcseconds. Outputs: parsecs/light-years. Requires a supplied
    positive error and S/N >= min_snr; no zero-point correction or Bayesian
    distance inference is performed. The default threshold is a conservative
    application choice, not a universal astronomical rule.
    """
    p, error, minimum = (_number(v) for v in (parallax_mas, parallax_error_mas, min_snr))
    if p is None or error is None or minimum is None or p <= 0 or error <= 0 or minimum < 1:
        return _unavailable("Supply a positive parallax and positive uncertainty from a reliable catalogue.")
    snr = p/error
    if snr < minimum:
        return _unavailable(f"Parallax S/N is below the chosen {minimum:g} threshold. Use an uncertainty-aware catalogue distance estimate instead of taking the reciprocal.", parallax_snr=snr)
    distance = 1000/p
    sigma = 1000*error/p**2
    return dict(available=True, distance_pc=distance, distance_error_pc=sigma,
                distance_ly=distance*3.26156, distance_error_ly=sigma*3.26156,
                parallax_snr=snr,
                warning="Approximate inverse-parallax distance with first-order uncertainty. Catalogue quality and zero-point corrections remain the user's responsibility.")


def transverse_speed(mu_arcsec_per_year, distance_pc, mu_error=None, distance_error=None):
    """Transverse km/s from angular motion (arcsec/year) and distance (pc)."""
    mu, distance = _number(mu_arcsec_per_year), _number(distance_pc)
    if mu is None or distance is None or mu < 0 or distance <= 0:
        return _unavailable("A non-negative angular speed and a positive reliable distance are required.")
    sigma = None
    if mu_error is not None or distance_error is not None:
        emu, ed = _number(mu_error), _number(distance_error)
        if emu is None or ed is None or emu < 0 or ed < 0:
            return _unavailable("Supply both non-negative uncertainties, or omit both.")
        sigma = 4.74047*math.sqrt((distance*emu)**2+(mu*ed)**2)
    return dict(available=True, transverse_kms=4.74047*mu*distance,
                transverse_error_kms=sigma,
                warning="A transverse component in the stated frame. Apparent image motion must first be separated from parallax and systematics. Error propagation assumes independent distance and motion estimates.")


def doppler_velocity(observed_um, rest_um):
    """First-order Doppler radial km/s for an identified rest feature.

    Both wavelengths are in micrometres. This calculator does not measure a
    SPHEREx spectral-line shift or apply observer/frame corrections.
    """
    observed, rest = _number(observed_um), _number(rest_um)
    if observed is None or rest is None or observed <= 0 or rest <= 0:
        return _unavailable("Positive observed and identified rest wavelengths are needed.")
    z = (observed-rest)/rest
    if abs(z) > .01:
        return _unavailable("The supplied shift exceeds this calculator's low-velocity range; use a suitable relativistic or cosmological model.", redshift=z)
    return dict(available=True, redshift=z, radial_kms=C_KMS*z,
                direction="receding" if z > 0 else "approaching" if z < 0 else "no supplied shift",
                warning="Derived from the supplied feature identification. This is not a precision radial-velocity measurement from SPHEREx; observer corrections and appropriate spectroscopy are required.")


def space_speed(transverse_kms, radial_kms):
    """3D speed magnitude in km/s, only for compatible velocity frames."""
    vt, vr = _number(transverse_kms), _number(radial_kms)
    if vt is None or vr is None or vt < 0:
        return _unavailable("Supply a non-negative transverse speed and a measured radial velocity in compatible frames.")
    return dict(available=True, space_kms=math.hypot(vt, vr),
                warning="Both components must describe the same source and compatible reference frames. Missing radial velocity is not zero.")


def predicted_parallax_track(ra_deg, dec_deg, parallax_mas, mjd,
                             pmra_mas_per_year=0.0, pmdec_mas_per_year=0.0,
                             reference_mjd=None):
    """Earth-viewpoint model from supplied parallax and proper motion.

    RA/Dec are degrees; parallax and proper-motion components are mas and
    mas/year. ``pmra`` already includes cos(dec), as in Gaia's convention.
    Input MJD values use UTC. Outputs are east/north tangent-plane offsets in
    arcseconds relative to the model's barycentric reference position. The
    first parallax offset need not be zero. The default proper-motion reference
    epoch is the earliest supplied time.

    The builtin barycentric Earth ephemeris avoids downloading a kernel. This
    is a predicted educational track, not a parallax fit or a precision model
    of a low-Earth-orbit telescope. It does not return a newly inferred distance.
    """
    from astropy.coordinates import get_body_barycentric
    from astropy.time import Time

    ra, dec, parallax, pmra, pmdec = (_number(value) for value in (
        ra_deg, dec_deg, parallax_mas, pmra_mas_per_year, pmdec_mas_per_year))
    if any(value is None for value in (ra, dec, parallax, pmra, pmdec)):
        return _unavailable("Supply finite coordinates, parallax and proper-motion components.")
    if not -90 <= dec <= 90:
        return _unavailable("Declination must lie between -90 and +90 degrees.")
    if parallax < 0:
        return _unavailable("A negative parallax cannot define this predicted physical track.")
    try:
        time = np.asarray(mjd, dtype=float).reshape(-1)
    except (TypeError, ValueError):
        return _unavailable("Model times must be finite MJD numbers.")
    if not len(time) or not np.isfinite(time).all():
        return _unavailable("At least one finite model time is required; remove invalid MJD values.")
    time = np.sort(time, kind="stable")
    epoch = float(time[0]) if reference_mjd is None else _number(reference_mjd)
    if epoch is None:
        return _unavailable("The proper-motion reference epoch must be a finite MJD value.")
    ra = ra % 360
    alpha, delta = np.deg2rad([ra, dec])
    try:
        earth = get_body_barycentric("earth", Time(time, format="mjd", scale="utc"),
                                     ephemeris="builtin")
        X, Y, Z = np.asarray(earth.xyz.to_value(u.au), dtype=float)
    except (ValueError, RuntimeError, OverflowError):
        return _unavailable("The builtin Earth ephemeris could not evaluate the supplied dates.")
    east_factor = X*np.sin(alpha)-Y*np.cos(alpha)
    north_factor = (X*np.cos(alpha)*np.sin(delta)
                    + Y*np.sin(alpha)*np.sin(delta)-Z*np.cos(delta))
    parallax_x = parallax*1e-3*east_factor
    parallax_y = parallax*1e-3*north_factor
    years = (time-epoch)/YEAR_DAYS
    pm_x, pm_y = pmra*1e-3*years, pmdec*1e-3*years
    if not (np.isfinite(parallax_x).all() and np.isfinite(parallax_y).all()):
        return _unavailable("The model ephemeris did not produce finite sky offsets.")
    return dict(
        available=True, kind="predicted Earth-viewpoint parallax and proper motion",
        mjd=time, x_arcsec=parallax_x+pm_x, y_arcsec=parallax_y+pm_y,
        parallax_x_arcsec=parallax_x, parallax_y_arcsec=parallax_y,
        proper_motion_x_arcsec=pm_x, proper_motion_y_arcsec=pm_y,
        east_parallax_factor=east_factor, north_parallax_factor=north_factor,
        reference_mjd=epoch, ra_deg=ra, dec_deg=dec, parallax_mas=parallax,
        pmra_mas_per_year=pmra, pmdec_mas_per_year=pmdec,
        warning="Predicted from supplied astrometric values, not measured from these images. Uses Earth's centre with the builtin barycentric ephemeris; it omits the telescope's low-Earth-orbit displacement and precision apparent-position corrections. No new parallax or distance is inferred.",
    )


def luminosity(distance_pc, flux_w_m2, flux_error=None, distance_error=None):
    """Isotropic luminosity from pc and integrated W/m2; output W and L_sun.

    The caller must distinguish bolometric flux from measured-band flux.
    No extinction correction or bolometric correction is applied here.
    """
    distance, flux = _number(distance_pc), _number(flux_w_m2)
    if distance is None or flux is None or distance <= 0 or flux <= 0:
        return _unavailable("Positive distance and a positive calibrated integrated flux are needed.")
    factor = 4*math.pi*(distance*PC_M)**2
    value = factor*flux
    sigma = None
    if flux_error is not None or distance_error is not None:
        ef, ed = _number(flux_error), _number(distance_error)
        if ef is None or ed is None or ef < 0 or ed < 0:
            return _unavailable("Supply both non-negative uncertainties, or omit both.")
        sigma = value*math.sqrt((ef/flux)**2+(2*ed/distance)**2)
    return dict(available=True, luminosity_w=value, luminosity_solar=value/L_sun.value,
                luminosity_error_w=sigma,
                warning="Assumes isotropic emission and independent errors. Label this as band luminosity unless the supplied flux is genuinely bolometric; correct extinction where needed.")


def integrate_band_flux(wavelength_um, flux_ujy, errors_ujy=None):
    """Trapezoidal measured-range energy flux estimate from F_nu samples.

    Wavelengths are micrometres, F_nu/errors are microjansky. Integrates F_nu dnu
    in increasing frequency; never integrates F_nu dlambda. This interpolates
    between distinct sample centres and is NOT a bolometric correction or a
    bandpass-convolved spectral reconstruction. Duplicate wavelength centres
    must be binned deliberately before calling it.
    """
    wavelength, flux = _vectors(wavelength_um, flux_ujy)
    errors = None if errors_ujy is None else np.asarray(errors_ujy, dtype=float).reshape(-1)
    if errors is not None and len(errors) != len(wavelength):
        raise ValueError("Flux uncertainties must match the wavelength samples.")
    valid = np.isfinite(wavelength) & (wavelength > 0) & np.isfinite(flux)
    if errors is not None:
        valid &= np.isfinite(errors) & (errors > 0)
    wavelength, flux = wavelength[valid], flux[valid]
    errors = None if errors is None else errors[valid]
    if len(np.unique(wavelength)) < 2:
        return _unavailable("At least two distinct calibrated wavelength samples are required.")
    if len(np.unique(wavelength)) != len(wavelength):
        return _unavailable("Bin repeated wavelength centres with an explicit time/wavelength selection before integrating.")
    frequency = c.value/(wavelength*1e-6)
    order = np.argsort(frequency)
    frequency, flux = frequency[order], flux[order]
    if errors is not None:
        errors = errors[order]
    gaps = np.diff(frequency)
    coefficients = np.empty(len(frequency))
    coefficients[0], coefficients[-1] = gaps[0]/2, gaps[-1]/2
    if len(frequency) > 2:
        coefficients[1:-1] = (gaps[:-1]+gaps[1:])/2
    value = float(np.sum(coefficients*flux)*FNU_UJY_TO_SI)
    sigma = None if errors is None else float(np.sqrt(np.sum((coefficients*errors)**2))*FNU_UJY_TO_SI)
    if value <= 0:
        return _unavailable("The estimated integrated flux is not positive; it cannot support a positive luminosity estimate.", flux_w_m2=value, flux_error_w_m2=sigma)
    sorted_lambda = np.sort(wavelength)
    return dict(available=True, flux_w_m2=value, flux_error_w_m2=sigma,
                wavelength_min_um=float(wavelength.min()), wavelength_max_um=float(wavelength.max()),
                largest_wavelength_ratio=float(np.max(sorted_lambda[1:]/sorted_lambda[:-1])),
                warning="Measured-range trapezoidal estimate only. Gaps, bandpass response, non-simultaneous epochs and calibration can dominate its error; the formal error excludes interpolation uncertainty. Not bolometric flux.")


def _blackbody_shape(wavelength_um, temperature, pivot_um):
    wavelength = np.asarray(wavelength_um, dtype=float)*1e-6
    frequency = c.value/wavelength
    pivot_frequency = c.value/(pivot_um*1e-6)
    exponent = h.value*frequency/(k_B.value*temperature)
    pivot_exponent = h.value*pivot_frequency/(k_B.value*temperature)
    # Ratio removes the unknown source scale while retaining the F_nu shape.
    return (frequency/pivot_frequency)**3 * np.expm1(min(float(pivot_exponent), 700.)) / np.expm1(np.minimum(exponent, 700.))


def fit_blackbody_fnu(wavelength_um, flux_ujy, errors_ujy):
    """Exploratory Planck F_nu fit with free amplitude; no atmosphere inference.

    Requires six distinct positive-flux samples spanning a wavelength ratio >=
    1.5, sufficient signal, and a fitted F_nu peak bracketed by the coverage.
    These are conservative app gates. An unbracketed/degenerate fit returns
    unavailable rather than a misleading measured temperature. WCS-WAVE and
    preliminary aperture data remain visualization-level inputs.
    """
    from scipy.optimize import least_squares

    wavelength, flux, error = _vectors(wavelength_um, flux_ujy, errors_ujy)
    valid = np.isfinite(wavelength) & (wavelength > 0) & np.isfinite(flux) & (flux > 0) & np.isfinite(error) & (error > 0)
    wavelength, flux, error = wavelength[valid], flux[valid], error[valid]
    if len(np.unique(wavelength)) < 6:
        return _unavailable("A thermal fit needs at least six distinct reliable wavelength samples.")
    if len(np.unique(wavelength)) != len(wavelength):
        return _unavailable("Select or bin repeated wavelength measurements before a thermal fit.")
    if wavelength.max()/wavelength.min() < 1.5:
        return _unavailable("The wavelength range is too narrow to constrain this thermal model.")
    if np.median(flux/error) < 3:
        return _unavailable("The spectrum has insufficient median signal-to-noise for this exploratory thermal fit.")
    order = np.argsort(wavelength)
    wavelength, flux, error = wavelength[order], flux[order], error[order]
    pivot = float(np.exp(np.mean(np.log(wavelength))))
    amplitude_guess = float(np.interp(pivot, wavelength, flux))
    def residual(log_parameters):
        amplitude, temperature = np.exp(log_parameters)
        return (amplitude*_blackbody_shape(wavelength, temperature, pivot)-flux)/error
    low = np.log([1e-20, 100.])
    high = np.log([max(1e20, float(flux.max())*1e6), 50000.])
    solutions = []
    for temperature_guess in (500., 1500., 5000., 15000.):
        try:
            fit = least_squares(residual, np.log([amplitude_guess, temperature_guess]),
                                bounds=(low, high), max_nfev=2000)
            if fit.success and np.isfinite(fit.cost):
                solutions.append(fit)
        except (ValueError, FloatingPointError):
            continue
    if not solutions:
        return _unavailable("The thermal model fit did not converge.")
    fit = min(solutions, key=lambda f: f.cost)
    amplitude, temperature = map(float, np.exp(fit.x))
    # The maximum of B_nu occurs at h*nu/kT=2.821439... . Its wavelength
    # location differs from the B_lambda Wien peak at 2897.77/T micrometres.
    fnu_peak_um = h.value*c.value/(2.8214393721220787*k_B.value*temperature)*1e6
    model_lambda = np.geomspace(wavelength.min(), wavelength.max(), 250)
    model_flux = amplitude*_blackbody_shape(model_lambda, temperature, pivot)
    details = dict(model_wavelength_um=model_lambda, model_flux_ujy=model_flux,
                   fitted_trial_temperature_k=temperature, fnu_peak_um=fnu_peak_um)
    if not wavelength.min() < fnu_peak_um < wavelength.max():
        return _unavailable("The fitted F_nu peak is outside the wavelength coverage; this spectrum does not bracket a thermal peak, so no constrained temperature is reported.", **details)
    if not (np.any(wavelength < fnu_peak_um) and np.any(wavelength > fnu_peak_um)):
        return _unavailable("The thermal peak is not bracketed by samples.", **details)
    normal = fit.jac.T@fit.jac
    if not np.isfinite(normal).all() or np.linalg.cond(normal) > 1e10:
        return _unavailable("Temperature and source scale are too degenerate for a stable estimate.", **details)
    reduced_chi2 = float(2*fit.cost/(len(wavelength)-2))
    covariance = np.linalg.inv(normal)*max(1., reduced_chi2)
    sigma_temperature = float(temperature*np.sqrt(max(0., covariance[1, 1])))
    warning = "Thermal-model estimate only, not a measured atmospheric temperature. Molecular absorption, clouds, non-simultaneous observations and calibration can invalidate a blackbody interpretation."
    if reduced_chi2 > 3:
        warning += " The residuals exceed the quoted statistical errors; a blackbody may be inadequate."
    return dict(available=True, temperature_k=temperature, temperature_error_k=sigma_temperature,
                amplitude_ujy=amplitude, pivot_um=pivot, reduced_chi2=reduced_chi2,
                wien_blambda_peak_um=2897.771955/temperature,
                warning=warning, **details)


def kepler_period(a_au, central_mass_solar, companion_mass_solar=0.0):
    """Two-body orbital period from relative semimajor axis (AU), masses (M_sun)."""
    a, mass, companion = (_number(v) for v in (a_au, central_mass_solar, companion_mass_solar))
    if a is None or mass is None or companion is None or a <= 0 or mass <= 0 or companion < 0:
        return _unavailable("Supply a positive established semimajor axis and central mass; companion mass cannot be negative.")
    seconds = 2*math.pi*math.sqrt((a*AU_M)**3/(G.value*(mass+companion)*M_sun.value))
    return dict(available=True, period_years=seconds/YEAR_S, period_days=seconds/86400,
                semimajor_axis_au=a,
                warning="Two-body model from supplied orbital inputs. These are not orbit measurements from two sky images.")


def kepler_semimajor_axis(period_years, central_mass_solar, companion_mass_solar=0.0):
    """Relative two-body semimajor axis (AU) from established period (yr), masses."""
    period, mass, companion = (_number(v) for v in (period_years, central_mass_solar, companion_mass_solar))
    if period is None or mass is None or companion is None or period <= 0 or mass <= 0 or companion < 0:
        return _unavailable("Supply a positive established period and central mass; companion mass cannot be negative.")
    axis = (G.value*(mass+companion)*M_sun.value*(period*YEAR_S)**2/(4*math.pi**2))**(1/3)
    return dict(available=True, semimajor_axis_au=axis/AU_M, period_years=period,
                warning="Two-body model from supplied orbital inputs, not an inferred orbit from apparent motion alone.")

