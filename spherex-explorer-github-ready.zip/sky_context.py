"""Shareable coordinates and an optional CDS sky atlas with Gaia/WISE context."""
from dataclasses import asdict
import json
import math
from urllib.parse import urlencode

import streamlit as st

import data_access as archive


def parse_region_query(params):
    if "ra" not in params or "dec" not in params:
        return None
    try:
        return archive.Region(float(params["ra"]),float(params["dec"]),float(params.get("fov",6)))
    except (ValueError,TypeError):
        raise ValueError("The shared URL needs valid decimal RA, Dec and a field between 1 and 30 arcminutes.")


def region_query(region,collections=None,target=None):
    values={"ra":f"{region.ra:.8f}","dec":f"{region.dec:.8f}","fov":f"{region.fov_arcmin:g}"}
    if collections:values["collections"]=",".join(sorted(collections))
    if target:values["target"]=target
    return urlencode(values)


def render_share(region,collections,target=None):
    if st.button("Put this region in the URL",key="share_region"):
        st.query_params.update(dict(ra=f"{region.ra:.8f}",dec=f"{region.dec:.8f}",fov=f"{region.fov_arcmin:g}",collections=",".join(sorted(collections))))
        if target:st.query_params["target"]=target
        elif "target" in st.query_params:del st.query_params["target"]
        st.success("The address bar now contains this region. Copy its full URL to share it.")
    st.caption("Coordinate query: ?"+region_query(region,collections,target)+". A localhost link works only on this computer until the app is deployed.")


def atlas_html(region,survey="P/allWISE/color",gaia=False,selected_source=None):
    if survey not in ("P/allWISE/color","P/2MASS/color","P/DSS2/color"):
        raise ValueError("Unknown sky-context survey.")
    # Explicit mirrors avoid depending on the central CDS survey-ID registry.
    survey_urls={"P/allWISE/color":"https://irsa.ipac.caltech.edu/data/hips/CDS/AllWISE/RGB-W4-W2-W1",
                 "P/2MASS/color":"https://skies.esac.esa.int/2MASSColor",
                 "P/DSS2/color":"https://stpubdata.s3.us-east-1.amazonaws.com/mast/skybackgrounds/DSSColor"}
    options={"target":f"{region.ra:.9f} {region.dec:+.9f}","fov":max(.02,region.fov_arcmin/60),
             "survey":survey_urls[survey],"cooFrame":"ICRSd","showCooGrid":True,"showSimbadPointerControl":True,"showShareControl":True}
    gaia_url="https://vizier.cfa.harvard.edu/viz-bin/votable?"+urlencode({"-source":"I/355/gaiadr3","-c":f"{region.ra} {region.dec}","-c.r":region.fov_arcmin/2,"-c.u":"arcmin","-out.max":"1000","-out":"Source,RA_ICRS,DE_ICRS,Plx,e_Plx,pmRA,pmDE,Gmag"})
    source=None
    if selected_source:
        ra=float(selected_source["ra"]);dec=float(selected_source["dec"])
        if math.isfinite(ra) and math.isfinite(dec) and 0<=ra<360 and -90<=dec<=90:source=[ra,dec]
    return """<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{margin:0;background:#111;color:#eee;font:14px sans-serif}#atlas{height:510px;width:100%}#notice{padding:8px}</style></head>
<body><div id="atlas"></div><div id="notice">Loading CDS Aladin sky context…</div>
<script type="module">
const options=OPTIONS,selected=SELECTED,includeGaia=GAIA,gaiaUrl=GAIA_URL;
function fail(error){document.getElementById('notice').textContent='The external sky atlas could not load: '+String(error?.message||error||'script unavailable')+'. SPHEREx analysis remains available in the other tabs.';}
import('https://cdn.jsdelivr.net/npm/aladin-lite@3.8.2/dist/aladin.js').then(module=>{const A=module.default||module.A;return A.init.then(()=>{
 const map=A.aladin('#atlas',options);
 map.setBaseImageLayer(A.HiPS(options.survey,{
   name:'Requested sky context',
   errorCallback:fail
 }));
 const layer=A.catalog({name:'Selected region/source',sourceSize:16,color:'#22d3ee'});
 map.addCatalog(layer);layer.addSources([A.marker(REGION_RA,REGION_DEC,{popupTitle:'SPHEREx region centre'})]);
 if(selected){layer.addSources([A.marker(selected[0],selected[1],{popupTitle:'Selected source coordinates'})]);}
 if(includeGaia){A.catalogFromURL(gaiaUrl,{name:'Gaia DR3 — catalogue epoch2016.0',color:'#ffcc66',sourceSize:8,onClick:'showTable'},cat=>map.addCatalog(cat),()=>{document.getElementById('notice').textContent='Gaia catalogue could not be retrieved. External image availability depends on the selected survey service.';});}
 document.getElementById('notice').textContent='Requested context survey: '+options.survey+'. External tiles may be unavailable. Gaia positions, if enabled, are catalogue-epoch positions and are not automatically shifted to a SPHEREx exposure.';
});}).catch(fail);
</script></body></html>""".replace("OPTIONS",json.dumps(options)).replace("SELECTED",json.dumps(source)).replace("GAIA_URL",json.dumps(gaia_url)).replace("GAIA",json.dumps(bool(gaia))).replace("REGION_RA",repr(region.ra)).replace("REGION_DEC",repr(region.dec))


def render_atlas(region,selected_source=None):
    st.subheader("Sky context: WISE, 2MASS and Gaia")
    st.write("Pan and zoom the surrounding sky, or compare another mission's view with the selected SPHEREx region.")
    cols=st.columns(2)
    survey=cols[0].selectbox("Context survey",["P/allWISE/color","P/2MASS/color","P/DSS2/color"],format_func=lambda v:{"P/allWISE/color":"AllWISE infrared","P/2MASS/color":"2MASS near infrared","P/DSS2/color":"DSS optical"}[v])
    gaia=cols[1].checkbox("Overlay Gaia DR3 sources",value=False)
    enabled=st.checkbox("Load the external sky atlas",value=False)
    if enabled:st.iframe(atlas_html(region,survey,gaia,selected_source),height=560,alt="External WISE/2MASS sky context with optional Gaia DR3 sources")
    st.caption("Context images come from external CDS/mission services and have different observing dates. They are not frames in the SPHEREx time player. CDS Aladin attribution is retained.")
    st.link_button("Open the IRSA SPHEREx Data Explorer","https://irsa.ipac.caltech.edu/applications/spherex")
