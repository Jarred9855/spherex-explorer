"""Numerical smoke checks using an independent synthetic Gaussian source."""

from pathlib import Path
import json
import math
import tempfile

import numpy as np
from astropy.io import fits
from astropy.time import Time
from astropy.wcs import WCS

import photometry as p


def make_frame(path, centre=(50.35, 49.70), mjd=61000.0, flags_value=0):
    rng = np.random.default_rng(1205)
    yy, xx = np.indices((101, 101))
    sigma, amplitude, noise = 1.2, 0.05, 0.001
    star = amplitude * np.exp(-((xx - centre[0]) ** 2 + (yy - centre[1]) ** 2) / (2 * sigma ** 2))
    image = 0.2 + star + rng.normal(0, noise, xx.shape)
    wcs = WCS(naxis=2)
    wcs.wcs.crpix = [51, 51]
    wcs.wcs.cdelt = [-1 / 3600, 1 / 3600]
    wcs.wcs.crval = [123, -15]
    wcs.wcs.ctype = ["RA---TAN", "DEC--TAN"]
    header = wcs.to_header()
    header["BUNIT"] = "MJy/sr"
    header["MJD-OBS"] = mjd
    header["DATE-OBS"] = Time(mjd, format="mjd").isot
    flags = np.zeros(image.shape, dtype=np.int32)
    flags[((xx - centre[0]) ** 2 + (yy - centre[1]) ** 2) < 5 ** 2] = flags_value
    flag_header = fits.Header()
    flag_header["MSKN0000"] = "SOURCE"
    flag_header["MSKM0000"] = 1
    flag_header["MSKN0001"] = "BLOOM"
    flag_header["MSKM0001"] = 2
    fits.HDUList([
        fits.PrimaryHDU(), fits.ImageHDU(image, header=header, name="IMAGE"),
        fits.ImageHDU(np.full(image.shape, noise ** 2), name="VARIANCE"),
        fits.ImageHDU(flags, header=flag_header, name="FLAGS"),
    ]).writeto(path, overwrite=True)
    sky = wcs.pixel_to_world(*centre)
    theoretical_flux = 2 * math.pi * sigma ** 2 * amplitude * (math.pi / 648000) ** 2 * 1e12
    return wcs, sky, theoretical_flux


def run():
    with tempfile.TemporaryDirectory() as folder:
        directory = Path(folder)
        first = directory / "first.fits"
        second = directory / "second.fits"
        flagged = directory / "flagged.fits"
        bad = directory / "bad.fits"
        wcs, sky, theory = make_frame(first)
        make_frame(second, centre=(51.35, 49.70), mjd=61200)
        make_frame(flagged, flags_value=1)
        make_frame(bad, flags_value=3)
        candidates = p.detect_sources(first)
        assert candidates
        assert abs(candidates[0]["x"] - 50.35) < 0.2
        assert abs(candidates[0]["y"] - 49.70) < 0.2
        options = dict(aperture_arcsec=4, annulus_inner=7, annulus_outer=11, search_radius_arcsec=3)
        measured = p.measure_source(first, sky.ra.deg, sky.dec.deg, **options)
        assert measured["usable_flux"] and measured["centroid_valid"], measured
        assert abs(measured["flux_ujy"] / theory - 1) < 0.04, (measured["flux_ujy"], theory)
        assert measured["flux_err_ujy"] > 0
        assert measured["position_error_arcsec"] is None
        assert measured["central_wavelength_um"] is None
        flagged_measurement = p.measure_source(flagged, sky.ra.deg, sky.dec.deg, **options)
        assert flagged_measurement["pixel_flags_or"] == 1
        assert flagged_measurement["flux_ujy"] == measured["flux_ujy"]
        bad_measurement = p.measure_source(bad, sky.ra.deg, sky.dec.deg, **options)
        assert bad_measurement["status"] == "bad_quality_flags"
        assert not bad_measurement["usable_flux"] and bad_measurement["flux_ujy"] is None
        blank = wcs.pixel_to_world(20.0, 20.0)
        nondetection = p.measure_source(first, blank.ra.deg, blank.dec.deg, **options)
        assert not nondetection["detected"] and nondetection["upper_limit_ujy"] > 0
        assert nondetection["flux_ujy"] is not None
        corner = wcs.pixel_to_world(1.0, 1.0)
        edge = p.measure_source(first, corner.ra.deg, corner.dec.deg, follow_centroid=False, **options)
        assert edge["status"] == "aperture_truncated" and edge["flux_ujy"] is None
        series = p.extract_series([
            {"path": str(second), "record": {"detector": "D1", "obs_id": "second"}},
            {"path": str(first), "record": {"detector": "D1", "obs_id": "first"}},
        ], sky.ra.deg, sky.dec.deg, **options)
        assert series[0]["mjd"] == 61000 and series[1]["mjd"] == 61200
        assert all(row["centroid_valid"] for row in series)
        dx = series[1]["centroid_x"] - series[0]["centroid_x"]
        assert abs(dx - 1) < 0.15, dx
        print(json.dumps({"synthetic_flux_ujy": measured["flux_ujy"], "theory_total_ujy": theory,
                          "snr": measured["snr"], "measured_shift_pixels": dx,
                          "non_detection_upper_limit": nondetection["upper_limit_ujy"]}))
        print("PASS: native flux/units, centroid tracking, nonzero flags, nondetection, edge rejection and sorting")


if __name__ == "__main__":
    run()
