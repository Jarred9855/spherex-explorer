"""Numerical and interpretation regressions for advanced supplied-data models."""
import unittest
import math
import numpy as np

import advanced_analysis as advanced
import physics


class AdvancedTests(unittest.TestCase):
    def test_shared_reference_covariance_cancels_common_calibration(self):
        sigma=np.array([1.,2.,3.])
        result=advanced.shared_reference_differences([60000,60010,60020],[10,13,9],sigma)
        self.assertTrue(result['available'])
        np.testing.assert_allclose(result['delta_flux'],[0,3,-1])
        np.testing.assert_allclose(np.diag(result['covariance']),[0,5,10])
        self.assertAlmostEqual(result['covariance'][1,2],1.)
        covariance=np.diag(sigma*sigma)+4*np.ones((3,3))
        common=advanced.shared_reference_differences([60000,60010,60020],[10,13,9],np.sqrt(np.diag(covariance)),covariance=covariance)
        np.testing.assert_allclose(common['covariance'],result['covariance'])
        self.assertFalse(advanced.shared_reference_differences([1],[1],[1])['available'])
        self.assertFalse(advanced.shared_reference_differences([1,2],[1,2],None)['available'])
        self.assertFalse(advanced.shared_reference_differences([1,2],[1,2],[1,1],reference_index=None)['available'])

    def test_spectral_density_units_and_negative_noisy_flux(self):
        result=advanced.fnu_to_flambda([1.,2.],[1.,-1.],[.1,.2])
        self.assertTrue(result['available'])
        np.testing.assert_allclose(result['flambda_w_m2_um'],[2.99792458e-18,-2.99792458e-18/4])
        np.testing.assert_allclose(result['flambda_error_w_m2_um'],[2.99792458e-19,2.99792458e-18*.2/4])
        self.assertIsNone(advanced.fnu_to_flambda([1.],[1.])['flambda_error_w_m2_um'])
        self.assertFalse(advanced.fnu_to_flambda([0.],[1.])['available'])

    def astrometric_data(self,parallax=.2,noise=.002):
        time=np.linspace(60000,61020,32)
        # Generate with the independently implemented catalogue prediction helper.
        prediction=physics.predicted_parallax_track(210.,30.,abs(parallax)*1000,time,
                    pmra_mas_per_year=120.,pmdec_mas_per_year=-70.,reference_mjd=60510)
        rng=np.random.default_rng(441)
        sign=1 if parallax>=0 else -1
        x=.3+prediction['proper_motion_x_arcsec']+sign*prediction['parallax_x_arcsec']+rng.normal(0,noise,len(time))
        y=-.2+prediction['proper_motion_y_arcsec']+sign*prediction['parallax_y_arcsec']+rng.normal(0,noise,len(time))
        sigma=np.full(len(time),noise)
        return time,x,y,sigma,sigma

    def test_five_parameter_fit_recovers_signal_and_honours_reference(self):
        inputs=self.astrometric_data()
        self.assertFalse(advanced.fit_five_parameter_astrometry(*inputs,210,30)['available'])
        relative=advanced.fit_five_parameter_astrometry(*inputs,210,30,
                    calibrated=True,reference_corrected=True,calibration_reference='synthetic regression')
        self.assertTrue(relative['available'])
        self.assertFalse(relative['distance_available'])
        self.assertLess(abs(relative['parallax_mas']-200),4)
        self.assertLess(abs(relative['mu_x_mas_per_year']-120),3)
        self.assertLess(abs(relative['mu_y_mas_per_year']+70),3)
        absolute=advanced.fit_five_parameter_astrometry(*inputs,210,30,
                    calibrated=True,reference_corrected=True,calibration_reference='synthetic regression',
                    solution_kind='absolute',absolute_reference='synthetic absolute frame')
        self.assertTrue(absolute['distance_available'])
        self.assertAlmostEqual(absolute['distance']['distance_pc'],5.,delta=.1)
        self.assertEqual(absolute['rank'],5)

    def test_negative_low_snr_and_bad_residuals_never_give_distance(self):
        common=dict(calibrated=True,reference_corrected=True,calibration_reference='synthetic',solution_kind='absolute',absolute_reference='synthetic')
        negative=advanced.fit_five_parameter_astrometry(*self.astrometric_data(-.1),210,30,**common)
        self.assertTrue(negative['available'])
        self.assertFalse(negative['distance_available'])
        low=advanced.fit_five_parameter_astrometry(*self.astrometric_data(.001),210,30,**common)
        self.assertFalse(low['distance_available'])
        time,x,y,sx,sy=self.astrometric_data()
        x=x+.15*np.sin(2*np.pi*(time-time[0])/87)
        poor=advanced.fit_five_parameter_astrometry(time,x,y,sx,sy,210,30,**common)
        self.assertTrue(poor['available'])
        self.assertFalse(poor['fit_acceptable'])
        self.assertFalse(poor['distance_available'])

    def test_annual_sampling_and_uncertainty_guards(self):
        inputs=list(self.astrometric_data())
        common=dict(calibrated=True,reference_corrected=True,calibration_reference='synthetic')
        inputs[0]=60000+np.arange(32)*.01
        self.assertFalse(advanced.fit_five_parameter_astrometry(*inputs,210,30,**common)['available'])
        inputs=list(self.astrometric_data())
        inputs[0]=60000+np.repeat(np.arange(4)*365.25,8)+np.tile(np.arange(8)*.001,4)
        self.assertFalse(advanced.fit_five_parameter_astrometry(*inputs,210,30,**common)['available'])
        inputs=list(self.astrometric_data())
        inputs[3]=None
        self.assertFalse(advanced.fit_five_parameter_astrometry(*inputs,210,30,**common)['available'])

    def test_template_scale_with_band_averaging_and_no_extrapolation(self):
        tw=np.linspace(.6,5.5,20000)
        tf=tw**-2
        wave=np.array([.8,1.,1.5,2.,3.,4.5])
        width=.025*wave
        truth=2.5*((1/(wave-width/2)-1/(wave+width/2))/width)
        result=advanced.fit_uploaded_template(wave,truth,np.full(len(wave),.01),width,tw,tf)
        self.assertTrue(result['available'])
        self.assertAlmostEqual(result['scale'],2.5,delta=1e-5)
        self.assertLess(result['reduced_chi2'],1e-5)
        self.assertFalse(advanced.fit_uploaded_template([.2,.3],[1.,1.],[.1,.1],[.01,.01],tw,tf)['available'])

    def test_orbit_position_and_speed_respect_supplied_elements(self):
        result=advanced.known_orbit_timeseries(1.,semimajor_axis_au=1.,samples=257)
        self.assertTrue(result['available'])
        self.assertAlmostEqual(result['period_years'],1.,delta=1e-4)
        np.testing.assert_allclose(result['separation_au'],np.ones(257),atol=1e-12)
        self.assertAlmostEqual(result['x_au'][32],0.,delta=1e-10)
        self.assertAlmostEqual(result['y_au'][32],1.,delta=1e-10)
        eccentric=advanced.known_orbit_timeseries(1.,semimajor_axis_au=2.,eccentricity=.5,samples=257)
        self.assertAlmostEqual(eccentric['separation_au'][0],1.)
        self.assertAlmostEqual(eccentric['separation_au'][64],3.)
        self.assertGreater(eccentric['speed_kms'][0],eccentric['speed_kms'][64])
        self.assertFalse(advanced.known_orbit_timeseries(None,semimajor_axis_au=1.)['available'])
        self.assertFalse(advanced.known_orbit_timeseries(1.,semimajor_axis_au=1.,period_years=2.)['available'])

    def test_upload_schemas_do_not_certify_calibration(self):
        csv='mjd,x_arcsec,y_arcsec,sigma_x_arcsec,sigma_y_arcsec\n60000,0,0,.01,.01\n'
        parsed=advanced.parse_calibrated_astrometry_csv(csv)
        self.assertTrue(parsed['available'])
        self.assertIn('does not establish',parsed['warning'])
        self.assertFalse(advanced.parse_calibrated_astrometry_csv('mjd,x_arcsec\n1,2\n')['available'])
        self.assertFalse(advanced.parse_calibrated_astrometry_csv(csv.replace('.01,.01','0,.01'))['available'])
        self.assertTrue(advanced.parse_spectral_template_csv('wavelength_um,flux_ujy\n1,2\n2,1\n3,.5\n')['available'])
        self.assertFalse(advanced.parse_spectral_template_csv('wavelength_um,flux_ujy\n1,2\n1,1\n3,.5\n')['available'])


if __name__=='__main__':
    unittest.main(verbosity=2)
