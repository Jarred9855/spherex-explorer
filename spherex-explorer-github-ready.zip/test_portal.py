"""Coordinate-sharing, strict imported-data and source-identity invariants."""
import unittest
from urllib.parse import parse_qs,unquote
import numpy as np
from astropy.time import Time
import calibrated_data
import measurement_workflow as workflow
import sky_context
import data_access as archive


class PortalTests(unittest.TestCase):
    def test_shared_region_roundtrip(self):
        region=archive.Region(359.9999,-82.3,12.)
        params={k:v[0] for k,v in parse_qs(sky_context.region_query(region,archive.COLLECTIONS)).items()}
        result=sky_context.parse_region_query(params)
        self.assertEqual(region,result)
        for params in ({"ra":"nan","dec":"0"},{"ra":"360","dec":"0"},{"ra":"1","dec":"91"}):
            with self.assertRaises(ValueError):sky_context.parse_region_query(params)

    def test_import_preserves_negative_flux_and_rejects_flags(self):
        content=b'wavelength,flux,flux_err,mjd,lambda_width,det_id,flags\n1.2,-2,1,61000,.02,2,2097152\n1.2,5,1,61001,.02,2,67108864\n'
        rows=calibrated_data.parse_photometry_csv(content,10,20,"Official test-schema fixture")
        self.assertEqual(rows[0]["flux_ujy"],-2)
        self.assertFalse(rows[0]["detected"])
        self.assertTrue(rows[0]["usable_flux"])
        self.assertFalse(rows[1]["usable_flux"])
        self.assertEqual(rows[0]["detector"],"SPHEREx-D2")
        self.assertFalse(rows[0]["usable_for_astrometry"])

    def test_import_wrong_source_and_units(self):
        content=b'wavelength,flux,flux_err,mjd,ra,dec\n1.2,2,1,61000,11,20\n'
        with self.assertRaises(ValueError):calibrated_data.parse_photometry_csv(content,10,20,"Export provenance")
        for content in (b'wavelength,flux,flux_err,mjd\n1.2,2,-1,61000\n',b'wavelength,flux,flux_err,mjd\n1.2,2,1,2025\n'):
            with self.assertRaises(ValueError):calibrated_data.parse_photometry_csv(content,10,20,"Export provenance")

    def test_catalogue_identity_and_epoch_motion(self):
        catalogue={"available":True,"query_ra_deg":10.,"query_dec_deg":0.,"query_epoch_jyear":2025.,"pmra_mas_per_year":1000.,"pmdec_mas_per_year":-500.}
        self.assertTrue(workflow.catalogue_matches_source(catalogue,10.,0.))
        self.assertFalse(workflow.catalogue_matches_source(catalogue,10.01,0.))
        pos=workflow.predicted_position(catalogue,Time(2026.,format="jyear").mjd)
        self.assertAlmostEqual((pos[0]-10)*3600,1.,places=5)
        self.assertAlmostEqual(pos[1]*3600,-.5,places=5)
        self.assertIsNone(workflow.predicted_position(dict(catalogue,pmdec_mas_per_year=None),61000))

    def test_external_atlas_coordinates_are_numeric(self):
        html=sky_context.atlas_html(archive.Region(10.,20.),gaia=True)
        self.assertIn("I/355/gaiadr3",unquote(html))
        self.assertNotIn("REGION_RA",html)
        with self.assertRaises(ValueError):sky_context.atlas_html(archive.Region(10.,20.),survey='<script>')


if __name__=="__main__":unittest.main()
