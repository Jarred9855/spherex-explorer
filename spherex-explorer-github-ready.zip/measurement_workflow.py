"""Source identity and epoch-aware measurement orchestration."""
import math
import warnings
import numpy as np
import astropy.units as u
from astropy.coordinates import SkyCoord
from astropy.time import Time

import photometry


def catalogue_matches_source(catalogue,ra,dec,tolerance_arcsec=3.):
    if not catalogue or not catalogue.get("available"):return False
    try:
        predicted=SkyCoord(float(catalogue["query_ra_deg"]),float(catalogue["query_dec_deg"]),unit="deg")
        return bool(predicted.separation(SkyCoord(float(ra),float(dec),unit="deg")).arcsec<=tolerance_arcsec)
    except (TypeError,ValueError,KeyError):return False


def predicted_position(catalogue,mjd):
    """Propagate supplied catalogue proper motion; missing components stay unavailable."""
    if not catalogue or any(catalogue.get(k) is None for k in ("query_ra_deg","query_dec_deg","query_epoch_jyear","pmra_mas_per_year","pmdec_mas_per_year")):
        return None
    try:
        position=SkyCoord(ra=float(catalogue["query_ra_deg"])*u.deg,dec=float(catalogue["query_dec_deg"])*u.deg,
                pm_ra_cosdec=float(catalogue["pmra_mas_per_year"])*u.mas/u.yr,pm_dec=float(catalogue["pmdec_mas_per_year"])*u.mas/u.yr,
                obstime=Time(float(catalogue["query_epoch_jyear"]),format="jyear"))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result=position.apply_space_motion(new_obstime=Time(float(mjd),format="mjd"))
        return float(result.ra.deg),float(result.dec.deg)
    except (ValueError,TypeError,KeyError):return None


def measure_series(frames,ra,dec,catalogue=None,**settings):
    rows=[]
    follow_catalogue=catalogue_matches_source(catalogue,ra,dec)
    for frame in frames:
        prediction=predicted_position(catalogue,frame["record"]["mjd"]) if follow_catalogue else None
        at_ra,at_dec=prediction if prediction is not None else (ra,dec)
        measured=photometry.extract_series([frame],at_ra,at_dec,**settings)
        for row in measured:
            row["catalogue_position_propagated"]=prediction is not None
            row["position_prediction_source"]=catalogue.get("source_url") if prediction is not None else None
            row["selected_reference_ra_deg"]=float(ra)
            row["selected_reference_dec_deg"]=float(dec)
        rows.extend(measured)
    return rows


def reference_correction(bundle,measurement,band,max_references=6,progress=None):
    """A diagnostic ensemble correction in one matched band, never all bands together."""
    if measurement.get("imported"):return {"available":False,"reason":"Reference-image correction is not applied to an imported calibrated table."}
    if len(band)<3:return {"available":False,"reason":"At least three approximately matched-band source measurements are required."}
    urls={row.get("source_url") for row in band}
    frames=[frame for frame in bundle["frames"] if frame["record"]["url"] in urls]
    selected=SkyCoord(measurement["ra"],measurement["dec"],unit="deg")
    references=[];coordinates=[]
    for candidate in bundle["candidates"]:
        point=SkyCoord(candidate["ra_deg"],candidate["dec_deg"],unit="deg")
        if selected.separation(point).arcsec<30:continue
        if any(point.separation(other).arcsec<25 for other in coordinates):continue
        coordinates.append(point)
        references.append(photometry.extract_series(frames,point.ra.deg,point.dec.deg,
                aperture_arcsec=measurement["aperture"],annulus_inner=max(18.,measurement["aperture"]*1.5),
                annulus_outer=max(30.,measurement["aperture"]*2.5),follow_centroid=True))
        if progress:progress(len(references),max_references)
        if len(references)>=max_references:break
    result=photometry.relative_ensemble_correction(band,references)
    result["attempted_references"]=len(references)
    return result
