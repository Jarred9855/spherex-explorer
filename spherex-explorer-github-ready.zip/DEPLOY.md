# Publish on Streamlit Community Cloud

This is a Python/Streamlit application. The deployable entry point is **app.py**. It does not require a NASA API key or database credential for public archive queries.

1. Put the contents of the prepared deployment folder/ZIP into a GitHub repository. Keep app.py, requirements.txt, requirements-web.txt and all helper modules in the repository root. Include the supplied public demonstration data and data/targets evidence files.
2. Exclude .venv, backups, secrets.toml, .env, Python caches and local cutout_cache. The supplied .gitignore lists these. NASA catalogue/image data and their provenance are public; do not upload unrelated personal files.
3. Sign in to [Streamlit Community Cloud](https://share.streamlit.io/) with the GitHub account that can access this repository.
4. Select **Create app**, choose the repository and branch, and set the main file path to **app.py**.
5. In Advanced settings choose **Python3.13**, matching the development environment. No app secrets are needed for the current public-data features.
6. Select **Deploy**, wait for dependency installation and copy the resulting `https://….streamlit.app` URL.
7. Check the saved demonstration region, prepare a small time player, inspect Target validation, and open a shared coordinate URL. Live archive searches need functioning external IRSA services; deployment cannot remove an upstream outage.

Streamlit reads requirements.txt automatically; it includes requirements-web.txt. External sky-atlas data are fetched from CDS/mission services only when the user enables the atlas.

## Data and resource behaviour

- Downloaded cutouts are cached on the server filesystem. Community Cloud storage and browser-session state are not permanent research storage. Download evidence CSV/JSON before a restart.
- Start with a small sequence. The largest spectral sampling settings can download hundreds of products; they are optional and may be slow on shared hosting.
- The prepared package includes catalogue/validation provenance. A failed multi-epoch archive test is labelled failed, rather than being replaced with a coadded image and called a time sequence.
- The app keeps source measurements scoped to the selected region, dataset and measurement recipe. Catalogue inputs are linked only to the selected named target.

## Alternative Docker host

Build with `docker build -t spherex-explorer .` and run with `docker run --rm -p8501:8501 spherex-explorer`. The Dockerfile provides a health check. Docker execution has not been verified unless explicitly recorded in the validation report.

Official instructions: [Community Cloud deployment](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app), [dependency files](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/app-dependencies).
