"""Fixed-sky SPHEREx playback and explicitly diagnostic image products.

Reprojection aligns celestial WCS grids for viewing and masks known defects.
Comparisons can smooth to an approximate common Gaussian PSF and check reference
star registration. They do not replace the spatial ePSF, fit a science-grade
astrometric correction or propagate interpolation covariance. Quantitative
photometry must use native FITS images and their calibration.

Primary method: https://docs.astropy.org/projects/reproject/en/stable/api/reproject.reproject_interp.html
"""

from copy import deepcopy
from pathlib import Path
import math

import numpy as np
import astropy.units as u
from astropy.io import fits
from astropy.time import Time
from astropy.visualization import ZScaleInterval
from astropy.wcs import WCS
from photometry import quality_mask, estimate_psf_width


def _finite_float(value, default=None):
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError):
        return default


def choose_sequence_records(records, detector=None, max_frames=8):
    """Return a deterministic, time-spread subset of image records.

    Prefer distinct MJD calendar-day groups before filling extra intra-day
    exposures. Always include earliest/latest when at least two are requested.
    A detector filter does NOT establish equivalent source wavelengths.
    """
    if isinstance(max_frames, bool) or int(max_frames) != max_frames or not 1 <= int(max_frames) <= 64:
        raise ValueError("Choose between 1 and 64 sequence frames.")
    maximum = int(max_frames)
    selected_detector = None if detector in (None, "All") else str(detector)
    by_identity = {}
    for record in records:
        if selected_detector is not None and record.get("detector") != selected_detector:
            continue
        time = _finite_float(record.get("mjd"))
        if time is None:
            continue
        identity = (record.get("obs_id") or record.get("url") or time, record.get("detector"))
        previous = by_identity.get(identity)
        if previous is None or (
            record.get("collection") == "spherex_dr1"
            and previous.get("collection") != "spherex_dr1"
        ):
            by_identity[identity] = record
    ordered = sorted(by_identity.values(), key=lambda r: (float(r["mjd"]), str(r.get("detector", "")), str(r.get("obs_id", ""))))
    if len(ordered) <= maximum:
        return ordered
    if maximum == 1:
        return ordered[:1]
    selected = [0, len(ordered) - 1]
    selected_days = {math.floor(float(ordered[i]["mjd"])) for i in selected}
    remaining = set(range(1, len(ordered) - 1))
    while len(selected) < maximum and remaining:
        distinct_day = [i for i in remaining if math.floor(float(ordered[i]["mjd"])) not in selected_days]
        candidates = distinct_day or list(remaining)
        # Farthest-point time sampling favours coverage over densely repeated visits.
        winner = max(
            candidates,
            key=lambda i: (
                min(abs(float(ordered[i]["mjd"]) - float(ordered[j]["mjd"])) for j in selected),
                -float(ordered[i]["mjd"]),
                -i,
            ),
        )
        selected.append(winner)
        selected_days.add(math.floor(float(ordered[winner]["mjd"])))
        remaining.remove(winner)
    return [ordered[i] for i in sorted(selected)]


def _region_values(region):
    def read(name):
        return region[name] if isinstance(region, dict) else getattr(region, name)
    ra, dec, fov = (_finite_float(read(name)) for name in ("ra", "dec", "fov_arcmin"))
    if ra is None or not 0 <= ra < 360 or dec is None or not -90 <= dec <= 90:
        raise ValueError("The sequence requires finite, valid RA/Dec coordinates.")
    if fov is None or fov <= 0:
        raise ValueError("The sequence field size must be positive.")
    return ra, dec, fov


def make_common_grid(region, pixel_scale_arcsec=6.15, max_pixels=384):
    """Create a north-up/east-left TAN grid covering the requested square field.

    Returns a dict with header, wcs, shape, pixel_scale_arcsec and fov_arcmin.
    Pixel count is capped; larger fields use a coarser *display* scale.
    """
    ra, dec, fov = _region_values(region)
    scale = _finite_float(pixel_scale_arcsec)
    if scale is None or scale <= 0:
        raise ValueError("Display pixel scale must be positive.")
    if isinstance(max_pixels, bool) or int(max_pixels) != max_pixels or not 3 <= int(max_pixels) <= 384:
        raise ValueError("The display grid limit must be between 3 and 384 pixels.")
    size = max(3, math.ceil(fov * 60.0 / scale))
    if size > int(max_pixels):
        size = int(max_pixels)
        scale = fov * 60.0 / size
    wcs = WCS(naxis=2)
    wcs.wcs.crpix = [(size + 1.0) / 2.0, (size + 1.0) / 2.0]
    wcs.wcs.crval = [ra, dec]
    wcs.wcs.cdelt = [-scale / 3600.0, scale / 3600.0]
    wcs.wcs.ctype = ["RA---TAN", "DEC--TAN"]
    wcs.wcs.cunit = ["deg", "deg"]
    wcs.wcs.radesys = "ICRS"
    header = wcs.to_header(relax=True)
    header["NAXIS"] = 2
    header["NAXIS1"] = size
    header["NAXIS2"] = size
    return {"header": header, "wcs": wcs, "shape": (size, size),
            "pixel_scale_arcsec": scale, "fov_arcmin": fov}


def load_native_frame(frame):
    """Read native image, variance and flags without blanket nonzero-flag masking.

    Return a dict. IMAGE is canonicalized to MJy/sr if BUNIT supplies compatible
    units; VARIANCE is converted by the squared factor. These are native arrays.
    """
    path = Path(frame["path"])
    with fits.open(path, memmap=False) as hdul:
        if "IMAGE" not in hdul:
            raise ValueError("A sequence input has no IMAGE extension.")
        image = np.asarray(hdul["IMAGE"].data, dtype=float).copy()
        header = hdul["IMAGE"].header.copy()
        if image.ndim != 2 or image.size == 0 or not np.isfinite(image).any():
            raise ValueError("A sequence image has no finite two-dimensional data.")
        variance = None
        if "VARIANCE" in hdul and hdul["VARIANCE"].data is not None:
            candidate = np.asarray(hdul["VARIANCE"].data, dtype=float)
            if candidate.shape == image.shape:
                variance = candidate.copy()
        flags = None
        if "FLAGS" in hdul and hdul["FLAGS"].data is not None:
            candidate = np.asarray(hdul["FLAGS"].data)
            if candidate.shape == image.shape:
                flags = candidate.copy()
        flag_header = hdul["FLAGS"].header.copy() if flags is not None else None
        if "PSF_FWHM" not in header and "PSF_FWHM" in hdul[0].header:
            header.append(hdul[0].header.cards["PSF_FWHM"])
    factor = 1.0
    unit_text = str(header.get("BUNIT", "")).strip()
    if unit_text:
        try:
            factor = (1.0 * u.Unit(unit_text)).to_value(u.MJy / u.sr)
        except (ValueError, TypeError, u.UnitConversionError) as error:
            raise ValueError("Sequence inputs must use compatible surface-brightness units.") from error
        image *= factor
        if variance is not None:
            variance *= factor * factor
        unit_text = "MJy / sr"
    else:
        unit_text = "unspecified"
    quality = quality_mask(flags, flag_header, image.shape)
    valid_mask = np.isfinite(image) & ~quality["bad"]
    if not valid_mask.any():
        raise ValueError("The frame has no usable pixels after quality-flag masking.")
    psf = estimate_psf_width(image, header, quality["bad"])
    metadata = deepcopy(frame.get("meta") or {})
    record = frame.get("record") or {}
    metadata.update({
        "date": str(header.get("DATE-OBS", metadata.get("date") or record.get("date") or "Unknown")),
        "mjd": _finite_float(record.get("mjd")),
        "detector": str(record.get("detector", metadata.get("detector", "Unknown"))),
        "obs_id": str(record.get("obs_id", "")),
        "collection": str(record.get("collection", "")),
        "source_url": str(record.get("url", "")),
        "path": str(path),
        "frame_key": frame.get("key"),
        "record": deepcopy(record),
        "meta": deepcopy(frame.get("meta") or {}),
        "frame": deepcopy(frame),
        "unit": unit_text,
        "native_shape": tuple(image.shape),
        "flags_available": flags is not None,
        "variance_available": variance is not None,
        "quality_mask_applied": True,
        "quality_flags_known": quality["known"],
        "bad_native_fraction": float(np.mean(quality["bad"])),
        "psf_fwhm_arcsec": psf["fwhm_arcsec"],
        "psf_method": psf["method"],
        "psf_approximate": True,
        "psf_stars": psf["n_stars"],
    })
    if metadata["mjd"] is None and metadata["date"] != "Unknown":
        try:
            metadata["mjd"] = float(Time(metadata["date"]).mjd)
        except (ValueError, TypeError):
            pass
    positive = variance[np.isfinite(variance) & (variance > 0) & valid_mask] if variance is not None else np.array([])
    metadata["median_native_variance"] = float(np.median(positive)) if positive.size else None
    return {"image": image, "variance": variance, "flags": flags,
            "header": header, "metadata": metadata, "valid_mask": valid_mask,
            "quality_mask": quality["bad"], "source_mask": quality["source"]}


def shared_stretch_limits(images, sample_limit=200000):
    """Compute one deterministic display range for an entire sequence."""
    if isinstance(sample_limit, bool) or int(sample_limit) != sample_limit or sample_limit < 2:
        raise ValueError("Display sampling needs an integer limit of at least two.")
    array = np.asarray(images)
    flat = array.reshape(-1)
    stride = max(1, math.ceil(flat.size / int(sample_limit)))
    sample = flat[::stride]
    finite = sample[np.isfinite(sample)]
    if finite.size < 2:
        finite = flat[np.isfinite(flat)]
    if finite.size == 0:
        raise ValueError("No valid sky coverage is available in the aligned sequence.")
    low, high = ZScaleInterval().get_limits(finite)
    if not (np.isfinite(low) and np.isfinite(high)):
        low, high = np.nanmin(finite), np.nanmax(finite)
    if high <= low:
        high = low + max(abs(float(low)) * 1e-6, 1.0)
    return float(low), float(high)


def wavelength_compatibility(metadata, relative_tolerance=0.02, bandwidth_ratio_limit=1.25):
    """Check approximate centre/bandwidth agreement for diagnostic comparisons.

    This is not a full response-function match or a precision-photometry test.
    Centre differences must be within both the fractional tolerance and half the
    narrower bandwidth. A detector name alone is never accepted as a match.
    """
    if not 0 < float(relative_tolerance) <= 0.2 or float(bandwidth_ratio_limit) < 1:
        raise ValueError("Choose a positive wavelength tolerance and bandwidth ratio >= 1.")
    wavelengths = [_finite_float(m.get("wavelength_um")) for m in metadata]
    widths = [_finite_float(m.get("bandwidth_um")) for m in metadata]
    if not metadata or any(w is None or w <= 0 for w in wavelengths + widths):
        return {"compatible": False, "reason": "Wavelength or bandwidth information is missing.",
                "relative_tolerance": float(relative_tolerance), "reference_um": None}
    compatible = True
    for i in range(len(wavelengths)):
        for j in range(i + 1, len(wavelengths)):
            mean_wave = (wavelengths[i] + wavelengths[j]) / 2.0
            tolerance = min(float(relative_tolerance) * mean_wave, 0.5 * min(widths[i], widths[j]))
            if abs(wavelengths[i] - wavelengths[j]) > tolerance or max(widths[i], widths[j]) / min(widths[i], widths[j]) > bandwidth_ratio_limit:
                compatible = False
    reason = ("Approximate centre/bandwidth match for preview only; responses and PSFs are not matched."
              if compatible else "The measured wavelength centres or bandwidths differ too much for this preview comparison.")
    return {"compatible": compatible, "reason": reason,
            "relative_tolerance": float(relative_tolerance),
            "reference_um": float(np.median(wavelengths))}


def align_sequence(frames, region, pixel_scale_arcsec=6.15, max_pixels=384,
                   skip_failed=False, on_progress=None):
    """Reproject images onto one north-up, east-left celestial display grid.

    Frame dictionaries follow data_access.download_cutout's output shape. Output
    images/footprints have shape (n_frames, ny, nx), ordered by observation time.
    Missing or invalid coverage remains NaN in images and zero in footprints.
    The header describes the *common* grid. No aligned science-variance map is
    fabricated: interpolation creates covariance and requires special treatment.
    """
    if not frames or len(frames) > 64:
        raise ValueError("Provide between 1 and 64 downloaded frames.")
    from reproject import reproject_interp

    grid = make_common_grid(region, pixel_scale_arcsec, max_pixels)
    projected, footprints, metadata, errors = [], [], [], []
    units = set()
    for i, frame in enumerate(frames):
        try:
            native = load_native_frame(frame)
            source_wcs = WCS(native["header"]).celestial
            result, footprint = reproject_interp(
                (np.where(native["valid_mask"], native["image"], np.nan), source_wcs), grid["wcs"],
                shape_out=grid["shape"], order="bilinear",
                roundtrip_coords=True, return_footprint=True, parallel=False,
            )
            support, _ = reproject_interp(
                (native["valid_mask"].astype(float), source_wcs), grid["wcs"],
                shape_out=grid["shape"], order="bilinear", roundtrip_coords=True,
                return_footprint=True, parallel=False,
            )
            valid = np.isfinite(result) & np.isfinite(footprint) & (footprint > 0)
            valid &= np.isfinite(support) & (support >= .999999)
            if not valid.any():
                raise ValueError("This image has no valid coverage on the requested grid.")
            result = np.where(valid, result, np.nan).astype(np.float32)
            footprint = np.where(valid, np.clip(footprint, 0, 1), 0).astype(np.float32)
            projected.append(result)
            footprints.append(footprint)
            meta = native["metadata"]
            meta["coverage_fraction"] = float(np.mean(valid))
            metadata.append(meta)
            units.add(meta["unit"])
        except (OSError, ValueError, KeyError, TypeError) as error:
            if not skip_failed:
                raise
            errors.append({"input_index": i, "path": str(frame.get("path", "")), "message": str(error)})
        if on_progress is not None:
            on_progress(i + 1, len(frames))
    if not projected:
        raise ValueError("No sequence frames could be aligned.")
    if len(units) != 1:
        raise ValueError("Do not combine images with specified and unspecified brightness units.")
    order = sorted(range(len(metadata)), key=lambda i: (metadata[i]["mjd"] is None, metadata[i]["mjd"] or 0, i))
    images = np.stack([projected[i] for i in order])
    footprint_stack = np.stack([footprints[i] for i in order])
    metadata = [metadata[i] for i in order]
    limits = shared_stretch_limits(images)
    compatibility = wavelength_compatibility(metadata)
    registration = registration_diagnostics(images, footprint_stack)
    for item, diagnostic in zip(metadata, registration["frames"]):
        item["registration"] = diagnostic
    warnings = [
        "Playback uses a fixed sky grid and one shared display stretch. It is not an astrometric motion measurement.",
        "Image interpolation is for viewing; use the native images for quantitative photometry and uncertainties.",
        "Known artifact/defect flags are masked; SOURCE and FULLSAMPLE are retained. Missing flags cannot establish clean data.",
        "PSF changes, wavelength differences and uncorrected astrometric offsets can mimic image changes.",
    ]
    if not compatibility["compatible"]:
        warnings.append(compatibility["reason"])
    header = grid["header"].copy()
    if next(iter(units)) != "unspecified":
        header["BUNIT"] = next(iter(units))
    return {"images": images, "footprints": footprint_stack, "header": header,
            "metadata": metadata, "sharedlimits": limits,
            "pixel_scale_arcsec": grid["pixel_scale_arcsec"],
            "shape": grid["shape"], "compatibility": compatibility,
            "registration": registration,
            "warnings": warnings, "errors": errors, "diagnostic_only": True}


def _indices(sequence, indices=None):
    count = len(sequence["images"])
    result = list(range(count)) if indices is None else list(indices)
    if not result or len(set(result)) != len(result) or any(isinstance(i, bool) or int(i) != i or not 0 <= int(i) < count for i in result):
        raise ValueError("Choose valid, nonrepeated frame indices.")
    return [int(i) for i in result]


def _registration_peaks(image, valid, limit=50):
    from scipy.ndimage import maximum_filter, binary_erosion
    from astropy.stats import sigma_clipped_stats
    safe = binary_erosion(valid, iterations=3, border_value=0)
    if safe.sum() < 30:
        return np.empty((0, 2))
    _, median, noise = sigma_clipped_stats(image[valid], sigma=3, maxiters=5)
    noise = max(float(noise), abs(float(median))*1e-10, 1e-12)
    excess = np.where(valid, image-float(median), -np.inf)
    peak = (excess == maximum_filter(excess, size=3, mode="constant", cval=-np.inf))
    py, px = np.nonzero(peak & safe & (excess > 5*noise))
    indices = np.argsort(excess[py, px])[::-1]
    points = []
    for number in indices:
        x, y = int(px[number]), int(py[number])
        patch = image[y-2:y+3, x-2:x+3]-float(median)
        weight = np.maximum(patch, 0)
        total = weight.sum()
        if total <= 0:
            continue
        yy, xx = np.indices(patch.shape)
        cx = float((xx*weight).sum()/total + x-2)
        cy = float((yy*weight).sum()/total + y-2)
        if any(np.hypot(cx-previous[0], cy-previous[1]) < 3 for previous in points):
            continue
        points.append((cx,cy))
        if len(points) >= limit:
            break
    return np.asarray(points, dtype=float).reshape(-1, 2)


def registration_diagnostics(images, footprints=None, max_offset_pixels=.75,
                             max_scatter_pixels=.35, match_radius_pixels=4.0,
                             min_references=3):
    """Estimate common residual star offsets after WCS alignment; apply no shift.

    Assumes most matched local maxima are stationary, isolated field sources.
    A robust translation diagnostic cannot replace external astrometric fitting.
    """
    arrays = np.asarray(images, dtype=float)
    if arrays.ndim != 3 or not len(arrays):
        raise ValueError("Registration diagnostics need a nonempty image cube.")
    valid = np.isfinite(arrays)
    if footprints is not None:
        valid &= np.asarray(footprints) > 0
    peaks = [_registration_peaks(image, mask) for image,mask in zip(arrays,valid)]
    reference = peaks[0]
    output = []
    for index, current in enumerate(peaks):
        empty = {"index": index, "available": False, "reliable": False,
                 "matched_sources": 0, "dx_pixels": None, "dy_pixels": None,
                 "shift_pixels": None, "scatter_pixels": None,
                 "reason": "Too few isolated reference peaks for a registration check."}
        if len(reference) < min_references or len(current) < min_references:
            output.append(empty)
            continue
        distances = np.linalg.norm(current[:,None,:]-reference[None,:,:],axis=2)
        pairs = sorted((float(distances[i,j]),i,j) for i in range(len(current))
                       for j in range(len(reference)) if distances[i,j] <= match_radius_pixels)
        used_current,used_reference,deltas = set(),set(),[]
        for _,i,j in pairs:
            if i not in used_current and j not in used_reference:
                deltas.append(current[i]-reference[j])
                used_current.add(i); used_reference.add(j)
        if len(deltas) < min_references:
            output.append(empty)
            continue
        deltas = np.asarray(deltas)
        median = np.median(deltas,axis=0)
        residual = np.linalg.norm(deltas-median,axis=1)
        robust_scale = 1.4826*np.median(np.abs(residual-np.median(residual)))
        keep = residual <= max(.25,3*float(robust_scale))
        if keep.sum() < min_references:
            output.append(dict(empty,matched_sources=int(keep.sum())))
            continue
        deltas = deltas[keep]
        median = np.median(deltas,axis=0)
        scatter = float(np.sqrt(np.mean(np.sum((deltas-median)**2,axis=1))))
        shift = float(np.hypot(*median))
        reliable = shift <= max_offset_pixels and scatter <= max_scatter_pixels
        output.append(dict(empty,available=True,reliable=reliable,
                           matched_sources=len(deltas), dx_pixels=float(median[0]),
                           dy_pixels=float(median[1]),shift_pixels=shift,
                           scatter_pixels=scatter,
                           reason="Residual field-star translation is small." if reliable else "Residual field-star offset/scatter is too large for a reliable comparison."))
    return {"reference_index":0,"frames":output,"max_offset_pixels":max_offset_pixels,
            "max_scatter_pixels":max_scatter_pixels,
            "method":"Robust matched-peak translation check; no measured shift is applied.",
            "diagnostic_only":True}


def gaussian_match_image(image, valid, sigma_pixels):
    """Normalized Gaussian smoothing with full-support masks.

    The unit-sum kernel preserves interior integrated signal on a fixed grid.
    Pixels near holes/edges are withheld instead of filling missing data. Global
    flux conservation is not claimed when source light overlaps these masks.
    """
    from scipy.ndimage import gaussian_filter
    sigma = _finite_float(sigma_pixels)
    if sigma is None or not 0 <= sigma <= 12:
        raise ValueError("Approximate Gaussian smoothing must use 0-12 pixels sigma.")
    image = np.asarray(image,dtype=float)
    valid = np.asarray(valid,bool) & np.isfinite(image)
    if sigma < 1e-4:
        return np.where(valid,image,np.nan),valid.copy()
    support = gaussian_filter(valid.astype(float),sigma,mode="constant",cval=0,truncate=4)
    blurred = gaussian_filter(np.where(valid,image,0),sigma,mode="constant",cval=0,truncate=4)
    complete = valid & (support >= 1-1e-6)
    result = np.full(image.shape,np.nan)
    np.divide(blurred,support,out=result,where=complete)
    return result,complete


def prepare_comparison(sequence, indices, match_psf=True, require_registration=True):
    """Prepare masked, approximately PSF-matched diagnostic image products."""
    chosen = _indices(sequence, indices)
    metadata = [sequence["metadata"][i] for i in chosen]
    images = np.asarray(sequence["images"],float)[chosen].copy()
    valid = np.isfinite(images) & (np.asarray(sequence["footprints"])[chosen]>0)
    warnings = []
    if not all(m.get("quality_mask_applied") for m in metadata):
        warnings.append("Quality masking was not verified for every input; rebuild the sequence before interpreting residuals.")
    fwhm = [_finite_float(m.get("psf_fwhm_arcsec")) for m in metadata]
    matching = {"applied":False,"approximate":True,"target_fwhm_arcsec":None,
                "kernel_sigma_pixels":[0.0]*len(chosen),"method":"No PSF matching requested."}
    if match_psf:
        scale = _finite_float(sequence.get("pixel_scale_arcsec"))
        if scale is None or scale <= 0 or any(v is None or v<=0 for v in fwhm):
            raise ValueError("A PSF width is unavailable. Rebuild with usable PSF metadata or use an explicitly unmatched diagnostic preview.")
        target = max(fwhm)
        sigmas = [math.sqrt(max(target*target-v*v,0))/(2.354820045*scale) for v in fwhm]
        matched,masked = [],[]
        for image,mask,sigma in zip(images,valid,sigmas):
            array,support = gaussian_match_image(image,mask,sigma)
            matched.append(array); masked.append(support)
        images,valid = np.stack(matched),np.stack(masked)
        matching.update(applied=True,target_fwhm_arcsec=target,kernel_sigma_pixels=sigmas,
                        method="Circular Gaussian smoothing to the widest supplied FWHM; not a spatial ePSF match.")
        warnings.append("Median/circular PSF matching omits PSF asymmetry, spatial variation and interpolation broadening.")
    else:
        warnings.append("The input PSFs are not matched; shape changes can dominate the residual.")
    diagnostics = registration_diagnostics(images,valid)
    if require_registration and len(chosen)>1 and not all(d["available"] and d["reliable"] for d in diagnostics["frames"]):
        raise ValueError("Registration could not be validated from at least three consistent field sources, or residual offsets are too large. Use a larger field or an explicitly unchecked diagnostic preview.")
    if not require_registration:
        warnings.append("Registration checks are reported but not enforced.")
    return {"images":images,"valid":valid,"metadata":metadata,"indices":chosen,
            "psf_matching":matching,"registration":diagnostics,"warnings":warnings}


def preview_stack(sequence, indices=None, weights=None, require_compatible=True,
                  match_psf=True, require_registration=True, clip_sigma=4.0):
    """Return an inverse-variance-weighted *display* stack, without error bars.

    By default each frame receives inverse median native-pixel variance, where
    available. This is a scalar diagnostic weight, not a per-pixel covariance
    propagation. Missing pixels never enter the denominator as zeros.
    """
    chosen = _indices(sequence, indices)
    metadata = [sequence["metadata"][i] for i in chosen]
    compatibility = wavelength_compatibility(metadata)
    if require_compatible and not compatibility["compatible"]:
        raise ValueError(compatibility["reason"])
    prepared = prepare_comparison(sequence,chosen,match_psf,require_registration)
    if weights is None:
        variances = [_finite_float(m.get("median_native_variance")) for m in metadata]
        if all(v is not None and v > 0 for v in variances):
            weight = 1.0 / np.asarray(variances, dtype=float)
            weight_kind = "inverse median native-pixel variance (diagnostic scalar weights)"
        else:
            weight = np.ones(len(chosen), dtype=float)
            weight_kind = "equal weights; native variances incomplete"
    else:
        weight = np.asarray(weights, dtype=float)
        if weight.shape != (len(chosen),) or not np.all(np.isfinite(weight)) or np.any(weight <= 0):
            raise ValueError("Supply one finite positive weight per chosen frame.")
        weight_kind = "supplied scalar frame weights"
    weight = weight / np.max(weight)
    images,valid = prepared["images"],prepared["valid"]
    rejected = np.zeros(images.shape,bool)
    if clip_sigma is not None and len(chosen)>=3:
        threshold = _finite_float(clip_sigma)
        if threshold is None or threshold<2:
            raise ValueError("Robust clipping needs a threshold of at least 2 sigma.")
        for _ in range(2):
            with np.errstate(invalid="ignore"):
                cube = np.ma.array(images,mask=~valid)
                median = np.ma.median(cube,axis=0).filled(np.nan)
                mad = np.ma.median(np.ma.abs(cube-median),axis=0).filled(np.nan)*1.4826
            variances = [_finite_float(m.get("median_native_variance")) for m in metadata]
            usable_variances = [v for v in variances if v is not None and v>0]
            floor = math.sqrt(float(np.median(usable_variances))) if usable_variances else np.finfo(float).eps
            noise = np.maximum(mad,floor)
            outlier = valid & (np.sum(valid,axis=0)>=3) & (np.abs(images-median)>threshold*noise)
            rejected |= outlier
            valid &= ~outlier
    weights_per_pixel = np.where(valid, weight[:, None, None], 0.0)
    denominator = np.sum(weights_per_pixel, axis=0)
    numerator = np.sum(np.where(valid, images, 0.0) * weight[:, None, None], axis=0)
    result = np.full(images.shape[1:], np.nan, dtype=float)
    np.divide(numerator, denominator, out=result, where=denominator > 0)
    return {"image": result, "coverage": denominator > 0,
            "count": np.sum(valid, axis=0), "weights": weight,
            "weight_kind": weight_kind, "indices": chosen,
            "compatibility": compatibility, "diagnostic_only": True,
            "psf_matching":prepared["psf_matching"],"registration":prepared["registration"],
            "rejected_count":np.sum(rejected,axis=0),
            "warnings":prepared["warnings"],
            "note": "Quality-masked diagnostic stack. " + prepared["psf_matching"]["method"] + " Robust clipping can remove real variability. Interpolation/convolution covariance and science uncertainties are not propagated."}


def preview_difference(sequence, first=0, second=-1, scale=1.0,
                       subtract_background=True, require_compatible=True,
                       match_psf=True, require_registration=True):
    """Return a quality-masked, approximately PSF-matched diagnostic residual."""
    count = len(sequence["images"])
    first, second = int(first), int(second)
    first = first + count if first < 0 else first
    second = second + count if second < 0 else second
    chosen = _indices(sequence, [first, second])
    compatibility = wavelength_compatibility([sequence["metadata"][i] for i in chosen])
    if require_compatible and not compatibility["compatible"]:
        raise ValueError(compatibility["reason"])
    prepared = prepare_comparison(sequence,chosen,match_psf,require_registration)
    scale = _finite_float(scale)
    if scale is None or scale <= 0:
        raise ValueError("The brightness scale must be finite and positive.")
    image1,image2 = prepared["images"]
    overlap = prepared["valid"][0] & prepared["valid"][1]
    if not overlap.any():
        raise ValueError("The chosen images have no common valid coverage.")
    background1 = float(np.median(image1[overlap])) if subtract_background else 0.0
    background2 = float(np.median(image2[overlap])) if subtract_background else 0.0
    difference = np.full(image1.shape, np.nan, dtype=float)
    difference[overlap] = (image2[overlap] - background2) - scale * (image1[overlap] - background1)
    return {"image": difference, "coverage": overlap, "indices": chosen,
            "backgrounds": (background1, background2), "scale": scale,
            "compatibility": compatibility, "diagnostic_only": True,
            "psf_matching":prepared["psf_matching"],"registration":prepared["registration"],
            "warnings":prepared["warnings"],
            "note": "Diagnostic residual with quality/common-coverage masks. " + prepared["psf_matching"]["method"] + " No astrometric correction or science covariance propagation is applied. Residuals are not confirmed variability or motion."}
