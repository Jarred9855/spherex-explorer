"""Additional evidence graphs and guarded, supplied-data astrometric models.

The native-image centroids in this prototype are not calibrated astrometry.
They are never used automatically for the five-parameter parallax fit below.
The fit requires separate, externally calibrated/reference-corrected positions
and explicit provenance. Its Earth-centre model is not a precision Gaia pipeline.
"""

from io import StringIO
import csv
import math

import numpy as np
import astropy.units as u
from astropy.coordinates import get_body_barycentric
from astropy.time import Time
from astropy.constants import c

import physics


def _unavailable(reason, **extra):
    return dict(available=False, reason=reason, **extra)


def _number(value):
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


def _arrays(*values):
    if any(value is None for value in values):
        return None
    try:
        arrays = [np.asarray(value, dtype=float).reshape(-1) for value in values]
    except (TypeError, ValueError):
        return None
    if not arrays or any(array.shape != arrays[0].shape for array in arrays):
        return None
    return arrays


def shared_reference_differences(mjd, flux, errors, reference_index=0, covariance=None):
    """Differences in the flux input unit, including shared-reference covariance.

    Input covariance, when supplied, is an N by N covariance of original fluxes.
    The default assumes independent original measurements. The reference point
    has an identically zero difference and zero error, not an extra measurement.
    """
    arrays = _arrays(mjd, flux, errors)
    if arrays is None:
        return _unavailable("Supply matching time, flux and uncertainty arrays.")
    time, values, sigma = arrays
    n = len(time)
    if n < 2 or not np.isfinite(np.concatenate(arrays)).all() or np.any(sigma <= 0):
        return _unavailable("At least two finite fluxes with positive uncertainties are required.")
    parsed_reference = _number(reference_index)
    if isinstance(reference_index, bool) or parsed_reference is None or int(parsed_reference) != parsed_reference or not 0 <= int(parsed_reference) < n:
        return _unavailable("Choose a valid reference observation.")
    reference = int(reference_index)
    if covariance is None:
        original_covariance = np.diag(sigma**2)
    else:
        try:
            original_covariance = np.asarray(covariance, dtype=float)
        except (TypeError, ValueError):
            return _unavailable("The flux covariance must be a numeric square matrix.")
        if original_covariance.shape != (n, n) or not np.isfinite(original_covariance).all():
            return _unavailable("The flux covariance must match all observations.")
        if not np.allclose(original_covariance, original_covariance.T, rtol=1e-9, atol=1e-12):
            return _unavailable("The flux covariance must be symmetric.")
        if not np.allclose(np.diag(original_covariance), sigma**2, rtol=1e-6, atol=1e-12):
            return _unavailable("Covariance diagonal and supplied flux errors must agree.")
        tolerance = max(float(np.max(np.abs(original_covariance))), 1e-30) * 1e-10
        if np.min(np.linalg.eigvalsh(original_covariance)) < -tolerance:
            return _unavailable("The flux covariance is not positive semidefinite.")
    transform = np.eye(n)
    transform[:, reference] -= 1.0
    differences = transform @ values
    difference_covariance = transform @ original_covariance @ transform.T
    difference_sigma = np.sqrt(np.maximum(np.diag(difference_covariance), 0))
    scores = np.full(n, np.nan)
    np.divide(differences, difference_sigma, out=scores, where=difference_sigma > 0)
    return dict(available=True, mjd=time, delta_flux=differences,
                delta_flux_error=difference_sigma, covariance=difference_covariance,
                change_score=scores, reference_index=reference,
                warning="All differences share the reference observation. Error bars show marginal errors; the nonreference points are correlated. Instrumental systematics are additional.")


def fnu_to_flambda(wavelength_um, flux_ujy, errors_ujy=None):
    """Convert microJy to W m^-2 micrometre^-1; negative noisy flux is allowed."""
    values = _arrays(wavelength_um, flux_ujy)
    if values is None:
        return _unavailable("Supply matching wavelength and flux-density arrays.")
    wavelength, flux = values
    if len(wavelength) == 0 or not np.isfinite(np.concatenate(values)).all() or np.any(wavelength <= 0):
        return _unavailable("Wavelengths must be positive and all values finite.")
    errors = None
    if errors_ujy is not None:
        parsed = _arrays(wavelength, errors_ujy)
        if parsed is None or not np.isfinite(parsed[1]).all() or np.any(parsed[1] < 0):
            return _unavailable("Flux uncertainties must be finite, nonnegative and match the wavelengths.")
        errors = parsed[1]
    factor = c.value * 1e-26 / wavelength**2
    return dict(available=True, wavelength_um=wavelength,
                flambda_w_m2_um=flux * factor,
                flambda_error_w_m2_um=None if errors is None else errors * factor,
                factor=factor, unit="W m^-2 micrometre^-1")


def earth_parallax_factors(ra_deg, dec_deg, mjd):
    """Dimensionless east/north factors from builtin Earth barycentric position.

    Input times are UTC MJD. A parallax in arcseconds multiplied by a factor
    gives a tangent-plane angular offset in arcseconds. Telescope displacement,
    aberration, light deflection and perspective acceleration are not modelled.
    """
    ra, dec = _number(ra_deg), _number(dec_deg)
    arrays = _arrays(mjd)
    if ra is None or dec is None or not -90 <= dec <= 90 or arrays is None:
        return _unavailable("Supply finite source coordinates and MJD times.")
    times = arrays[0]
    if not len(times) or not np.isfinite(times).all():
        return _unavailable("Parallax factors require finite observing times.")
    try:
        earth = get_body_barycentric("earth", Time(times, format="mjd", scale="utc"), ephemeris="builtin")
        X, Y, Z = np.asarray(earth.xyz.to_value(u.au), dtype=float)
    except (ValueError, RuntimeError, OverflowError):
        return _unavailable("The builtin ephemeris cannot evaluate these dates.")
    alpha, delta = np.deg2rad([ra % 360, dec])
    return dict(available=True, mjd=times,
                east=X*np.sin(alpha)-Y*np.cos(alpha),
                north=X*np.cos(alpha)*np.sin(delta)+Y*np.sin(alpha)*np.sin(delta)-Z*np.cos(delta),
                observer="Earth centre; builtin barycentric ephemeris")


def fit_five_parameter_astrometry(mjd, x_arcsec, y_arcsec, sigma_x_arcsec,
                                  sigma_y_arcsec, ra_deg, dec_deg,
                                  covariance_xy_arcsec2=None, *, calibrated=False,
                                  reference_corrected=False, calibration_reference="",
                                  solution_kind="relative", absolute_reference="",
                                  minimum_baseline_days=365.25,
                                  maximum_condition=1e6, minimum_distance_snr=10.0):
    """Weighted [x0,y0,mu_east,mu_north,parallax] fit with guarded interpretation.

    Offsets and per-epoch errors are arcseconds, times UTC MJD. Inputs must be
    externally calibrated and corrected against a stable reference frame, not
    this app's raw image moments. Optional per-epoch east/north covariance is in
    arcsec^2. Cross-epoch correlations must already be included in an external
    solution; this prototype cannot ingest a full 2N by 2N covariance.

    Relative parallax is reported as relative. Distance is gated to a declared
    absolute zero point, positive high-SNR parallax and an acceptable model fit.
    """
    if not calibrated or not reference_corrected or not isinstance(calibration_reference,str) or not calibration_reference.strip():
        return _unavailable("Upload calibrated, reference-corrected astrometry and document its calibration. Preliminary image centroids are not eligible for a new parallax fit.")
    if solution_kind not in {"relative", "absolute"}:
        return _unavailable("Declare a relative or absolute astrometric reference.")
    if solution_kind == "absolute" and (not isinstance(absolute_reference,str) or not absolute_reference.strip()):
        return _unavailable("An absolute solution needs the external zero-point/reference provenance.")
    limits = [_number(v) for v in (minimum_baseline_days,maximum_condition,minimum_distance_snr)]
    if any(v is None or v <= 0 for v in limits):
        return _unavailable("Fit safeguards require positive finite baseline, condition and signal-to-noise limits.")
    arrays = _arrays(mjd, x_arcsec, y_arcsec, sigma_x_arcsec, sigma_y_arcsec)
    if arrays is None:
        return _unavailable("Times, positions and coordinate uncertainties must be matching arrays.")
    time, x, y, sx, sy = arrays
    n = len(time)
    if n < 8 or len(np.unique(time)) < 8:
        return _unavailable("This prototype requires at least eight distinct calibrated observing epochs for a five-parameter fit.")
    if not np.isfinite(np.concatenate(arrays)).all() or np.any(sx <= 0) or np.any(sy <= 0):
        return _unavailable("All positions must be finite and coordinate uncertainties strictly positive.")
    order = np.argsort(time, kind="stable")
    time, x, y, sx, sy = (a[order] for a in arrays)
    baseline = float(time[-1]-time[0])
    if baseline < minimum_baseline_days:
        return _unavailable("A baseline of at least one year is required to separate annual parallax and proper motion.", baseline_days=baseline)
    phases = np.sort(np.unique(np.mod((time-time[0])/365.25, 1.0)))
    gaps = np.diff(np.r_[phases, phases[0]+1.0])
    if float(np.max(gaps)) > .85:
        return _unavailable("The observations occupy too narrow an annual phase range for this prototype's parallax fit.")
    factors = earth_parallax_factors(ra_deg, dec_deg, time)
    if not factors["available"]:
        return factors
    covxy = np.zeros(n)
    if covariance_xy_arcsec2 is not None:
        parsed = _arrays(mjd, covariance_xy_arcsec2)
        if parsed is None or not np.isfinite(parsed[1]).all():
            return _unavailable("Per-epoch coordinate covariances must be finite and match the observations.")
        covxy = parsed[1][order]
    if np.any(np.abs(covxy) >= sx*sy):
        return _unavailable("Each east/north covariance block must be positive definite.")
    with np.errstate(over="ignore",under="ignore"):
        total_variance=sx*sx+sy*sy
    if not np.isfinite(total_variance).all() or np.any(total_variance<=0):
        return _unavailable("The coordinate uncertainties are outside a numerically usable range.")
    t0 = float(np.average(time, weights=1/total_variance))
    years = (time-t0)/365.25
    design = np.zeros((2*n,5))
    observed = np.column_stack([x,y]).reshape(-1)
    design[0::2,0] = 1
    design[1::2,1] = 1
    design[0::2,2] = years
    design[1::2,3] = years
    design[0::2,4] = factors["east"]
    design[1::2,4] = factors["north"]
    weighted_design, weighted_observed = [], []
    for i in range(n):
        block = np.array([[sx[i]**2,covxy[i]],[covxy[i],sy[i]**2]])
        try:
            chol = np.linalg.cholesky(block)
            weighted_design.append(np.linalg.solve(chol,design[2*i:2*i+2]))
            weighted_observed.append(np.linalg.solve(chol,observed[2*i:2*i+2]))
        except np.linalg.LinAlgError:
            return _unavailable("The supplied coordinate covariance cannot be whitened.")
    A = np.vstack(weighted_design)
    b = np.concatenate(weighted_observed)
    scale = np.linalg.norm(A,axis=0)
    if np.any(scale <= 0):
        return _unavailable("The samples do not constrain every astrometric parameter.")
    normalised = A/scale
    try:
        _, singular, vh = np.linalg.svd(normalised,full_matrices=False)
        rank = int(np.count_nonzero(singular > singular[0]*1e-10))
        condition = float(singular[0]/singular[-1]) if singular[-1] > 0 else math.inf
        if rank < 5 or condition > maximum_condition:
            return _unavailable("Parallax and proper motion are degenerate or poorly conditioned for these epochs.", rank=rank,condition=condition)
        scaled_parameters = np.linalg.lstsq(normalised,b,rcond=None)[0]
        parameters = scaled_parameters/scale
        covariance = ((vh.T * (1/singular**2)) @ vh) / np.outer(scale,scale)
    except np.linalg.LinAlgError:
        return _unavailable("A stable weighted astrometric fit could not be computed.")
    model = (design@parameters).reshape(n,2)
    residual = np.column_stack([x,y])-model
    chi2 = float(np.sum((b-A@parameters)**2))
    dof = 2*n-5
    reduced = chi2/dof
    errors = np.sqrt(np.maximum(np.diag(covariance),0))
    dense_time=np.linspace(time[0],time[-1],min(2048,max(256,int(baseline)+1)))
    dense_factors=earth_parallax_factors(ra_deg,dec_deg,dense_time)
    dense_years=(dense_time-t0)/365.25
    dense_x=parameters[0]+parameters[2]*dense_years+parameters[4]*dense_factors["east"]
    dense_y=parameters[1]+parameters[3]*dense_years+parameters[4]*dense_factors["north"]
    parallax_mas = float(parameters[4]*1000)
    parallax_error = float(errors[4]*1000)
    snr = parallax_mas/parallax_error if parallax_error > 0 else math.nan
    acceptable = bool(math.isfinite(reduced) and reduced <= 5)
    distance = None
    if solution_kind != "absolute":
        distance_reason = "This is a relative parallax. An independently established absolute zero point is required for distance."
    elif not acceptable:
        distance_reason = "Residuals are too large compared with the supplied errors for this simple model; distance is withheld."
    elif parallax_mas <= 0 or not math.isfinite(snr) or snr < minimum_distance_snr:
        distance_reason = "The fitted parallax is negative, zero or too uncertain for reciprocal distance; use uncertainty-aware inference."
    else:
        candidate = physics.distance_from_parallax(parallax_mas,parallax_error,min_snr=minimum_distance_snr)
        if candidate["available"]:
            distance = candidate
            distance_reason = "Approximate distance from a positive high-SNR, externally absolute-referenced fit."
        else:
            distance_reason = candidate["reason"]
    return dict(available=True,kind=f"{solution_kind} five-parameter fit",solution_kind=solution_kind,
                calibration_reference=str(calibration_reference),absolute_reference=str(absolute_reference),
                reference_mjd=t0,mjd=time,x_arcsec=x,y_arcsec=y,sigma_x_arcsec=sx,sigma_y_arcsec=sy,
                model_x_arcsec=model[:,0],model_y_arcsec=model[:,1],
                model_mjd=dense_time,dense_model_x_arcsec=dense_x,dense_model_y_arcsec=dense_y,
                residual_x_arcsec=residual[:,0],residual_y_arcsec=residual[:,1],
                parameters=parameters,covariance=covariance,parameter_errors=errors,
                mu_x_mas_per_year=float(parameters[2]*1000),mu_y_mas_per_year=float(parameters[3]*1000),
                mu_x_error_mas_per_year=float(errors[2]*1000),mu_y_error_mas_per_year=float(errors[3]*1000),
                parallax_mas=parallax_mas,parallax_error_mas=parallax_error,parallax_snr=snr,
                rank=rank,condition=condition,chi2=chi2,degrees_of_freedom=dof,reduced_chi2=reduced,
                fit_acceptable=acceptable,distance_available=distance is not None,distance=distance,
                distance_reason=distance_reason,east_parallax_factor=factors["east"],north_parallax_factor=factors["north"],
                warning="Formal errors follow the supplied per-epoch covariance; cross-epoch and calibration systematics are not added. The Earth-centre approximation omits telescope displacement and precision apparent-position effects. A fitted annual component alone is not proof of physical parallax.")


def _csv_rows(content, required, max_rows=20000):
    try:
        text = content.decode("utf-8-sig") if isinstance(content,(bytes,bytearray)) else str(content)
    except UnicodeError:
        return _unavailable("Upload a UTF-8 CSV file.")
    if len(text) > 2_000_000:
        return _unavailable("Keep the CSV smaller than 2 MB.")
    reader = csv.DictReader(StringIO(text))
    if reader.fieldnames is None:
        return _unavailable("The CSV needs a header row.")
    missing = set(required).difference(reader.fieldnames)
    if missing:
        return _unavailable("Missing CSV columns: "+", ".join(sorted(missing)))
    rows = []
    try:
        for line,row in enumerate(reader,2):
            if len(rows) >= max_rows:
                return _unavailable(f"The CSV exceeds {max_rows} rows.")
            values = {name:float(row[name]) for name in required}
            if not all(math.isfinite(value) for value in values.values()):
                return _unavailable(f"CSV line {line} contains nonfinite values.")
            if row.get("covariance_xy_arcsec2", "").strip():
                values["covariance_xy_arcsec2"] = float(row["covariance_xy_arcsec2"])
                if not math.isfinite(values["covariance_xy_arcsec2"]):
                    return _unavailable(f"CSV line {line} contains an invalid covariance.")
            rows.append(values)
    except (TypeError,ValueError,KeyError,csv.Error):
        return _unavailable("CSV numeric fields could not be read. Use decimal numbers and the stated units.")
    if not rows:
        return _unavailable("The CSV has no measurement rows.")
    return dict(available=True,rows=rows)


def parse_calibrated_astrometry_csv(content):
    """Parse east/north tangent-plane offsets; this does not certify calibration."""
    names=("mjd","x_arcsec","y_arcsec","sigma_x_arcsec","sigma_y_arcsec")
    result=_csv_rows(content,names)
    if not result["available"]:
        return result
    if any(row["sigma_x_arcsec"]<=0 or row["sigma_y_arcsec"]<=0 for row in result["rows"]):
        return _unavailable("CSV coordinate uncertainties must be strictly positive.")
    result["arrays"]={name:np.array([row[name] for row in result["rows"]]) for name in names}
    if any("covariance_xy_arcsec2" in row for row in result["rows"]):
        if not all("covariance_xy_arcsec2" in row for row in result["rows"]):
            return _unavailable("Supply coordinate covariance on every row, or omit that optional column.")
        result["arrays"]["covariance_xy_arcsec2"]=np.array([row["covariance_xy_arcsec2"] for row in result["rows"]])
    result["warning"]="CSV upload does not establish calibration, source identity, reference correction or an absolute parallax zero point."
    return result


def parse_spectral_template_csv(content):
    result=_csv_rows(content,("wavelength_um","flux_ujy"))
    if not result["available"]:
        return result
    rows=sorted(result["rows"],key=lambda r:r["wavelength_um"])
    wavelength=np.array([r["wavelength_um"] for r in rows])
    flux=np.array([r["flux_ujy"] for r in rows])
    if len(rows)<3 or np.any(wavelength<=0) or len(np.unique(wavelength))!=len(wavelength):
        return _unavailable("A spectral curve needs at least three unique positive wavelengths.")
    if np.any(flux<0) or not np.any(flux>0):
        return _unavailable("The reference spectral curve must be nonnegative and not identically zero.")
    return dict(available=True,wavelength_um=wavelength,flux_ujy=flux)


def fit_uploaded_template(wavelength_um,flux_ujy,errors_ujy,bandwidth_um,
                          template_wavelength_um,template_flux_ujy):
    """Fit one positive scale after illustrative top-hat wavelength averaging.

    This is not integration through the measured SPHEREx response functions.
    It is an explicit diagnostic approximation, never an object classifier.
    """
    arrays=_arrays(wavelength_um,flux_ujy,errors_ujy,bandwidth_um)
    template=_arrays(template_wavelength_um,template_flux_ujy)
    if arrays is None or template is None:
        return _unavailable("Template comparison needs matching data, uncertainties and bandwidths.")
    wave,flux,error,width=arrays
    tw,tf=template
    order=np.argsort(tw,kind="stable")
    tw,tf=tw[order],tf[order]
    if len(tw)<3 or not np.isfinite(np.r_[tw,tf]).all() or np.any(tw<=0) or np.any(np.diff(tw)<=0) or np.any(tf<0):
        return _unavailable("The reference curve requires unique positive wavelengths and finite nonnegative fluxes.")
    models=[];indices=[]
    for i,(centre,band) in enumerate(zip(wave,width)):
        if not all(math.isfinite(v) for v in (centre,band,flux[i],error[i])) or centre<=0 or band<=0 or error[i]<=0:
            continue
        lower,upper=centre-band/2,centre+band/2
        if lower<tw[0] or upper>tw[-1] or lower<=0:
            continue
        grid=np.r_[lower,tw[(tw>lower)&(tw<upper)],upper]
        models.append(float(np.trapezoid(np.interp(grid,tw,tf),grid)/band))
        indices.append(i)
    if len(indices)<3:
        return _unavailable("At least three observed bands must lie entirely inside the uploaded template coverage. No extrapolation is performed.")
    indices=np.array(indices,dtype=int)
    if len(np.unique(np.round(wave[indices],8)))<3:
        return _unavailable("At least three distinct measured wavelength centres are needed for a spectral-shape comparison; repeated dates in one band do not supply a spectrum.")
    model=np.array(models)
    weight=1/error[indices]**2
    denominator=float(np.sum(weight*model**2))
    if denominator<=0:
        return _unavailable("The template has no usable positive flux in the observed bands.")
    scale=float(np.sum(weight*model*flux[indices])/denominator)
    if scale<=0 or not math.isfinite(scale):
        return _unavailable("A positive reference-spectrum scale is not supported by these data.")
    predicted=scale*model
    residual=flux[indices]-predicted
    chi2=float(np.sum((residual/error[indices])**2))
    return dict(available=True,indices=indices,wavelength_um=wave[indices],data_flux_ujy=flux[indices],
                errors_ujy=error[indices],model_band_flux_ujy=predicted,residual_ujy=residual,
                scale=scale,scale_error=1/math.sqrt(denominator),chi2=chi2,
                degrees_of_freedom=len(indices)-1,reduced_chi2=chi2/(len(indices)-1),
                template_wavelength_um=tw,scaled_template_flux_ujy=scale*tf,
                warning="Illustrative top-hat averaging of Fnu over wavelength; the actual spectral response functions are not applied. Formal chi-square excludes template/calibration/aperture systematics and is not a classification or discovery probability.")


def known_orbit_timeseries(central_mass_solar, semimajor_axis_au=None,
                           period_years=None,companion_mass_solar=0.,
                           eccentricity=0.,samples=256):
    """Relative two-body orbital-plane positions from established supplied inputs.

    The model starts at periastron at arbitrary t=0, with no sky orientation.
    It is not an orbit inferred from image positions or a real-date ephemeris.
    """
    mass,companion,ecc=(_number(v) for v in (central_mass_solar,companion_mass_solar,eccentricity))
    if mass is None or companion is None or mass<=0 or companion<0 or ecc is None or not 0<=ecc<.95:
        return _unavailable("Supply positive central mass, nonnegative companion mass and eccentricity between 0 and 0.95.")
    sample_count=_number(samples)
    if isinstance(samples,bool) or sample_count is None or int(sample_count)!=sample_count or not 32<=int(sample_count)<=4096:
        return _unavailable("Choose 32-4096 orbit model samples.")
    if semimajor_axis_au is not None:
        orbit=physics.kepler_period(semimajor_axis_au,mass,companion)
        if not orbit["available"]:
            return orbit
        supplied_period=_number(period_years)
        if period_years is not None and (supplied_period is None or not math.isclose(supplied_period,orbit["period_years"],rel_tol=.005)):
            return _unavailable("The supplied period, semimajor axis and masses are inconsistent with this two-body model.")
    else:
        orbit=physics.kepler_semimajor_axis(period_years,mass,companion)
        if not orbit["available"]:
            return orbit
    axis,period=orbit["semimajor_axis_au"],orbit["period_years"]
    time=np.linspace(0,2*period,int(samples))
    mean=np.mod(2*np.pi*time/period,2*np.pi)
    anomaly=mean.copy() if ecc<.8 else np.full_like(mean,np.pi)
    for _ in range(40):
        correction=(anomaly-ecc*np.sin(anomaly)-mean)/(1-ecc*np.cos(anomaly))
        anomaly-=correction
        if np.max(np.abs(correction))<1e-12:
            break
    if np.max(np.abs(anomaly-ecc*np.sin(anomaly)-mean))>1e-9:
        return _unavailable("The orbital anomaly solver did not converge.")
    x=axis*(np.cos(anomaly)-ecc)
    y=axis*math.sqrt(1-ecc*ecc)*np.sin(anomaly)
    rate=2*np.pi/period/(1-ecc*np.cos(anomaly))
    speed=axis*rate*np.sqrt(np.sin(anomaly)**2+(1-ecc*ecc)*np.cos(anomaly)**2)*physics.AU_M/physics.YEAR_S/1000
    return dict(available=True,time_years=time,x_au=x,y_au=y,separation_au=axis*(1-ecc*np.cos(anomaly)),
                speed_kms=speed,period_years=period,semimajor_axis_au=axis,eccentricity=ecc,
                warning="Supplied-input two-body relative orbit in its own plane, starting at arbitrary periastron t=0. It has no fitted sky orientation or real observation epoch and is not an orbit recovered from these images.")


def _plot(fig,key):
    import streamlit as st
    fig.update_layout(margin=dict(l=50,r=25,t=55,b=50),font=dict(size=13))
    return st.plotly_chart(fig,key=key,width="stretch",config={"displaylogo":False})


def _finite_row(row,name):
    return _number(row.get(name)) is not None


def _catalogue_value(catalogue,*names):
    if not isinstance(catalogue,dict) or catalogue.get("available") is False:
        return None
    for nested in (catalogue.get("record"),catalogue.get("row"),catalogue):
        if not isinstance(nested,dict):
            continue
        for name in names:
            value=_number(nested.get(name))
            if value is not None:
                return value
    return None


def render_advanced(bundle,measurement,catalogue=None):
    """Render additional evidence graphs without promoting missing data to facts."""
    import streamlit as st
    import plotly.graph_objects as go

    st.subheader("Additional evidence and supplied-data models")
    if bundle is None:
        st.info("Prepare a time viewer first. Advanced graphs retain the same selected source and observation provenance.")
        return
    recipe=measurement.get("recipe","no_measurement") if isinstance(measurement,dict) else "no_measurement"
    scope=bundle["id"]+"_"+recipe
    band=measurement.get("band",[]) if isinstance(measurement,dict) else []
    good=measurement.get("good",[]) if isinstance(measurement,dict) else []

    with st.expander("Flux differences against a shared reference",expanded=True):
        valid=[r for r in band if all(_finite_row(r,key) for key in ("mjd","flux_ujy","flux_err_ujy")) and r["flux_err_ujy"]>0]
        if len(valid)<2:
            st.info("At least two compatible-band source flux measurements with positive uncertainties are needed.")
        else:
            reference_labels=[f"{i+1}: {row.get('date',row['mjd'])}" for i,row in enumerate(valid)]
            reference=st.selectbox("Difference reference observation",range(len(valid)),format_func=reference_labels.__getitem__,key="adv_reference_"+scope)
            result=shared_reference_differences([r["mjd"] for r in valid],[r["flux_ujy"] for r in valid],[r["flux_err_ujy"] for r in valid],reference)
            if result["available"]:
                fig=go.Figure(go.Scatter(x=result["mjd"],y=result["delta_flux"],error_y=dict(type="data",array=result["delta_flux_error"]),mode="markers",text=[r.get("source_url","") for r in valid]))
                fig.update_layout(title="Aperture flux change relative to the selected observation",xaxis_title="Observation time (MJD, days)",yaxis_title="Flux difference (microJy)")
                _plot(fig,"adv_delta_"+scope)
                st.caption(result["warning"]+" These are preliminary native-image aperture measurements; calibration and aperture corrections remain additional.")
                if st.checkbox("Show shared-reference covariance matrix",value=False,key="adv_show_covariance_"+scope):
                    covariance=go.Figure(go.Heatmap(z=result["covariance"],colorscale="Viridis",colorbar=dict(title="microJy²")))
                    covariance.update_layout(xaxis_title="Observation index",yaxis_title="Observation index",title="Covariance of flux differences")
                    _plot(covariance,"adv_flux_cov_"+scope)
                st.latex(r"\Delta F_i=F_i-F_r,\quad C_\Delta=A C_F A^T,\quad A=I-\mathbf{1}e_r^T")

    with st.expander("Tentative apparent-motion vector"):
        motion=measurement.get("motion") if isinstance(measurement,dict) else None
        if not isinstance(motion,dict) or not motion.get("available"):
            st.info("A compatible-band apparent-motion fit is not available for the current source. No motion arrow is invented.")
        else:
            mx,my=motion["mu_x_arcsec_per_year"],motion["mu_y_arcsec_per_year"]
            ex,ey=_number(motion.get("mu_x_error")),_number(motion.get("mu_y_error"))
            fig=go.Figure(go.Scatter(x=[0,mx],y=[0,my],mode="lines+markers",name="Tentative apparent slope"))
            if ex is not None and ey is not None:
                fig.add_trace(go.Scatter(x=[mx],y=[my],error_x=dict(type="data",array=[ex]),error_y=dict(type="data",array=[ey]),mode="markers",name="Formal slope uncertainty"))
                st.caption(f"Formal component uncertainties: east {ex:.3g}, north {ey:.3g} arcsec/year. These do not establish a calibrated proper-motion error budget.")
            else:
                st.caption("Reliable component uncertainties are unavailable; this diagnostic vector must not be interpreted as a precise proper-motion measurement.")
            fig.add_annotation(x=mx,y=my,ax=0,ay=0,xref="x",yref="y",axref="x",ayref="y",showarrow=True,arrowhead=3)
            fig.update_layout(title="Tentative apparent angular-motion vector",xaxis_title="Apparent east slope (arcsec/year)",yaxis_title="Apparent north slope (arcsec/year)",yaxis=dict(scaleanchor="x"))
            _plot(fig,"adv_motion_arrow_"+scope)
            st.warning("The centroid slope can include parallax, blending, wavelength-dependent shifts and registration errors. It is not automatically usable for physical speed or a new distance.")

    with st.expander("Flux-density conversion and full Planck equation"):
        st.latex(r"F_\lambda=\frac{c}{\lambda^2}F_\nu,\qquad B_\lambda(T)=\frac{2hc^2}{\lambda^5}\frac{1}{\exp[hc/(\lambda k_BT)]-1}")
        st.caption("h is Planck's constant, c is light speed and kB is Boltzmann's constant. Fnu and Flambda have different units and different spectral peak positions.")
        valid=[r for r in good if all(_finite_row(r,k) for k in ("wavelength_um","flux_ujy","flux_err_ujy"))]
        if valid:
            result=fnu_to_flambda([r["wavelength_um"] for r in valid],[r["flux_ujy"] for r in valid],[r["flux_err_ujy"] for r in valid])
            if result["available"]:
                fig=go.Figure(go.Scatter(x=result["wavelength_um"],y=result["flambda_w_m2_um"],error_y=dict(type="data",array=result["flambda_error_w_m2_um"]),mode="markers",marker=dict(color=[r["mjd"] for r in valid],colorscale="Viridis",colorbar=dict(title="MJD"))))
                fig.update_layout(title="The same aperture measurements expressed as Flambda",xaxis_title="Wavelength (micrometres)",yaxis_title="Aperture Flambda (W m⁻² micrometre⁻¹)")
                _plot(fig,"adv_flambda_"+scope)
                st.caption("A unit-density conversion preserves the original measurement limitations. Different wavelengths may have different observation times; this is not a simultaneous spectrum.")
        else:
            st.info("Measure usable source fluxes to display their converted spectrum.")

    with st.expander("External Doppler line-centre illustration"):
        rest=_number(st.session_state.get("lambda_rest_"+scope))
        observed=_number(st.session_state.get("lambda_observed_"+scope))
        if rest is None or observed is None:
            st.info("Enter identified rest and measured external line wavelengths in the physical-estimates panel to display their shift here.")
        else:
            result=physics.doppler_velocity(observed,rest)
            if result["available"]:
                fig=go.Figure()
                for value,label in [(rest,"Identified rest centre"),(observed,"Supplied measured centre")]:
                    fig.add_trace(go.Scatter(x=[value,value],y=[0,1],mode="lines",name=label))
                fig.update_layout(title=f"Supplied external line-centre shift: {result['radial_kms']:+.4g} km/s",xaxis_title="Wavelength (micrometres)",yaxis=dict(visible=False))
                _plot(fig,"adv_doppler_"+scope)
                st.caption("The vertical markers show supplied line centres, not invented measured line profiles. "+result["warning"])
            else:
                st.info(result["reason"])

    with st.expander("Known-orbit position and speed against model time"):
        mass=_number(st.session_state.get("orbit_mass_"+scope))
        companion=_number(st.session_state.get("orbit_companion_"+scope)) or 0.
        solve=st.session_state.get("orbit_solve_"+scope,"Period from semimajor axis")
        axis=_number(st.session_state.get("orbit_axis_"+scope)) if solve=="Period from semimajor axis" else None
        period=_number(st.session_state.get("orbit_period_"+scope)) if axis is None else None
        if mass is None or (axis is None and period is None):
            st.info("Enter established mass and orbital size or period in the known-orbit panel. No orbital motion is inferred from the sky animation.")
        else:
            eccentricity=st.number_input("Illustrative orbital eccentricity",min_value=0.,max_value=.94,value=0.,step=.05,key="adv_eccentricity_"+scope)
            result=known_orbit_timeseries(mass,axis,period,companion,eccentricity)
            if result["available"]:
                fig=go.Figure()
                for values,label in [(result["x_au"],"Orbital-plane x"),(result["y_au"],"Orbital-plane y"),(result["separation_au"],"Relative separation")]:
                    fig.add_trace(go.Scatter(x=result["time_years"],y=values,mode="lines",name=label))
                fig.update_layout(title="Supplied-input orbital positions against time",xaxis_title="Model years since arbitrary periastron",yaxis_title="Relative orbital-plane position (AU)")
                _plot(fig,"adv_orbit_time_"+scope)
                speed=go.Figure(go.Scatter(x=result["time_years"],y=result["speed_kms"],mode="lines"))
                speed.update_layout(title="Supplied-input relative orbital speed",xaxis_title="Model years since arbitrary periastron",yaxis_title="Relative speed (km/s)")
                _plot(speed,"adv_orbit_speed_"+scope)
                st.caption(result["warning"])
            else:
                st.info(result["reason"])

    with st.expander("Uploaded reference spectrum: explicit model comparison"):
        st.write("Upload a reference curve with wavelength_um and flux_ujy columns. This comparison fits one positive scale; it does not identify a planet or measure chemical abundances.")
        upload=st.file_uploader("Reference spectral curve CSV",type=["csv"],key="adv_template_"+scope)
        stable=st.checkbox("Assume source stability across dates and accept the diagnostic top-hat response approximation",value=False,key="adv_template_stable_"+scope)
        if upload is not None and stable:
            template=parse_spectral_template_csv(upload.getvalue())
            valid=[r for r in good if all(_finite_row(r,k) for k in ("wavelength_um","bandwidth_um","flux_ujy","flux_err_ujy"))]
            if not template["available"]:
                st.info(template["reason"])
            elif len(valid)<3:
                st.info("At least three usable source bands with bandwidths and errors are needed.")
            else:
                result=fit_uploaded_template([r["wavelength_um"] for r in valid],[r["flux_ujy"] for r in valid],[r["flux_err_ujy"] for r in valid],[r["bandwidth_um"] for r in valid],template["wavelength_um"],template["flux_ujy"])
                if result["available"]:
                    fig=go.Figure(go.Scatter(x=result["wavelength_um"],y=result["data_flux_ujy"],error_y=dict(type="data",array=result["errors_ujy"]),mode="markers",name="Source aperture measurements"))
                    fig.add_trace(go.Scatter(x=result["template_wavelength_um"],y=result["scaled_template_flux_ujy"],mode="lines",name="Scaled uploaded reference"))
                    fig.add_trace(go.Scatter(x=result["wavelength_um"],y=result["model_band_flux_ujy"],mode="markers",name="Top-hat reference averages"))
                    fig.update_layout(title="Uploaded reference comparison",xaxis_title="Wavelength (micrometres)",yaxis_title="Flux density (microJy)")
                    _plot(fig,"adv_template_plot_"+scope)
                    st.write(f"Diagnostic scale: {result['scale']:.4g}; formal reduced chi-square: {result['reduced_chi2']:.3g}.")
                    st.caption("Reference file: "+upload.name+". Source dates and original observations remain in the measurement export.")
                    st.warning(result["warning"]+" Wavelength-dependent aperture corrections and source blending can change the shape.")
                else:
                    st.info(result["reason"])

    with st.expander("Five-parameter fit from externally calibrated astrometry"):
        st.write("This fitter never treats the app's preliminary image centroids as calibrated parallax data. Upload separately calibrated east/north offsets relative to one fixed reference direction.")
        st.code("mjd,x_arcsec,y_arcsec,sigma_x_arcsec,sigma_y_arcsec",language="text")
        st.caption("An optional covariance_xy_arcsec2 column supplies east/north covariance for every epoch.")
        upload=st.file_uploader("Calibrated astrometry CSV",type=["csv"],key="adv_astrometry_"+scope)
        fields=st.columns(2)
        origin_ra=fields[0].number_input("Offset reference RA (degrees)",min_value=0.,max_value=360.,value=float(measurement["ra"]) if isinstance(measurement,dict) else None,format="%.8f",key="adv_origin_ra_"+scope)
        origin_dec=fields[1].number_input("Offset reference Dec (degrees)",min_value=-90.,max_value=90.,value=float(measurement["dec"]) if isinstance(measurement,dict) else None,format="%.8f",key="adv_origin_dec_"+scope)
        provenance=st.text_input("Calibration and reference-frame provenance",key="adv_calibration_"+scope,placeholder="Publication, pipeline and reference-frame description")
        calibrated=st.checkbox("Uploaded positions are calibrated and corrected against a stable reference frame; quoted errors include the stated calibration budget",value=False,key="adv_calibrated_"+scope)
        solution=st.radio("Astrometric zero point",["Relative","Externally absolute-referenced"],horizontal=True,key="adv_solution_"+scope)
        absolute_reference=st.text_input("External absolute zero-point reference (required for absolute interpretation)",key="adv_absolute_reference_"+scope) if solution!="Relative" else ""
        if upload is not None:
            parsed=parse_calibrated_astrometry_csv(upload.getvalue())
            if not parsed["available"]:
                st.info(parsed["reason"])
            elif origin_ra is None or origin_dec is None:
                st.info("Supply the fixed reference direction defining the uploaded offsets.")
            else:
                data=parsed["arrays"]
                fit=fit_five_parameter_astrometry(data["mjd"],data["x_arcsec"],data["y_arcsec"],data["sigma_x_arcsec"],data["sigma_y_arcsec"],origin_ra,origin_dec,data.get("covariance_xy_arcsec2"),calibrated=calibrated,reference_corrected=calibrated,calibration_reference=provenance,solution_kind="relative" if solution=="Relative" else "absolute",absolute_reference=absolute_reference)
                if not fit["available"]:
                    st.info(fit["reason"])
                else:
                    st.write(f"**{fit['solution_kind'].capitalize()} fitted parallax:** {fit['parallax_mas']:+.4g} ± {fit['parallax_error_mas']:.3g} mas. Formal reduced chi-square: {fit['reduced_chi2']:.3g}.")
                    fig=go.Figure()
                    residual=go.Figure()
                    for label,key,sigma,modelkey,residkey in [("East","x_arcsec","sigma_x_arcsec","model_x_arcsec","residual_x_arcsec"),("North","y_arcsec","sigma_y_arcsec","model_y_arcsec","residual_y_arcsec")]:
                        fig.add_trace(go.Scatter(x=fit["mjd"],y=fit[key],error_y=dict(type="data",array=fit[sigma]),mode="markers",name=label+" uploaded"))
                        densekey="dense_model_x_arcsec" if label=="East" else "dense_model_y_arcsec"
                        fig.add_trace(go.Scatter(x=fit["model_mjd"],y=fit[densekey],mode="lines",name=label+" five-parameter model"))
                        residual.add_trace(go.Scatter(x=fit["mjd"],y=fit[residkey],error_y=dict(type="data",array=fit[sigma]),mode="markers",name=label))
                    fig.update_layout(title="Calibrated uploaded astrometry and fitted annual model",xaxis_title="Observation time (MJD, days)",yaxis_title="Offset (arcsec)")
                    residual.update_layout(title="Uploaded-astrometry fit residuals",xaxis_title="Observation time (MJD, days)",yaxis_title="Residual (arcsec)")
                    _plot(fig,"adv_five_fit_"+scope)
                    _plot(residual,"adv_five_residuals_"+scope)
                    if fit["distance_available"]:
                        st.write(f"Approximate externally absolute-referenced fit distance: **{fit['distance']['distance_pc']:.4g} pc**.")
                    else:
                        st.info(fit["distance_reason"])
                    st.caption("Uploaded file: "+upload.name+". Calibration declaration and provenance are user supplied; the app does not independently verify them.")
                    st.warning(fit["warning"])
        else:
            st.info("No calibrated astrometry has been uploaded; no new parallax measurement is reported.")
        p=_catalogue_value(catalogue,"parallax_mas","parallax")
        pmra=_catalogue_value(catalogue,"pmra_mas_per_year","pmra")
        pmdec=_catalogue_value(catalogue,"pmdec_mas_per_year","pmdec")
        allow_catalogue_prediction=True
        if isinstance(catalogue,dict) and catalogue.get("distance_eligible") is False:
            st.warning("The catalogue astrometry did not pass its quality checks. Its parallax can produce an unreliable predicted track; no distance is inferred from this illustration.")
            allow_catalogue_prediction=st.checkbox("Show an exploratory prediction using the flagged catalogue astrometry",value=False,key="adv_flagged_catalogue_prediction_"+scope)
        if allow_catalogue_prediction and p is not None and p>0 and origin_ra is not None and origin_dec is not None:
            start=float(bundle["sequence"]["metadata"][0]["mjd"])
            model=physics.predicted_parallax_track(origin_ra,origin_dec,p,np.linspace(start,start+730.5,160),pmra or 0.,pmdec or 0.)
            if model["available"]:
                fig=go.Figure(go.Scatter(x=model["x_arcsec"],y=model["y_arcsec"],mode="lines"))
                fig.update_layout(title="Separate catalogue-predicted annual track",xaxis_title="Predicted east offset (arcsec)",yaxis_title="Predicted north offset (arcsec)",yaxis=dict(scaleanchor="x"))
                _plot(fig,"adv_catalogue_prediction_"+scope)
                st.caption("Prediction uses supplied/retrieved catalogue values; it is separate from uploaded or image-measured astrometry. "+model["warning"])
                if pmra is None or pmdec is None:
                    st.caption("A missing proper-motion component is set to zero only for this labelled illustration; it has not been measured as zero.")
