"""IRSA archive queries and validated SPHEREx cutouts."""

from dataclasses import dataclass, asdict
from pathlib import Path
from io import BytesIO
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from datetime import datetime, timezone
from copy import deepcopy
import hashlib
import json
import math
import os
import re
import tempfile

import numpy as np
import requests
import astropy.units as u
from astropy.coordinates import SkyCoord
from astropy.io import fits
from astropy.table import Table
from astropy.time import Time
from astropy.wcs import WCS
from astropy.io.votable import parse as parse_votable


DEFAULT_RA = 304.693508808
DEFAULT_DEC = 42.4436872991
COLLECTIONS = ("spherex_dr1", "spherex_qr3")


class ArchiveUnavailable(RuntimeError):
    """A user-readable archive connection failure, without response HTML."""


def archive_error_message(error):
    description = str(error)
    match = re.search(r"(?:HTTP\s+Code:|\bHTTP|\bstatus|\bcode)\s*[:=]?\s*(\d{3})", description, re.IGNORECASE)
    if match is None:
        match = re.search(r"\b(502|503|504)\b", description)
    if match:
        return f"The archive search returned HTTP {match.group(1)}. Please try again later."
    if isinstance(error, requests.Timeout) or "timed out" in description.lower():
        return "The archive search timed out. Please try again later."
    return "The archive search could not connect or return a usable result. Check the connection and try again later."


@dataclass(frozen=True)
class Region:
    ra: float
    dec: float
    fov_arcmin: float = 6.0

    def __post_init__(self):
        if not all(math.isfinite(x) for x in (self.ra, self.dec, self.fov_arcmin)):
            raise ValueError("Coordinates and field size must be finite numbers.")
        if not 0 <= self.ra < 360:
            raise ValueError("RA must be at least 0 and less than 360 degrees.")
        if not -90 <= self.dec <= 90:
            raise ValueError("Dec must be between -90 and +90 degrees.")
        if not 1 <= self.fov_arcmin <= 30:
            raise ValueError("Field of view must be between 1 and 30 arcminutes.")


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()[:24]


def text_value(row, name, default=""):
    if name not in row.colnames or np.ma.is_masked(row[name]):
        return default
    value = row[name]
    return value.decode() if isinstance(value, bytes) else str(value)


def number_value(row, name):
    value = text_value(row, name)
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


def normalise_records(table):
    records = []
    for row in table:
        mjd = number_value(row, "t_min")
        url = text_value(row, "access_url")
        if mjd is None or not url:
            continue
        records.append({
            "obs_id": text_value(row, "obs_id"),
            "detector": text_value(row, "energy_bandpassname", "Unknown"),
            "mjd": mjd,
            "date": Time(mjd, format="mjd").isot,
            "collection": text_value(row, "obs_collection"),
            "url": url,
            "em_min_m": number_value(row, "em_min"),
            "em_max_m": number_value(row, "em_max"),
        })
    # Keep separate detectors for a pointing; prefer DR1 for duplicate products.
    records.sort(key=lambda r: (0 if r["collection"] == "spherex_dr1" else 1, r["url"]))
    unique = {}
    for record in records:
        key = (record["obs_id"] or record["url"], record["detector"])
        unique.setdefault(key, record)
    result = sorted(unique.values(), key=lambda r: (r["mjd"], r["detector"], r["obs_id"]))
    return result


def dataset_from_table(table, region, collections=COLLECTIONS):
    records=normalise_records(table)
    if len(table)>0 and not records:
        raise ValueError("The archive returned rows but its time/URL columns could not be read; this is not an empty sky search.")
    return {
        "region": asdict(region),
        "collections": list(collections),
        "raw_count": len(table),
        "records": records,
    }


def load_local_dataset(path):
    table = Table.read(path, format="ascii.ecsv")
    dataset = dataset_from_table(table, Region(DEFAULT_RA, DEFAULT_DEC))
    return dict(dataset, source="saved", source_label="Saved tutorial query", fetched_at=None)


def query_archive(ra, dec, collections):
    region = Region(float(ra), float(dec))
    if not collections or any(c not in COLLECTIONS for c in collections):
        raise ValueError("Choose at least one supported SPHEREx collection.")
    from astroquery.ipac.irsa import Irsa
    # Query images overlapping the target centre. Cutout field size is independent.
    Irsa.TIMEOUT = 120
    try:
        result = Irsa.query_sia(
            pos=(SkyCoord(region.ra, region.dec, unit="deg"), 1 * u.arcsec),
            collection=list(collections),
        )
        dataset=dataset_from_table(result,region,collections)
    except Exception as error:
        sia_message = archive_error_message(error)
        try:
            fallback=query_archive_sia_direct(region.ra,region.dec,collections)
            fallback["fallback_notice"]=sia_message
            return fallback
        except Exception:
            pass
        try:
            fallback = query_archive_tap(region.ra, region.dec, collections)
            fallback["fallback_notice"] = sia_message
            return fallback
        except Exception as tap_error:
            raise ArchiveUnavailable(
                "The archive search routes are unavailable. " + sia_message
                + " Direct SIA and the alternate TAP route also failed."
            ) from tap_error
    return dict(dataset, source="live",
                source_label="IRSA live search", fetched_at=datetime.now(timezone.utc).isoformat())


def query_archive_sia_direct(ra,dec,collections):
    """Query standard SIA2 directly when service-capability discovery is unavailable."""
    region=Region(float(ra),float(dec))
    if not collections or any(c not in COLLECTIONS for c in collections):raise ValueError("Choose supported SPHEREx collections.")
    params=[("POS",f"CIRCLE {region.ra:.6f} {region.dec:.6f} 0.000277778"),("MAXREC","10000")]
    params.extend(("COLLECTION",value) for value in collections)
    response=requests.get("https://irsa.ipac.caltech.edu/SIA",params=params,timeout=(15,60))
    response.raise_for_status()
    return sia_dataset_from_votable(response.content,region,collections)


def sia_dataset_from_votable(content,region,collections=COLLECTIONS):
    if len(content)>64*1024*1024:raise ValueError("The metadata response is too large.")
    parsed=parse_votable(BytesIO(content),verify="ignore")
    infos=list(parsed.infos)
    for resource in parsed.resources:infos.extend(resource.infos)
    overflow=False
    for info in infos:
        if str(info.name).upper()=="QUERY_STATUS":
            if str(info.value).upper()=="ERROR":raise ArchiveUnavailable("The SIA service rejected the image query.")
            overflow |= str(info.value).upper()=="OVERFLOW"
    # VOTable IDs may be anonymous field numbers; names carry the SIA semantics.
    table=parsed.get_first_table().to_table(use_names_over_ids=True)
    dataset=dataset_from_table(table,region,collections)
    return dict(dataset,source="live",source_label="IRSA direct SIA2 search",query_method="SIA2 direct",
                fetched_at=datetime.now(timezone.utc).isoformat(),result_truncated=overflow,
                source_notice="The service truncated the result; coverage is incomplete." if overflow else None,
                query_position_precision_deg=.000001)


def query_archive_tap(ra, dec, collections):
    """Documented artifact/plane spatial query, with explicit survey scope.

    The minimal published TAP schema does not distinguish SIA wide/deep
    collections. This fallback filters the DR1/QR3 release from the documented
    artifact path and labels its broader release-wide scope explicitly.
    """
    region = Region(float(ra), float(dec))
    if not collections or any(value not in COLLECTIONS for value in collections):
        raise ValueError("Choose supported DR1/QR3 image collections.")
    query = f"""SELECT a.uri AS artifact_uri, p.time_bounds_lower, p.energy_bandpassname
FROM spherex.artifact a JOIN spherex.plane p ON a.planeid=p.planeid
WHERE 1=CONTAINS(POINT('ICRS',{region.ra:.10f},{region.dec:.10f}),p.poly)
ORDER BY p.time_bounds_lower"""
    response = requests.post("https://irsa.ipac.caltech.edu/TAP/sync", data={
        "REQUEST":"doQuery", "LANG":"ADQL", "FORMAT":"votable", "QUERY":query,
        "MAXREC":"50000",
    }, timeout=(15,90))
    response.raise_for_status()
    parsed = parse_votable(BytesIO(response.content), verify="ignore")
    infos = list(parsed.infos)
    for resource in parsed.resources:
        infos.extend(resource.infos)
    overflow = False
    for info in infos:
        if str(info.name).upper()=="QUERY_STATUS":
            status = str(info.value).upper()
            if status=="ERROR":raise ArchiveUnavailable("The TAP service rejected the metadata query.")
            overflow |= status=="OVERFLOW"
    raw = parsed.get_first_table().to_table(use_names_over_ids=True)
    mapped=[]
    known_products=0
    for row in raw:
        uri=text_value(row,"artifact_uri")
        if not uri:continue
        url = uri if uri.startswith("https://") else "https://irsa.ipac.caltech.edu/"+uri.lstrip("/")
        release = re.search(r"/spherex/(dr1|qr3)/",url)
        if release is None:continue
        known_products+=1
        collection = "spherex_"+release.group(1)
        if collection not in collections:continue
        filename = urlsplit(url).path.rsplit("/",1)[-1]
        exposure = re.match(r"level2_(.+)D[1-6]_spx_",filename)
        mjd = number_value(row,"time_bounds_lower")
        if mjd is None:continue
        mapped.append({"obs_id":exposure.group(1) if exposure else filename,
            "energy_bandpassname":text_value(row,"energy_bandpassname","Unknown"),
            "t_min":mjd,"access_url":url,"obs_collection":collection})
    if len(raw)>0 and known_products==0:
        raise ArchiveUnavailable("TAP returned products that could not be mapped to the selected DR1/QR3 releases.")
    if mapped:
        table=Table(rows=mapped)
    else:
        table=Table(names=["obs_id","energy_bandpassname","t_min","access_url","obs_collection"],dtype=["U1","U1",float,"U1","U1"])
    dataset=dataset_from_table(table,region,collections)
    notice="Alternate TAP results are release-wide; wide and deep survey images are not distinguished by the published minimal metadata query."
    if overflow:notice+=" The service truncated the result; this is not complete coverage."
    return dict(dataset,source="live",source_label="IRSA TAP image metadata",query_method="TAP",
                survey_scope="release-wide; wide/deep not distinguished",source_notice=notice,
                result_truncated=overflow,fetched_at=datetime.now(timezone.utc).isoformat())


def query_cache_key(ra, dec, collections):
    return digest({"ra": round(float(ra), 8), "dec": round(float(dec), 8),
                   "collections": sorted(collections)})


def save_query(dataset, cache_dir):
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    region = dataset["region"]
    key = query_cache_key(region["ra"], region["dec"], dataset["collections"])
    destination = cache_dir / f"{key}.json"
    payload = dict(deepcopy(dataset), cache_schema=1,
                   saved_at=datetime.now(timezone.utc).isoformat())
    payload.pop("archive_notice", None)
    with tempfile.NamedTemporaryFile(dir=cache_dir, prefix=key + "-", suffix=".part", delete=False) as handle:
        temporary = Path(handle.name)
    try:
        temporary.write_text(json.dumps(payload, allow_nan=False), encoding="utf-8")
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)
    return destination


def load_saved_query(ra, dec, collections, cache_dir):
    path = Path(cache_dir) / f"{query_cache_key(ra, dec, collections)}.json"
    try:
        dataset = json.loads(path.read_text(encoding="utf-8"))
        region = dataset["region"]
        if dataset.get("cache_schema") != 1:
            return None
        if not (math.isclose(region["ra"], float(ra), rel_tol=0, abs_tol=1e-8)
                and math.isclose(region["dec"], float(dec), rel_tol=0, abs_tol=1e-8)
                and sorted(dataset["collections"]) == sorted(collections)):
            return None
        if not isinstance(dataset["records"], list) or not isinstance(dataset["raw_count"], int):
            return None
        return dataset
    except (OSError, ValueError, KeyError, TypeError):
        return None


def search_with_recovery(ra, dec, collections, cache_dir, live_query=None):
    """Cache successful searches; recover only results for this exact query."""
    Region(float(ra), float(dec))
    if not collections or any(c not in COLLECTIONS for c in collections):
        raise ValueError("Choose at least one supported SPHEREx collection.")
    try:
        dataset = (live_query or query_archive)(ra, dec, collections)
    except ArchiveUnavailable as error:
        saved = load_saved_query(ra, dec, collections, cache_dir)
        if saved is None:
            raise ArchiveUnavailable(str(error) + " No saved result matches these coordinates and collections.") from error
        return dict(saved, source="saved", archive_notice=str(error))
    dataset = deepcopy(dataset)
    dataset["source"] = "live"
    dataset["source_label"] = "IRSA live search"
    dataset.pop("archive_notice", None)
    try:
        save_query(dataset, cache_dir)
    except OSError:
        dataset["cache_notice"] = "The search succeeded, but this result could not be saved locally."
    return dataset


def public_rows(records):
    return [{
        "Observation ID": r["obs_id"], "Observation date": r["date"],
        "Start MJD": r["mjd"], "Detector": r["detector"], "Collection": r["collection"],
    } for r in records]


def frame_key(record, region):
    return digest({"url": record["url"], "region": asdict(region)})


def inspect_fits(source, region):
    with fits.open(source, memmap=False) as hdul:
        if "IMAGE" not in hdul:
            raise ValueError("The response does not contain a SPHEREx IMAGE extension.")
        image = np.asarray(hdul["IMAGE"].data, dtype=float).copy()
        header = hdul["IMAGE"].header.copy()
        if image.ndim != 2 or image.size == 0 or not np.isfinite(image).any():
            raise ValueError("The cutout contains no usable two-dimensional image data.")
        x, y = WCS(header).celestial.world_to_pixel(SkyCoord(region.ra, region.dec, unit="deg"))
        x, y = float(x), float(y)
        if not (math.isfinite(x) and math.isfinite(y) and -0.5 <= x < image.shape[1]-0.5 and -0.5 <= y < image.shape[0]-0.5):
            raise ValueError("The returned image does not cover the requested centre.")
        ix = int(np.clip(round(x), 0, image.shape[1]-1))
        iy = int(np.clip(round(y), 0, image.shape[0]-1))
        wave = bandwidth = None
        try:
            spectral_header = header.copy()
            # SIP belongs to the spatial WCS, not the alternate wavelength WCS.
            for name in list(spectral_header):
                if re.fullmatch(r"(A|B|AP|BP)_(ORDER|\d+_\d+)", name):
                    del spectral_header[name]
            spectral = WCS(spectral_header, fobj=hdul, key="W")
            spectral.sip = None
            wavelength, width = spectral.pixel_to_world(x, y)
            wave = float(wavelength.to_value(u.um))
            bandwidth = float(width.to_value(u.um))
            if not (math.isfinite(wave) and math.isfinite(bandwidth) and wave > 0 and bandwidth > 0):
                wave = bandwidth = None
        except (ValueError, KeyError, TypeError, AttributeError, u.UnitConversionError):
            pass
        meta = {
            "date": str(header.get("DATE-OBS", "Unknown")),
            "width": image.shape[1], "height": image.shape[0],
            "unit": str(header.get("BUNIT", "Image intensity")),
            "target_x": x, "target_y": y,
            "centre_finite": bool(np.isfinite(image[iy, ix])),
            "wavelength_um": wave, "bandwidth_um": bandwidth,
            "compact_derived":bool(hdul[0].header.get("EPSFOMIT",False)),
            "original_product_url":str(hdul[0].header.get("ORIGURL","")),
        }
    return image, header, meta


def has_cached_cutout(record,region,cache_dir):
    name=frame_key(record,region)+".fits"
    return any(path.is_file() for path in (Path(cache_dir)/name,Path(__file__).resolve().parent/"data"/"demo_cutouts"/name))


def download_cutout(record, region, cache_dir):
    cache_dir = Path(cache_dir)
    key = frame_key(record, region)
    path = cache_dir / f"{key}.fits"
    if path.is_file():
        try:
            _, _, meta = inspect_fits(path, region)
            return {"key": key, "path": str(path), "meta": meta, "record": record, "region": asdict(region)}
        except (OSError, ValueError, KeyError):
            pass
    packaged=Path(__file__).resolve().parent/"data"/"demo_cutouts"/f"{key}.fits"
    if packaged.is_file():
        _,_,meta=inspect_fits(packaged,region)
        return {"key":key,"path":str(packaged),"meta":meta,"record":record,"region":asdict(region),"acquisition_source":"Packaged real NASA demonstration cutout"}
    url = urlsplit(record["url"])
    if url.scheme != "https" or url.hostname != "irsa.ipac.caltech.edu":
        raise ValueError("This download must come from the official IRSA HTTPS archive.")
    query = [(k, v) for k, v in parse_qsl(url.query) if k.lower() not in {"center", "size"}]
    clean_url = urlunsplit((url.scheme, url.netloc, url.path, urlencode(query), ""))
    payload = bytearray()
    with requests.get(clean_url, params={
        "center": f"{region.ra:.10f},{region.dec:.10f}d",
        "size": f"{region.fov_arcmin / 60:.10f}",
    }, timeout=(20, 180), stream=True) as response:
        response.raise_for_status()
        for chunk in response.iter_content(256 * 1024):
            payload.extend(chunk)
            if len(payload) > 64 * 1024 * 1024:
                raise ValueError("The response is too large for this cutout. Try a smaller field.")
    _, _, meta = inspect_fits(BytesIO(payload), region)
    cache_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=cache_dir, prefix=key + "-", suffix=".part", delete=False) as handle:
        temporary = Path(handle.name)
    try:
        temporary.write_bytes(payload)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return {"key": key, "path": str(path), "meta": meta, "record": record, "region": asdict(region)}
