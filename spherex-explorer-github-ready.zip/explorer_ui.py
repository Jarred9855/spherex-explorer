"""Time playback, preliminary source measurements and conditional physics UI."""

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path
import csv
from io import StringIO
import json
import math

import numpy as np
import plotly.graph_objects as go
from astropy.coordinates import SkyCoord
from astropy.time import Time
from astropy.wcs import WCS
import streamlit as st

import data_access as archive
import sequence
import photometry
import physics
import calibrated_data
import measurement_workflow

ANALYSIS_VERSION="reliability-3"


def safe_json(value):
    if isinstance(value, dict):
        return {str(k): safe_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [safe_json(v) for v in value]
    if isinstance(value, np.ndarray):
        return safe_json(value.tolist())
    if isinstance(value, np.generic):
        return safe_json(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Path):
        return str(value)
    return value


def csv_data(rows):
    if not rows:
        return ""
    result = StringIO()
    fields = list(dict.fromkeys(key for row in rows for key in row))
    writer = csv.DictWriter(result, fieldnames=fields)
    writer.writeheader()
    for row in safe_json(rows):
        writer.writerow({k: json.dumps(v) if isinstance(v, (list, dict)) else v for k, v in row.items()})
    return result.getvalue()


def plot(fig, key, **kwargs):
    fig.update_layout(margin=dict(l=45, r=20, t=55, b=50), font=dict(size=13))
    return st.plotly_chart(fig, key=key, width="stretch", config={"displaylogo": False}, **kwargs)


def linked_plot(fig, key, rows, bundle):
    """A selected measured point opens its already loaded exposure in Sky image."""
    fig.update_layout(clickmode="event+select")
    event=plot(fig,key,on_select="rerun",selection_mode="points")
    points=event.selection.points if hasattr(event,"selection") else []
    processed=st.session_state.setdefault("processed_measurement_selections",{})
    if not points:
        processed.pop(key,None)
        return
    value=points[-1].get("customdata")
    if isinstance(value,(list,tuple)):value=value[0] if value else None
    if not isinstance(value,(int,float)) or not 0<=int(value)<len(rows):return
    index=int(value)
    if processed.get(key)==index:return
    processed[key]=index
    frame=next((f for f in bundle["frames"] if f["record"]["url"]==rows[index].get("source_url")),None)
    if frame is not None:
        st.session_state.pending_plot_frame=frame
        st.rerun()


def _matches(bundle, region):
    return bundle is not None and bundle.get("region") == asdict(region)


def _prepare_records(records, detector, maximum, extra_bands, spectral_per_detector=1):
    chosen = sequence.choose_sequence_records(records, detector, maximum)
    if not chosen:
        raise ValueError("No image records are available for this detector.")
    movie_records = list(chosen)
    if extra_bands:
        anchor = chosen[0]["mjd"]
        for band in sorted({r["detector"] for r in records}):
            if spectral_per_detector>1:
                candidates=sequence.choose_sequence_records(records,band,spectral_per_detector)
                present={r["url"] for r in chosen}
                chosen.extend(r for r in candidates if r["url"] not in present)
            elif band != detector:
                chosen.append(min((r for r in records if r["detector"] == band), key=lambda r: abs(r["mjd"]-anchor)))
    return movie_records, chosen


def prepare_bundle(records, region, cache_dir, detector="SPHEREx-D1", maximum=6,
                   extra_bands=True, reusable_frame=None, progress=None,spectral_per_detector=1,catalogue=None):
    movie_records, wanted = _prepare_records(records, detector, maximum, extra_bands,spectral_per_detector)
    movie_urls = {r["url"] for r in movie_records}
    # Additional native cutouts already on disk improve wavelength-matched
    # sampling without silently starting more network downloads.
    wanted_urls={r["url"] for r in wanted}
    for record in records:
        if record["detector"]==detector and record["url"] not in wanted_urls:
            if archive.has_cached_cutout(record,region,cache_dir):
                wanted.append(record)
                wanted_urls.add(record["url"])
    frames, failures = [], []
    def fetch(record):
        key = archive.frame_key(record, region)
        if reusable_frame is not None and reusable_frame.get("key") == key:
            archive.inspect_fits(reusable_frame["path"], region)
            return reusable_frame
        return archive.download_cutout(record, region, cache_dir)
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = {pool.submit(fetch, record): record for record in wanted}
        for count, future in enumerate(as_completed(futures), 1):
            record = futures[future]
            try:
                frames.append(future.result())
            except Exception as error:
                failures.append({"obs_id": record["obs_id"], "detector": record["detector"], "date": record["date"], "reason": archive.archive_error_message(error)})
            if progress:
                progress(count, len(wanted))
    frames.sort(key=lambda f: (f["record"]["mjd"], f["record"]["detector"]))
    movie_frames = [frame for frame in frames if frame["record"]["url"] in movie_urls]
    if len(movie_frames) < 2:
        raise ValueError("At least two cutouts from different observations are needed. Some downloads may have failed; retry or choose another detector.")
    aligned = sequence.align_sequence(movie_frames, region, skip_failed=True)
    if len(aligned["images"]) < 2:
        raise ValueError("Fewer than two images have usable sky coverage after alignment.")
    reference = aligned["metadata"][0]["frame"]
    candidates = photometry.detect_sources(reference["path"], region=region, max_sources=25)
    identity = archive.digest({"version":ANALYSIS_VERSION,"region": asdict(region), "frames": [f["key"] for f in frames], "detector": detector})
    return {"id": identity, "region": asdict(region), "detector": detector,
            "frames": frames, "sequence": aligned, "candidates": candidates,
            "failures": failures, "maximum": maximum, "extra_bands": extra_bands,"analysis_version":ANALYSIS_VERSION,
            "catalogue":catalogue if measurement_workflow.catalogue_matches_source(catalogue,region.ra,region.dec) else None}


def _display_values(image, limits):
    low, high = limits
    raw = np.asarray(image, dtype=float)
    linear = np.clip((raw-low)/(high-low), 0, 1)
    stretched = np.arcsinh(linear/.1)/np.arcsinh(10.)
    return np.where(np.isfinite(raw), stretched, np.nan)


def bundle_from_frames(frames,catalogue):
    """Open a real validation subset without issuing new archive requests."""
    if not frames:raise ValueError("No dated validation images are available.")
    region=archive.Region(**frames[0]["region"])
    if any(frame.get("region")!=asdict(region) for frame in frames):raise ValueError("Validation samples do not share one cutout region.")
    preferred="SPHEREx-D6" if catalogue.get("target_key",catalogue.get("key"))=="wise_0855" else "SPHEREx-D1"
    counts={band:sum(f["record"]["detector"]==band for f in frames) for band in {f["record"]["detector"] for f in frames}}
    detector=preferred if counts.get(preferred,0)>=2 else max(counts,key=counts.get)
    movie=sorted([f for f in frames if f["record"]["detector"]==detector],key=lambda f:f["record"]["mjd"])
    if len(movie)<2:raise ValueError("This validation subset has fewer than two images from one detector.")
    aligned=sequence.align_sequence(movie,region,skip_failed=True)
    if len(aligned["images"])<2:raise ValueError("Fewer than two images have valid aligned coverage.")
    reference=aligned["metadata"][0]["frame"]
    candidates=photometry.detect_sources(reference["path"],region=region,max_sources=25)
    identity=archive.digest({"version":ANALYSIS_VERSION,"frames":[f["key"] for f in frames],"validation_sample":True})
    return {"id":identity,"region":asdict(region),"detector":detector,"frames":frames,"sequence":aligned,
            "candidates":candidates,"failures":[],"maximum":len(movie),"extra_bands":True,
            "analysis_version":ANALYSIS_VERSION,"catalogue":catalogue,"validation_subset":True}


def stack_figure(image,title="Weighted display stack"):
    """Robust asinh display only: retain raw values for hover and colour labels."""
    raw=np.asarray(image,dtype=float)
    low,high=sequence.shared_stretch_limits([raw])
    ticks=np.linspace(0,1,5)
    raw_ticks=low+(high-low)*.1*np.sinh(ticks*np.arcsinh(10.))
    fig=go.Figure(go.Heatmap(z=_display_values(raw,(low,high)),customdata=raw,zmin=0,zmax=1,
                colorscale=[[0,"black"],[1,"white"]],colorbar=dict(title="MJy/sr",tickvals=ticks,ticktext=[f"{v:.3g}" for v in raw_ticks]),
                hoverongaps=False,hovertemplate="x=%{x}, y=%{y}<br>%{customdata:.4g} MJy/sr<extra></extra>"))
    fig.update_layout(title=title,height=370,plot_bgcolor="#29313a",xaxis=dict(range=[-.5,raw.shape[1]-.5],constrain="domain"),
                      yaxis=dict(range=[-.5,raw.shape[0]-.5],scaleanchor="x",scaleratio=1,constrain="domain"))
    return fig


def movie_figure(bundle):
    seq = bundle["sequence"]
    ticks = np.linspace(0, 1, 5)
    low, high = seq["sharedlimits"]
    raw_ticks = low+(high-low)*.1*np.sinh(ticks*np.arcsinh(10.))
    colourbar = dict(title="MJy/sr", tickvals=ticks, ticktext=[f"{v:.3g}" for v in raw_ticks])
    def trace(image):
        return go.Heatmap(z=_display_values(image, seq["sharedlimits"]), customdata=image,
                          zmin=0, zmax=1, colorscale=[[0,"black"],[1,"white"]],
                          colorbar=colourbar, hoverongaps=False,
                          hovertemplate="x=%{x}, y=%{y}<br>%{customdata:.4g} MJy/sr<extra></extra>")
    def title(meta):
        wave = meta.get("wavelength_um")
        wavelength = f"{wave:.4f} μm" if wave is not None else "wavelength unavailable"
        return f"{meta['date']} · {meta['detector']} · {wavelength}"
    fig = go.Figure(data=[trace(seq["images"][0])])
    candidates = bundle["candidates"]
    if candidates:
        coords = SkyCoord([s["ra_deg"] for s in candidates], [s["dec_deg"] for s in candidates], unit="deg")
        xs, ys = WCS(seq["header"]).celestial.world_to_pixel(coords)
        fig.add_trace(go.Scatter(x=xs, y=ys, mode="markers", name="Reference candidates",
                                marker=dict(symbol="circle-open", size=14, color="#21bec5", line=dict(width=2)),
                                customdata=list(range(len(candidates))),
                                text=[f"Candidate {i+1}: RA {s['ra_deg']:.7f}°, Dec {s['dec_deg']:+.7f}°" for i,s in enumerate(candidates)],
                                hovertemplate="%{text}<extra></extra>"))
    frames = []
    for i,(image,meta) in enumerate(zip(seq["images"],seq["metadata"])):
        frames.append(go.Frame(name=str(i), data=[trace(image)], traces=[0], layout=dict(title=dict(text=title(meta)))))
    fig.frames = frames
    fig.update_layout(title=title(seq["metadata"][0]), height=570,template="plotly_dark",paper_bgcolor="#111111",
        xaxis=dict(title="Aligned sky-grid x (pixels; east is left)", constrain="domain"),
        yaxis=dict(title="Aligned sky-grid y (pixels; north is up)", scaleanchor="x", scaleratio=1),
        plot_bgcolor="#202020", dragmode="pan", clickmode="event+select", showlegend=False,
        updatemenus=[dict(type="buttons", direction="left", x=0, y=-.16,
            bgcolor="#E7EEF4",bordercolor="#536676",font=dict(color="#123044"),
            buttons=[dict(label="▶ Play",method="animate",args=[None,{"frame":{"duration":700,"redraw":True},"fromcurrent":True,"transition":{"duration":0}}]),
                     dict(label="Pause",method="animate",args=[[None],{"mode":"immediate","frame":{"duration":0,"redraw":False},"transition":{"duration":0}}])])],
        sliders=[dict(active=0,x=.25,len=.75,y=-.12,currentvalue=dict(prefix="Frame: "),
            steps=[dict(label=str(i+1),method="animate",args=[[str(i)],{"mode":"immediate","frame":{"duration":0,"redraw":True},"transition":{"duration":0}}]) for i in range(len(frames))])])
    return fig


def render_time_player(region, records, cache_dir, identity):
    st.subheader("Aligned time player")
    st.write("Load a small sequence, align it to a fixed sky grid, then play observations in date order.")
    controls = st.columns(3)
    bands = sorted({r["detector"] for r in records})
    preferred="SPHEREx-D6" if st.session_state.get("active_target_catalogue",{}).get("target_key")=="wise_0855" else "SPHEREx-D1"
    default = bands.index(preferred) if preferred in bands else 0
    detector = controls[0].selectbox("Movie detector", bands, index=default, key=f"movie_detector_{identity}")
    maximum = controls[1].selectbox("Movie observations", [4,6,8,12,24,48,96], index=1, key=f"movie_count_{identity}")
    extra = controls[2].checkbox("Also load other detectors for a spectrum", value=True, key=f"movie_extra_{identity}")
    spectral_count=st.select_slider("Spectral sampling per detector",options=[1,4,8,17,34,68],value=1,key=f"spectral_sampling_{identity}",disabled=not extra)
    st.caption("Higher spectral sampling loads more dated observations across all six detectors. Coverage depends on the actual archive; a complete 102-channel spectrum is not assumed. The largest settings may request several hundred cutouts.")
    if st.button("Prepare time viewer", type="primary", key=f"prepare_{identity}"):
        progress = st.progress(0., text="Preparing cutouts...")
        try:
            result = prepare_bundle(records, region, cache_dir, detector, maximum, extra,
                                    reusable_frame=st.session_state.get("sky_frame"),
                                    progress=lambda n,total: progress.progress(n/total,text=f"Cutouts checked: {n}/{total}"),
                                    spectral_per_detector=spectral_count,catalogue=st.session_state.get("active_target_catalogue"))
            st.session_state.analysis_bundle = result
            st.session_state.pop("source_measurements", None)
            st.rerun()
        except Exception as error:
            st.warning(f"The time viewer could not be prepared: {error}")
        finally:
            progress.empty()
    bundle = st.session_state.get("analysis_bundle")
    active_urls={record["url"] for record in records}
    if not _matches(bundle, region) or bundle.get("analysis_version")!=ANALYSIS_VERSION or any(frame["record"]["url"] not in active_urls for frame in bundle["frames"]):
        st.info("Select Prepare time viewer to download the observations for this region. Previously cached images are reused.")
        return None
    seq = bundle["sequence"]
    st.caption(f"Loaded sequence: {bundle['detector']} · {len(seq['images'])} movie frames · {len(bundle['frames'])} total cutouts for analysis. New control settings apply after Prepare time viewer.")
    if not seq["compatibility"]["compatible"]:
        st.warning("Some movie frames use different wavelengths. Apparent changes can be spectral or instrumental; they are not automatically motion or variability.")
    event = plot(movie_figure(bundle), "time_movie_"+bundle["id"], on_select="rerun", selection_mode="points",theme=None)
    points = event.selection.points if hasattr(event,"selection") else []
    candidate_points=[point for point in points if point.get("curve_number",point.get("curveNumber"))==1]
    if candidate_points:
        value = candidate_points[-1].get("customdata")
        if isinstance(value,(list,tuple)):
            value = value[0] if value else None
        if isinstance(value,(int,float)) and 0 <= int(value) < len(bundle["candidates"]):
            signature = (bundle["id"],int(value))
            if st.session_state.get("last_map_selection") != signature:
                st.session_state["source_picker_"+bundle["id"]] = int(value)
                st.session_state.last_map_selection = signature
    else:
        st.session_state.pop("last_map_selection",None)
    st.caption("Play uses uniform screen intervals; actual observing intervals differ and are shown in the dates. One shared asinh stretch is used. Missing coverage stays blank. Circles mark candidates detected in the reference frame; select one to populate Source measurements.")
    times = [m["mjd"] for m in seq["metadata"]]
    interval_rows = [{"From":seq["metadata"][i-1]["date"],"To":seq["metadata"][i]["date"],"Interval (days)":times[i]-times[i-1]} for i in range(1,len(times))]
    with st.expander("Dates, wavelengths and time intervals"):
        st.dataframe([{k:m.get(k) for k in ["date","mjd","detector","wavelength_um","bandwidth_um","coverage_fraction"]} for m in seq["metadata"]], hide_index=True)
        st.dataframe(interval_rows,hide_index=True)
        st.latex(r"\Delta t=t_2-t_1")
        st.write("Alignment and mask diagnostics")
        st.json(safe_json(seq.get("registration",{})),expanded=False)
        st.dataframe([{k:m.get(k) for k in ["date","psf_fwhm_arcsec","psf_method","bad_native_fraction","quality_mask_applied"]} for m in seq["metadata"]],hide_index=True)
    if bundle["failures"] or seq["errors"]:
        st.warning("Some cutouts were unavailable. The movie contains only the successfully loaded and aligned observations.")
        with st.expander("Unavailable observations"):
            st.dataframe(bundle["failures"]+seq["errors"],hide_index=True)
    st.subheader("Image comparison previews")
    a,b = st.columns(2)
    first = a.selectbox("Reference frame",range(len(times)),format_func=lambda i:f"{i+1}: {seq['metadata'][i]['date']}",key="diff_a_"+bundle["id"])
    second = b.selectbox("Comparison frame",range(len(times)),index=len(times)-1,format_func=lambda i:f"{i+1}: {seq['metadata'][i]['date']}",key="diff_b_"+bundle["id"])
    allow_mixed = st.checkbox("Allow a visual-only comparison of different wavelengths",value=False,key="mixed_"+bundle["id"])
    match_psf=st.checkbox("Approximately match image sharpness before comparing",value=True,key="psf_"+bundle["id"])
    allow_unregistered=st.checkbox("Allow a diagnostic preview if reference-star registration cannot be verified",value=False,key="unregistered_"+bundle["id"])
    stack_all=st.checkbox("Stack all approximately compatible frames",value=True,key="stack_all_"+bundle["id"])
    comparison = sequence.wavelength_compatibility([seq["metadata"][first],seq["metadata"][second]])
    if first == second:
        st.info("Choose two different observations to compare.")
    elif not comparison["compatible"] and not allow_mixed:
        st.info("These frames do not match in wavelength/bandwidth. Choose another pair, or explicitly enable a spectral comparison preview.")
    else:
        try:
            difference = sequence.preview_difference(seq,first,second,require_compatible=not allow_mixed,match_psf=match_psf,require_registration=not allow_unregistered)
            stack_indices=[first]
            if stack_all:
                for i,meta in enumerate(seq["metadata"]):
                    if i not in stack_indices and sequence.wavelength_compatibility([seq["metadata"][j] for j in stack_indices]+[meta])["compatible"]:stack_indices.append(i)
            else:stack_indices=[first,second]
            if len(stack_indices)<2:stack_indices=[first,second]
            stack = sequence.preview_stack(seq,stack_indices,require_compatible=not allow_mixed,match_psf=match_psf,require_registration=not allow_unregistered)
        except ValueError as error:
            st.info("Comparison unavailable: "+str(error))
            return bundle
        c1,c2 = st.columns(2)
        for container,title,item,colour in [(c1,"Background-subtracted difference",difference,"RdBu_r"),(c2,"Weighted display stack",stack,"Gray")]:
            if item is difference:
                fig = go.Figure(go.Heatmap(z=item["image"],colorscale=colour,colorbar=dict(title="MJy/sr"),hoverongaps=False))
                limit=float(np.nanpercentile(np.abs(item["image"]),98)) or 1.
                fig.update_traces(zmin=-limit,zmax=limit)
                ny,nx=item["image"].shape
                fig.update_layout(title=title,height=370,xaxis=dict(range=[-.5,nx-.5],constrain="domain"),yaxis=dict(range=[-.5,ny-.5],scaleanchor="x",constrain="domain"))
            else:fig=stack_figure(item["image"],title+f" ({len(stack_indices)} frames)")
            with container:plot(fig,title+bundle["id"])
        st.caption("The stack uses a robust asinh display stretch, preserving raw MJy/sr values on hover. Bad pixels are masked. Optional Gaussian smoothing uses reported median image sharpness; it is not a full spatially varying PSF model. Interpolation covariance remains uncalibrated, and residuals are not confirmed discoveries.")
        with st.expander("Comparison quality and stack coverage"):
            st.json(safe_json({"psf_matching":stack.get("psf_matching"),"registration":stack.get("registration"),"stacked_frame_indices":stack_indices,"rejected_pixels":stack.get("rejected_count")}),expanded=False)
            count=stack.get("count")
            if count is not None:
                coverage=go.Figure(go.Heatmap(z=count,colorscale="Viridis",colorbar=dict(title="Frames")))
                coverage.update_layout(title="Number of contributing valid frames",height=300,yaxis=dict(scaleanchor="x"))
                plot(coverage,"stack_count_"+bundle["id"])
        with st.expander("Difference and stacking equations"):
            st.latex(r"D=I_2-kI_1,\qquad \bar F=\frac{\sum_iw_iF_i}{\sum_iw_i},\quad w_i=1/\sigma_i^2")
    return bundle


def _finite(row,name):
    try:return math.isfinite(float(row.get(name)))
    except (TypeError,ValueError):return False


def _good_flux(rows):
    return [r for r in rows if r.get("usable_flux",False) and _finite(r,"flux_ujy") and _finite(r,"flux_err_ujy") and r["flux_err_ujy"]>0 and _finite(r,"wavelength_um")]


def matching_rows(rows, anchor, tolerance=.015):
    return [r for r in rows if r["detector"]==anchor["detector"] and sequence.wavelength_compatibility([anchor,r],relative_tolerance=tolerance)["compatible"]]


def render_measurements(bundle):
    st.subheader("Selected-source measurements")
    if bundle is None:
        st.info("Prepare a time viewer first. Source measurements use its original FITS cutouts.")
        return None
    candidates = bundle["candidates"]
    catalogue=bundle.get("catalogue")
    has_target=measurement_workflow.catalogue_matches_source(catalogue,bundle["region"]["ra"],bundle["region"]["dec"])
    ids=([-2] if has_target else [])+list(range(len(candidates)))+[-1]
    def source_label(i):
        if i==-2:return "Challenge target — catalogue position with epoch-aware tracking"
        return "Enter coordinates manually" if i==-1 else f"Candidate {i+1} · RA {candidates[i]['ra_deg']:.7f}°, Dec {candidates[i]['dec_deg']:+.7f}°"
    chosen=st.selectbox("Reference-frame source",ids,format_func=source_label,key="source_picker_"+bundle["id"])
    if chosen==-1:
        fields=st.columns(2)
        ra=fields[0].number_input("Source RA (degrees)",value=float(bundle["region"]["ra"]),min_value=0.,max_value=360.,format="%.8f",key="source_ra_"+bundle["id"])
        dec=fields[1].number_input("Source Dec (degrees)",value=float(bundle["region"]["dec"]),min_value=-90.,max_value=90.,format="%.8f",key="source_dec_"+bundle["id"])
    elif chosen==-2:
        ra,dec=catalogue["query_ra_deg"],catalogue["query_dec_deg"]
        st.caption(f"{catalogue.get('label','Target')} · reference epoch {catalogue.get('query_epoch_jyear')} · measured apertures follow supplied catalogue proper motion when available.")
    else:
        ra,dec=candidates[chosen]["ra_deg"],candidates[chosen]["dec_deg"]
    st.caption("A candidate is an image feature, not an identified planet. Clicking a reference circle in the movie selects a candidate here.")
    settings=st.columns(2)
    aperture=settings[0].number_input("Aperture radius (arcsec)",min_value=6.,max_value=24.,value=12.,step=3.,key="aperture_"+bundle["id"])
    follow=settings[1].checkbox("Follow an unambiguous nearby centroid",value=chosen!=-2,key="follow_"+bundle["id"]+"_"+str(chosen))
    catalogue_recipe={k:catalogue.get(k) for k in ["target_key","source_id","fetched_at","query_epoch_jyear","pmra_mas_per_year","pmdec_mas_per_year"]} if chosen==-2 else None
    recipe=archive.digest({"version":ANALYSIS_VERSION,"bundle":bundle["id"],"source_mode":chosen,"catalogue":catalogue_recipe,"ra":ra,"dec":dec,"aperture":aperture,"follow":follow})
    if st.button("Measure selected source",type="primary",key="measure_"+bundle["id"]):
        with st.spinner("Measuring positions and aperture fluxes in the native images..."):
            rows=measurement_workflow.measure_series(bundle["frames"],ra,dec,catalogue=catalogue if chosen==-2 else None,aperture_arcsec=aperture,
                    annulus_inner=max(18.,aperture*1.5),annulus_outer=max(30.,aperture*2.5),follow_centroid=follow)
        st.session_state.source_measurements={"recipe":recipe,"rows":rows,"ra":ra,"dec":dec,"aperture":aperture,"bundle_id":bundle["id"],"catalogue_identity":catalogue.get("target_key") if chosen==-2 else None}
    with st.expander("Import calibrated spectrophotometry instead of aperture estimates"):
        st.write("Export CSV from the official IRSA spectrophotometry tool, or supply a calibrated table for this selected source. Required: wavelength/flux/flux_err/mjd in μm/μJy/μJy/MJD days. Optional: lambda_width, det_id, flags, ra, dec.")
        imported=st.file_uploader("Calibrated photometry CSV",type=["csv"],key="import_flux_"+recipe)
        provenance=st.text_input("Measurement provenance or IRSA job ID",key="import_provenance_"+recipe)
        confirmed=st.checkbox("I confirm these units and that all rows describe this same selected source",value=False,key="import_confirm_"+recipe)
        if st.button("Use calibrated measurements",key="use_import_"+recipe,disabled=imported is None or not confirmed):
            try:
                imported_rows=calibrated_data.parse_photometry_csv(imported.getvalue(),ra,dec,provenance)
                st.session_state.source_measurements={"recipe":recipe,"rows":imported_rows,"ra":ra,"dec":dec,"aperture":None,"bundle_id":bundle["id"],"imported":True,"provenance":provenance,"catalogue_identity":catalogue.get("target_key") if chosen==-2 else None}
            except ValueError as error:st.warning(str(error))
        st.link_button("Official IRSA spectrophotometry","https://irsa.ipac.caltech.edu/applications/spherex/tool-spectrophotometry")
    measurement=st.session_state.get("source_measurements")
    if measurement is None or measurement.get("recipe")!=recipe:
        st.info("Select Measure selected source to calculate this position. Existing measurements are not relabelled when the selection changes.")
        return None
    rows=measurement["rows"]
    good=_good_flux(rows)
    counts=st.columns(3)
    counts[0].metric("Measured observations",len(rows))
    counts[1].metric("Usable flux measurements",len(good))
    counts[2].metric("Significant detections",sum(bool(r.get("detected")) for r in rows))
    if measurement.get("imported"):
        st.info("Analysis uses the supplied calibrated table: "+measurement.get("provenance","")+". Its calibration, aperture treatment and uncertainty budget remain those of the source pipeline.")
    else:
        st.warning("Preliminary aperture measurements: no total-flux aperture correction or PSF deblending is applied. Flagged pixels and crowded fields can prevent a usable result. Position errors are not a calibrated astrometric error budget.")
    if any(r.get("background_contamination_risk",False) for r in rows):
        st.warning("This field is crowded. Some measurements use a clipped background annulus that still contains source light; blending and background systematics are not included in the formal error bars.")
    with st.expander("Measurements, quality notes and downloads"):
        columns=["date","detector","wavelength_um","flux_ujy","flux_err_ujy","snr","detected","upper_limit_ujy","status","warnings"]
        st.dataframe([{k:r.get(k) for k in columns} for r in rows],hide_index=True)
        st.download_button("Download measurement CSV",csv_data(rows),file_name="spherex_source_measurements.csv",mime="text/csv")
        export={"region":bundle["region"],"source_ra_deg":ra,"source_dec_deg":dec,"aperture_arcsec":measurement.get("aperture"),
                "method":"Imported calibrated table: "+measurement.get("provenance","") if measurement.get("imported") else "Preliminary native-image aperture photometry; no aperture correction or deblending", "measurements":rows}
        st.download_button("Download evidence JSON",json.dumps(safe_json(export),indent=2,allow_nan=False),file_name="spherex_source_evidence.json",mime="application/json")
    if not good:
        st.info("No usable flux measurements passed the coverage and quality checks. Select another reference candidate or adjust the aperture.")
        return dict(measurement,good=[],band=[],motion=None)

    st.subheader("Spectrum and wavelength-time coverage")
    mjd=np.array([r["mjd"] for r in good]); wave=np.array([r["wavelength_um"] for r in good]); flux=np.array([r["flux_ujy"] for r in good]); error=np.array([r["flux_err_ujy"] for r in good])
    spectrum=go.Figure(go.Scatter(x=wave,y=flux,customdata=list(range(len(good))),error_y=dict(type="data",array=error),mode="markers",marker=dict(color=mjd,colorscale="Viridis",size=9,colorbar=dict(title="MJD")),text=[r["date"] for r in good],hovertemplate="λ=%{x:.4f} μm<br>%{y:.4g} μJy<br>%{text}<extra></extra>"))
    spectrum.update_layout(xaxis_title="Estimated wavelength (μm)",yaxis_title="Source flux density (μJy)",title="Spectral measurements, coloured by date")
    linked_plot(spectrum,"spectrum_"+recipe,good,bundle)
    coverage=go.Figure(go.Scatter(x=mjd,y=wave,mode="markers",marker=dict(color=flux,colorscale="Viridis",size=11,colorbar=dict(title="Source μJy")),text=[r["date"] for r in good],hovertemplate="MJD %{x:.5f}<br>λ=%{y:.4f} μm<br>%{text}<extra></extra>"))
    coverage.update_layout(xaxis_title="Observation time (MJD, days)",yaxis_title="Estimated wavelength (μm)",title="Time-wavelength measurements; gaps are unobserved")
    plot(coverage,"time_wave_"+recipe)
    st.caption("Select a spectrum point, then open Sky image to inspect that observation. These points can come from different dates. WCS-WAVE provides visualization-level wavelength estimates; precision analysis requires spectral calibration products.")

    st.subheader("Comparable-band light curve and motion")
    default_anchor=max(range(len(good)),key=lambda i:len(matching_rows(good,good[i])))
    anchor_index=st.selectbox("Reference passband",range(len(good)),index=default_anchor,format_func=lambda i:f"{good[i]['detector']} · {good[i]['wavelength_um']:.4f} μm · {good[i]['date']}",key="band_anchor_"+recipe)
    tolerance=st.slider("Maximum wavelength-centre difference (%)",.5,5.,1.5,.5,key="band_tolerance_"+recipe)/100
    band=sorted(matching_rows(good,good[anchor_index],tolerance),key=lambda r:r["mjd"])
    st.caption(f"{len(band)} usable measurements meet the approximate centre/bandwidth match. Matching is preliminary; instrumental response and PSFs may still differ.")
    x=[r["mjd"] for r in band]; y=[r["flux_ujy"] for r in band]; e=[r["flux_err_ujy"] for r in band]
    light=go.Figure(go.Scatter(x=x,y=y,customdata=list(range(len(band))),error_y=dict(type="data",array=e),mode="markers",name="Aperture flux"))
    light.update_layout(xaxis_title="Observation time (MJD, days)",yaxis_title="Source flux density (μJy)",title="Approximately matched-band light curve")
    linked_plot(light,"light_"+recipe,band,bundle)
    mean=physics.weighted_mean(y,e)
    if mean["available"]:
        st.write(f"Inverse-variance mean: **{mean['mean']:.4g} ± {mean['error']:.2g} μJy** over these observations. Shared systematic errors are not included.")
    if len(band)>=2:
        pair=physics.brightness_change(y[0],y[-1],e[0],e[-1])
        if pair["available"]:
            values=st.columns(3)
            values[0].metric("Elapsed time",f"{x[-1]-x[0]:.3f} days")
            values[1].metric("First-to-last Δflux",f"{pair['delta_flux']:.3g} μJy")
            values[2].metric("Formal change / noise",f"{pair['change_score']:.2f}")
            if pair["delta_magnitude"] is not None:
                st.write(f"Relative magnitude change: **{pair['delta_magnitude']:+.3f} ± {pair['delta_magnitude_error']:.3f} mag**.")
                relative=[]
                for i,row in enumerate(band):
                    change=physics.brightness_change(y[0],y[i],e[0],e[i])
                    if change["available"] and change["delta_magnitude"] is not None:
                        relative.append((x[i],change["delta_magnitude"],0. if i==0 else change["delta_magnitude_error"]))
                mag=go.Figure(go.Scatter(x=[v[0] for v in relative],y=[v[1] for v in relative],error_y=dict(type="data",array=[v[2] for v in relative]),mode="markers"))
                mag.update_layout(title="Relative magnitude against time",xaxis_title="Observation time (MJD, days)",yaxis_title="Magnitude change from reference",yaxis_autorange="reversed")
                plot(mag,"magnitudes_"+recipe)
                st.caption("Relative magnitudes share one reference observation; their errors are therefore correlated.")
            st.caption("The formal score is not a discovery probability. Calibration, PSF, passband and blending differences can mimic variability.")
    else:
        st.info("At least two compatible measurements are needed for a brightness-change comparison. Prepare more observations to improve coverage.")

    astrometry=[r for r in band if r.get("usable_for_astrometry",False) and _finite(r,"source_ra_deg") and _finite(r,"source_dec_deg")]
    motion=None
    if len(astrometry)>=2:
        offsets=physics.angular_offsets([r["source_ra_deg"] for r in astrometry],[r["source_dec_deg"] for r in astrometry])
        if offsets["available"]:
            pos_time=[r["mjd"] for r in astrometry]
            st.metric("Tentative first-to-last displacement",f"{offsets['separation_arcsec'][-1]:.3g} arcsec")
            motion=physics.fit_apparent_motion(pos_time,offsets["x_arcsec"],offsets["y_arcsec"])
            track=go.Figure(go.Scatter(x=offsets["x_arcsec"],y=offsets["y_arcsec"],mode="markers",marker=dict(color=pos_time,colorscale="Viridis",colorbar=dict(title="MJD"))))
            track.update_layout(title="Tentative centroid track",xaxis_title="Eastward sky offset (arcsec)",yaxis_title="Northward sky offset (arcsec)",yaxis=dict(scaleanchor="x"))
            plot(track,"track_"+recipe)
            positions=go.Figure()
            for label,key in [("East","x_arcsec"),("North","y_arcsec")]:
                positions.add_trace(go.Scatter(x=pos_time,y=offsets[key],mode="markers",name=label))
            if motion["available"]:
                for label,key in [("East fit","model_x_arcsec"),("North fit","model_y_arcsec")]:
                    positions.add_trace(go.Scatter(x=motion["mjd"],y=motion[key],mode="lines",name=label))
                st.write(f"Apparent fitted angular speed: **{motion['mu_arcsec_per_year']:.3g} arcsec/year**. This fit has not separated parallax or calibrated instrumental shifts.")
            positions.update_layout(title="Tentative position offsets against time",xaxis_title="Observation time (MJD, days)",yaxis_title="Offset (arcsec)")
            plot(positions,"positions_"+recipe)
    else:
        st.info("Motion fitting needs at least two reliable centroids in a compatible band. No motion is reported from missing or ambiguous detections.")
    with st.expander("Motion and brightness equations"):
        st.latex(r"\Delta\theta\simeq\sqrt{(\Delta\alpha\cos\bar\delta)^2+(\Delta\delta)^2}")
        st.latex(r"\mu_{\rm apparent}\simeq\Delta\theta/\Delta t,\qquad \Delta m=-2.5\log_{10}(F_2/F_1)")
        st.latex(r"S=\frac{F_2-F_1}{\sqrt{\sigma_1^2+\sigma_2^2}},\quad \bar F=\frac{\sum_iF_i/\sigma_i^2}{\sum_i1/\sigma_i^2}")
        st.latex(r"F_\nu=\sum_j a_j(I_{\nu,j}-B_{\nu,j})\Omega_j,\qquad {\rm SNR}=F_\nu/\sigma_F")
    st.subheader("Candidate repeating period")
    with st.expander("Period and phase equations"):
        st.latex(r"P=1/f_{\rm peak},\qquad \phi={\rm frac}[(t-t_0)/P]")
    period=physics.candidate_period(x,y,e)
    if period["available"]:
        pf=go.Figure(go.Scatter(x=1/period["frequency_per_day"],y=period["power"],mode="lines"))
        pf.update_layout(title="Exploratory Lomb-Scargle periodogram",xaxis_title="Trial period (days)",yaxis_title="Periodogram power",xaxis_type="log")
        plot(pf,"period_"+recipe)
        phase=go.Figure(go.Scatter(x=period["phase"],y=period["flux"],error_y=dict(type="data",array=period["errors"]),mode="markers"))
        phase.add_trace(go.Scatter(x=period["model_phase"],y=period["model_flux"],mode="lines",name="Candidate model"))
        phase.update_layout(title=f"Candidate period {period['period_days']:.3g} days",xaxis_title="Phase",yaxis_title="Aperture flux (μJy)")
        plot(phase,"phase_"+recipe)
        st.warning(period["warning"])
    else:st.info(period["reason"])
    with st.expander("Reference-star correction and stability check"):
        st.write("Compare this band with nearby candidate reference stars measured in the same exposures. Blended, low-SNR or unstable references are excluded. The result is a relative diagnostic, not an absolute recalibration.")
        correction_key=archive.digest({"recipe":recipe,"passband":[(r.get("obs_id"),r.get("detector"),r.get("mjd")) for r in band]})
        if st.button("Estimate reference-star correction",key="ensemble_"+correction_key,disabled=measurement.get("imported",False) or len(band)<3):
            with st.spinner("Checking nearby sources in the matched native exposures..."):
                st.session_state["ensemble_result_"+correction_key]=measurement_workflow.reference_correction(bundle,measurement,band)
        ensemble=st.session_state.get("ensemble_result_"+correction_key)
        if ensemble is not None:
            if ensemble.get("available"):
                corrected=[r for r in ensemble.get("rows",[]) if r.get("relative_available")]
                fig=go.Figure(go.Scatter(x=x,y=y,error_y=dict(type="data",array=e),mode="markers",name="Native aperture"))
                fig.add_trace(go.Scatter(x=[r["mjd"] for r in corrected],y=[r["relative_flux_ujy"] for r in corrected],error_y=dict(type="data",array=[r["relative_flux_err_ujy"] for r in corrected]),mode="markers",name="Reference-corrected diagnostic"))
                fig.update_layout(title="Relative ensemble comparison",xaxis_title="MJD (days)",yaxis_title="Source flux density (μJy)")
                plot(fig,"ensemble_plot_"+correction_key)
                st.caption(str(ensemble.get("note","Reference-star and calibration systematics remain.")))
                st.download_button("Download reference-correction evidence",json.dumps(safe_json(ensemble),indent=2,allow_nan=False),file_name="spherex_reference_correction.json",mime="application/json")
            else:st.info(ensemble.get("reason","No reliable reference ensemble was found."))
    return dict(measurement,good=good,band=band,motion=motion,period=period)


def _distance_inputs(scope):
    enabled=st.checkbox("I have a published parallax for this same source",value=False,key="have_parallax_"+scope)
    if not enabled:
        return None
    st.text_input("Catalogue/source reference",key="parallax_reference_"+scope,placeholder="Catalogue name, source ID or publication URL")
    fields=st.columns(2)
    p=fields[0].number_input("Parallax (mas)",value=None,format="%.5f",key="parallax_"+scope)
    error=fields[1].number_input("Parallax uncertainty (mas)",min_value=0.,value=None,format="%.5f",key="parallax_error_"+scope)
    result=physics.distance_from_parallax(p,error)
    if not result["available"]:
        st.info(result["reason"]);return None
    st.write(f"Catalogue-assisted distance: **{result['distance_pc']:.3g} ± {result['distance_error_pc']:.2g} pc**, or **{result['distance_ly']:.3g} light-years**.")
    st.caption("Approximate reciprocal distance. The app does not apply catalogue zero-point corrections or derive a new parallax from these images.")
    return result


def render_physics(bundle, measurement):
    st.subheader("Physical estimates and models")
    st.write("These calculations require additional information. Values entered here must describe the same selected source; they are labelled user-provided rather than retrieved catalogue measurements.")
    if bundle is None:
        st.info("Prepare a time viewer and select a source first.")
        return
    if measurement is None:
        st.info("Measure the selected source first, so catalogue inputs and models are attached to the correct position.")
        return
    scope=bundle["id"]+("_"+measurement["recipe"] if measurement is not None else "_no_measurement")
    catalogue=bundle.get("catalogue")
    matched_catalogue=bool(catalogue and measurement.get("catalogue_identity") and measurement["catalogue_identity"]==catalogue.get("target_key"))
    flagged_catalogue=bool(matched_catalogue and catalogue.get("distance_eligible") is False)
    if matched_catalogue:
        defaults={"parallax_":"parallax_mas","parallax_error_":"parallax_error_mas","pmra_":"pmra_mas_per_year","pmdec_":"pmdec_mas_per_year","rv_":"radial_velocity_kms"}
        for prefix,name in defaults.items():
            if catalogue.get(name) is not None:st.session_state.setdefault(prefix+scope,float(catalogue[name]))
        if catalogue.get("parallax_mas") is not None and catalogue.get("parallax_error_mas") is not None:st.session_state.setdefault("have_parallax_"+scope,True)
        if catalogue.get("pmra_mas_per_year") is not None and catalogue.get("pmdec_mas_per_year") is not None:st.session_state.setdefault("have_mu_"+scope,True)
        if catalogue.get("radial_velocity_kms") is not None:st.session_state.setdefault("have_rv_"+scope,True)
        st.session_state.setdefault("parallax_reference_"+scope,catalogue.get("source_catalogue","")+" · "+str(catalogue.get("source_id",catalogue.get("identifier",""))))
        st.caption("Catalogue defaults are attached only to the explicitly selected challenge target. You can edit them; they are not new measurements from these images.")
        if catalogue.get("source_url"):st.markdown("[Catalogue provenance]("+catalogue["source_url"]+")")
        if catalogue.get("astrometry_warning"):st.warning(str(catalogue["astrometry_warning"]))
    distance=None;vt=None;vr=None
    with st.expander("Distance, transverse speed and full space speed",expanded=True):
        st.latex(r"d_{\rm pc}\simeq1000/p_{\rm mas},\quad v_t=4.74047\,\mu_{\rm arcsec/yr}\,d_{\rm pc}")
        st.latex(r"v_{\rm space}=\sqrt{v_t^2+v_r^2}")
        allow_distance=not flagged_catalogue
        if flagged_catalogue:
            st.info("Automatic distance use is withheld because the retrieved astrometry failed a reliability check. Supplied values are retained for inspection.")
            allow_distance=st.checkbox("Use the flagged catalogue parallax only as an exploratory calculation",value=False,key="allow_flagged_parallax_"+scope)
        distance=_distance_inputs(scope) if allow_distance else None
        pmra=pmdec=None
        have_mu=st.checkbox("I have published proper motion for this same source",value=False,key="have_mu_"+scope)
        if have_mu:
            fields=st.columns(2)
            pmra=fields[0].number_input("RA proper motion including cos(Dec) (mas/year)",value=None,key="pmra_"+scope)
            pmdec=fields[1].number_input("Dec proper motion (mas/year)",value=None,key="pmdec_"+scope)
            if distance is not None and pmra is not None and pmdec is not None:
                mu=math.hypot(pmra,pmdec)/1000.
                vt=physics.transverse_speed(mu,distance["distance_pc"])
                if vt["available"]:st.metric("Catalogue-assisted transverse speed",f"{vt['transverse_kms']:.3g} km/s")
        else:
            st.caption("The preliminary image-centroid slope is not automatically treated as reliable proper motion for a physical velocity.")
        if distance is not None:
            start=float(bundle["sequence"]["metadata"][0]["mjd"])
            include_motion=pmra is not None and pmdec is not None
            model=physics.predicted_parallax_track(measurement["ra"],measurement["dec"],1000./distance["distance_pc"],
                    np.linspace(start,start+365.25,180),pmra_mas_per_year=pmra if include_motion else 0.,pmdec_mas_per_year=pmdec if include_motion else 0.)
            if model["available"]:
                fig=go.Figure(go.Scatter(x=model["x_arcsec"],y=model["y_arcsec"],mode="lines+markers",marker=dict(size=3,color=model["mjd"],colorscale="Viridis",colorbar=dict(title="Model MJD"))))
                title="Predicted annual track from supplied catalogue astrometry" if include_motion else "Parallax-only prediction; proper motion omitted"
                fig.update_layout(title=title,xaxis_title="Model east offset (arcsec)",yaxis_title="Model north offset (arcsec)",yaxis=dict(scaleanchor="x"))
                plot(fig,"parallax_model_"+scope)
                st.caption(model["warning"])
                if not include_motion:st.caption("Both published proper-motion components are needed to include motion in this prediction.")
        have_rv=st.checkbox("I have a measured catalogue radial velocity",value=False,key="have_rv_"+scope)
        if have_rv:
            vr=st.number_input("Radial velocity (km/s; positive means recession)",value=None,key="rv_"+scope)
            same_frame=st.checkbox("Velocity components refer to compatible reference frames",value=False,key="rv_frame_"+scope)
            if vt is not None and vr is not None and same_frame:
                speed=physics.space_speed(vt["transverse_kms"],vr)
                st.metric("Full space-speed magnitude",f"{speed['space_kms']:.3g} km/s")
        st.caption("Missing radial velocity remains unknown. These are user-supplied catalogue inputs, not automatic catalogue crossmatches.")

    with st.expander("Radial velocity from identified external spectral lines"):
        st.latex(r"z=(\lambda_{\rm obs}-\lambda_0)/\lambda_0,\qquad v_r\simeq cz")
        st.write("Use suitably calibrated external line measurements. Changes in SPHEREx observing bands are not Doppler shifts.")
        fields=st.columns(2)
        rest=fields[0].number_input("Identified rest wavelength (μm)",min_value=0.,value=None,format="%.8f",key="lambda_rest_"+scope)
        observed=fields[1].number_input("Measured line wavelength (μm)",min_value=0.,value=None,format="%.8f",key="lambda_observed_"+scope)
        if rest is not None and observed is not None:
            doppler=physics.doppler_velocity(observed,rest)
            if doppler["available"]:
                st.write(f"From supplied wavelengths: **{doppler['radial_kms']:+.4g} km/s**, {doppler['direction']}.")
                st.caption(doppler["warning"])
            else:st.info(doppler["reason"])

    with st.expander("Band luminosity and bolometric luminosity"):
        st.latex(r"L=4\pi d^2F,\quad F_{\rm bol}=\int F_\nu\,d\nu")
        if distance is None:
            st.info("Enter a reliable catalogue parallax above before calculating luminosity.")
        stable=st.checkbox("Assume the selected source is spectrally stable across the sampled dates",value=False,key="stable_lum_"+scope)
        good=measurement.get("good",[]) if measurement else []
        if stable and len(good)>=2:
            # One best-SNR sample per rounded centre avoids duplicate wavelength integration.
            unique={}
            for r in good:
                key=round(r["wavelength_um"],5)
                if key not in unique or r["snr"]>unique[key]["snr"]:unique[key]=r
            samples=list(unique.values())
            integrated=physics.integrate_band_flux([r["wavelength_um"] for r in samples],[r["flux_ujy"] for r in samples],[r["flux_err_ujy"] for r in samples])
            if integrated["available"]:
                st.write(f"Illustrative aperture-flux integral from {integrated['wavelength_min_um']:.3g} to {integrated['wavelength_max_um']:.3g} μm: **{integrated['flux_w_m2']:.3g} W/m²**.")
                st.caption(integrated["warning"]+" No total-flux aperture correction is applied.")
                if distance is not None:
                    lum=physics.luminosity(distance["distance_pc"],integrated["flux_w_m2"])
                    if lum["available"]:st.write(f"Corresponding illustrative aperture-band luminosity: **{lum['luminosity_w']:.3g} W**. This is not total stellar luminosity.")
            else:st.info(integrated["reason"])
        bolometric=st.number_input("Externally calibrated bolometric flux (W/m²)",min_value=0.,value=None,format="%.6e",key="fbol_"+scope)
        if bolometric is not None and distance is not None:
            result=physics.luminosity(distance["distance_pc"],bolometric)
            if result["available"]:st.write(f"From supplied bolometric flux: **{result['luminosity_w']:.3g} W = {result['luminosity_solar']:.3g} solar luminosities**. Extinction and bolometric corrections must already be handled.")
            else:st.info(result["reason"])
        if distance is not None and measurement.get("band"):
            band=measurement["band"]
            factor=4*np.pi*(distance["distance_pc"]*physics.PC_M)**2*1e-32
            fig=go.Figure(go.Scatter(x=[r["mjd"] for r in band],y=[r["flux_ujy"]*factor for r in band],error_y=dict(type="data",array=[r["flux_err_ujy"]*factor for r in band]),mode="markers"))
            fig.update_layout(title="Illustrative aperture spectral luminosity density",xaxis_title="Observation time (MJD, days)",yaxis_title="Aperture Lν (W/Hz)")
            plot(fig,"luminosity_time_"+scope)
            st.caption("Lν = 4πd²Fν is luminosity per frequency interval, not bolometric luminosity. Error bars show formal flux errors; distance and aperture/calibration uncertainties are additional.")

    with st.expander("Exploratory thermal model"):
        st.latex(r"T[\mathrm{K}]\simeq2898/\lambda_{\rm peak}[\mu\mathrm{m}]")
        st.write("Wien's relation uses the wavelength-density blackbody peak. The fit below models Fν directly; its peak differs. Molecular absorption, clouds, calibration and non-simultaneous observations may invalidate a blackbody model.")
        thermal=st.checkbox("Try an illustrative Planck fit; assume stable brightness and accept aperture/response limitations",value=False,key="thermal_"+scope)
        good=measurement.get("good",[]) if measurement else []
        if thermal:
            fit=physics.fit_blackbody_fnu([r["wavelength_um"] for r in good],[r["flux_ujy"] for r in good],[r["flux_err_ujy"] for r in good])
            if fit["available"]:
                st.write(f"Exploratory thermal-model estimate: **{fit['temperature_k']:.3g} ± {fit['temperature_error_k']:.2g} K**.")
                fig=go.Figure(go.Scatter(x=[r["wavelength_um"] for r in good],y=[r["flux_ujy"] for r in good],error_y=dict(type="data",array=[r["flux_err_ujy"] for r in good]),mode="markers",name="Aperture data"))
                fig.add_trace(go.Scatter(x=fit["model_wavelength_um"],y=fit["model_flux_ujy"],mode="lines",name="Illustrative Planck fit"))
                fig.update_layout(xaxis_title="Wavelength (μm)",yaxis_title="Source flux density (μJy)")
                plot(fig,"thermal_plot_"+scope)
                st.warning(fit["warning"])
            else:st.info(fit["reason"])

    with st.expander("Known-orbit educational model"):
        st.latex(r"P^2=\frac{4\pi^2a^3}{G(M+m)}")
        st.write("Enter established orbital information. This model does not infer an orbit from the displayed sky images.")
        solve=st.radio("Calculate",["Period from semimajor axis","Semimajor axis from period"],horizontal=True,key="orbit_solve_"+scope)
        fields=st.columns(3)
        mass=fields[0].number_input("Central mass (solar masses)",min_value=0.,value=None,key="orbit_mass_"+scope)
        if solve=="Period from semimajor axis":
            axis=fields[1].number_input("Established semimajor axis (AU)",min_value=0.,value=None,key="orbit_axis_"+scope)
            supplied_period=None
        else:
            supplied_period=fields[1].number_input("Established orbital period (years)",min_value=0.,value=None,key="orbit_period_"+scope)
            axis=None
        companion=fields[2].number_input("Companion mass (solar masses)",min_value=0.,value=0.,key="orbit_companion_"+scope)
        if mass is not None and (axis is not None or supplied_period is not None):
            orbit=physics.kepler_period(axis,mass,companion) if axis is not None else physics.kepler_semimajor_axis(supplied_period,mass,companion)
            if orbit["available"]:
                axis=orbit["semimajor_axis_au"]
                st.write(f"Two-body result from supplied inputs: **{orbit['period_years']:.4g} years**, semimajor axis **{axis:.4g} AU**.")
                phase=np.linspace(0,2*np.pi,200)
                fig=go.Figure(go.Scatter(x=axis*np.cos(phase),y=axis*np.sin(phase),mode="lines",name="Circular illustration"))
                fig.update_layout(title="Circular illustration at the supplied semimajor axis",xaxis_title="Model x (AU)",yaxis_title="Model y (AU)",yaxis=dict(scaleanchor="x"))
                plot(fig,"orbit_plot_"+scope)
                st.caption("This illustration assumes zero eccentricity and a face-on orientation. It is not a recovered orbit.")
            else:st.info(orbit["reason"])

    with st.expander("All 16 analysis modules and their requirements"):
        items=[
            ("1 Time intervals","Available from the loaded observation timestamps"),
            ("2 Angular displacement","Requires at least two reliable source centroids"),
            ("3 Angular motion","Apparent centroid fit only; calibration and parallax are not removed"),
            ("4 Distance","User-provided reliable parallax and uncertainty"),
            ("5 Transverse speed","Reliable distance and supplied catalogue proper motion"),
            ("6 Brightness changes","Native-image aperture measurements in compatible bands"),
            ("7 Change/noise","Compatible fluxes, uncertainty and systematic-error assessment"),
            ("8 Spectral shape","Native aperture fluxes; wavelength and response limitations apply"),
            ("9 Time-wavelength diagram","Actual measured points; no invented coverage"),
            ("10 Difference image","Quality-masked WCS-grid preview with optional median-Gaussian sharpness matching and registration gates; spatial ePSF matching is not implemented"),
            ("11 Stacking","Weighted display preview and independent-error aperture-flux mean"),
            ("12 Candidate period","At least 12 distinct compatible-band time samples and suitable cadence"),
            ("13 Radial velocity","Supplied catalogue velocity or identified external spectral lines"),
            ("14 Luminosity","Reliable distance plus calibrated flux or explicitly illustrative aperture-band estimate"),
            ("15 Temperature","Conditional thermal model; adequate coverage must bracket its peak"),
            ("16 Orbit","Two-body calculation, circular illustration and position/speed-time graphs from established inputs; no recovered orbit"),
        ]
        st.dataframe([{"Module":a,"Requirement / interpretation":b} for a,b in items],hide_index=True)
