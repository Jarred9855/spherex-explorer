"""Diagnostic native-image aperture photometry and tentative source positions.

All fluxes are *uncorrected aperture fluxes*, not total source photometry.
Errors use independent pixels and an estimated local-background uncertainty.
Pixel solid angle is a local WCS Jacobian approximation, not the mission's
precision solid-angle calibration. Header-defined SOURCE and FULLSAMPLE flags
are retained; other or unknown quality bits are rejected conservatively.
WCS-WAVE wavelengths are visualization estimates. These measurements should
not be advertised as research-calibrated spectra or absolute astrometry.
"""

from pathlib import Path
import math
import re

import numpy as np
import astropy.units as u
from astropy.coordinates import SkyCoord
from astropy.io import fits
from astropy.stats import sigma_clipped_stats, sigma_clip
from astropy.time import Time
from astropy.wcs import WCS


METHOD_NOTE = (
    "Diagnostic native-image aperture flux; no aperture correction or PSF "
    "deblending. Local WCS solid-angle approximation. Errors assume independent "
    "pixels and omit calibration systematics. WCS-WAVE is visualization-level."
)


def _finite_float(value):
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def _read_native(path):
    with fits.open(path, memmap=False) as hdul:
        image = np.array(hdul["IMAGE"].data, dtype=float, copy=True)
        header = hdul["IMAGE"].header.copy()
        if image.ndim != 2 or not np.isfinite(image).any():
            raise ValueError("A finite two-dimensional IMAGE extension is required.")
        variance = np.array(hdul["VARIANCE"].data, dtype=float, copy=True) if "VARIANCE" in hdul else None
        flags = np.array(hdul["FLAGS"].data, copy=True) if "FLAGS" in hdul else None
        flag_header = hdul["FLAGS"].header.copy() if "FLAGS" in hdul else None
    if variance is not None and variance.shape != image.shape:
        variance = None
    if flags is not None and flags.shape != image.shape:
        flags = None
    return image, header, variance, flags, flag_header


def _quality_masks(flags, flag_header, shape):
    """Interpret bit names from this file, keeping SOURCE/FULLSAMPLE useful."""
    if flags is None or flag_header is None:
        return np.zeros(shape, dtype=bool), np.zeros(shape, dtype=bool), {}
    definitions = {}
    for name in flag_header:
        if re.fullmatch(r"MSKN\d{4}", name):
            suffix = name[-4:]
            bit = int(flag_header.get("MSKM" + suffix, 1 << int(suffix)))
            definitions[bit] = str(flag_header[name]).strip().upper()
    known_mask, bad_mask, source_mask = 0, 0, 0
    for bit, name in definitions.items():
        known_mask |= bit
        if name == "SOURCE":
            source_mask |= bit
        if name not in {"SOURCE", "FULLSAMPLE"}:
            bad_mask |= bit
    values = flags.astype(np.int64)
    bad = ((values & bad_mask) != 0) | ((values & ~known_mask) != 0)
    source = (values & source_mask) != 0
    return bad, source, definitions


def quality_mask(flags, flag_header, shape):
    """Shared conservative flag interpretation for native photometry and movies."""
    bad, source, definitions = _quality_masks(flags, flag_header, shape)
    return {"bad": bad, "source": source, "definitions": definitions,
            "available": flags is not None and flag_header is not None,
            "known": flags is not None and bool(definitions)}


def estimate_psf_width(image, header, bad_mask=None, max_stars=12):
    """Approximate circular FWHM, never a replacement for the spatial ePSF.

    Prefer a header PSF_FWHM with explicit angular/pixel units. Otherwise fit
    isolated, unflagged local peaks and require at least three agreeing fits.
    Widths are for conservative smoothing/association diagnostics only.
    """
    from scipy.ndimage import maximum_filter
    from scipy.optimize import least_squares

    image = np.asarray(image, dtype=float)
    bad = np.zeros(image.shape, bool) if bad_mask is None else np.asarray(bad_mask, bool)
    result = {"available": False, "fwhm_arcsec": None, "fwhm_pixels": None,
              "method": "unavailable", "approximate": True, "n_stars": 0,
              "scatter_arcsec": None}
    try:
        wcs = WCS(header).celestial
        scale, _ = _local_geometry(wcs, (image.shape[1]-1)/2, (image.shape[0]-1)/2)
    except (ValueError, TypeError, AttributeError):
        return result
    value = _finite_float(header.get("PSF_FWHM"))
    comment = str(header.comments["PSF_FWHM"]).lower() if "PSF_FWHM" in header else ""
    units = str(header.get("PSFUNITS", "")).lower()
    if value is not None and value > 0:
        angular = any(word in comment + " " + units for word in ["arcsec", "asec"])
        pixels = any(word in comment + " " + units for word in ["pixel", " pix", "[pix]"])
        if angular or pixels:
            fwhm_arcsec = value if angular else value * scale
            if 0.25 <= fwhm_arcsec / scale <= 20:
                return dict(result, available=True, fwhm_arcsec=fwhm_arcsec,
                            fwhm_pixels=fwhm_arcsec/scale,
                            method="header median PSF_FWHM; circular-Gaussian approximation")
    clean = np.where(np.isfinite(image) & ~bad, image, np.nan)
    if np.isfinite(clean).sum() < 100:
        return result
    background, noise = _background(clean)
    excess = np.where(np.isfinite(clean), clean-background, -np.inf)
    peaks = (excess == maximum_filter(excess, size=3, mode="constant", cval=-np.inf)) & (excess > 8*noise)
    py, px = np.nonzero(peaks)
    order = np.argsort(excess[py, px])[::-1]
    measured = []
    for index in order:
        x, y = int(px[index]), int(py[index])
        radius = 6
        if min(x, y, image.shape[1]-1-x, image.shape[0]-1-y) < radius:
            continue
        neighbour_distance = np.hypot(px-x, py-y)
        if np.any((neighbour_distance > 0) & (neighbour_distance < 2*radius)):
            continue
        patch = clean[y-radius:y+radius+1, x-radius:x+radius+1]
        if not np.isfinite(patch).all():
            continue
        yy, xx = np.indices(patch.shape, dtype=float)
        initial = [float(np.max(patch)-background), float(radius), float(radius), 1.3, background]
        def residual(parameters):
            amplitude, cx, cy, sigma, offset = parameters
            model = offset + amplitude*np.exp(-((xx-cx)**2+(yy-cy)**2)/(2*sigma*sigma))
            return ((model-patch)/noise).ravel()
        fit = least_squares(residual, initial,
                            bounds=([0, radius-1, radius-1, 0.35, -np.inf],
                                    [np.inf, radius+1, radius+1, 4.0, np.inf]),
                            loss="soft_l1", max_nfev=150)
        sigma = float(fit.x[3])
        if fit.success and .4 < sigma < 3.8 and np.sqrt(np.mean(residual(fit.x)**2)) < 3:
            measured.append(2.354820045*sigma*scale)
        if len(measured) >= int(max_stars):
            break
    if len(measured) < 3:
        return result
    median = float(np.median(measured))
    scatter = float(1.4826*np.median(np.abs(np.asarray(measured)-median)))
    if scatter > .25*median:
        return dict(result, method="inconsistent measured widths", n_stars=len(measured))
    return dict(result, available=True, fwhm_arcsec=median, fwhm_pixels=median/scale,
                method="robust isolated-star circular Gaussian fits", n_stars=len(measured),
                scatter_arcsec=scatter)


def _flag_summary(flags, definitions, weights):
    selected = weights > 0.01
    if flags is None or not selected.any():
        return None, None, []
    values = flags[selected].astype(np.int64)
    combined = int(np.bitwise_or.reduce(values))
    total = sum(definitions)
    names = [name for bit, name in sorted(definitions.items()) if combined & bit]
    if combined & ~total:
        names.append("UNKNOWN_BITS")
    fraction = float(np.sum(weights[selected] * (values != 0)) / np.sum(weights[selected]))
    return combined, fraction, names


def _background(image, variance=None):
    _, median, std = sigma_clipped_stats(image[np.isfinite(image)], sigma=3.0, maxiters=5)
    median, std = float(median), float(std)
    if not math.isfinite(std) or std <= 0:
        if variance is not None:
            values = variance[np.isfinite(variance) & (variance > 0)]
            if values.size:
                std = float(np.sqrt(np.median(values)))
    if not math.isfinite(std) or std <= 0:
        std = max(abs(median) * 1e-8, np.finfo(float).eps)
    return median, std


def _local_geometry(wcs, x, y):
    """Return local equivalent pixel scale [arcsec] and area [steradian]."""
    centre = wcs.pixel_to_world(x, y)
    left = wcs.pixel_to_world(x - 0.5, y)
    right = wcs.pixel_to_world(x + 0.5, y)
    lower = wcs.pixel_to_world(x, y - 0.5)
    upper = wcs.pixel_to_world(x, y + 0.5)
    lx, ly = centre.spherical_offsets_to(left)
    rx, ry = centre.spherical_offsets_to(right)
    bx, by = centre.spherical_offsets_to(lower)
    tx, ty = centre.spherical_offsets_to(upper)
    jacobian = np.array([
        [(rx - lx).to_value(u.arcsec), (tx - bx).to_value(u.arcsec)],
        [(ry - ly).to_value(u.arcsec), (ty - by).to_value(u.arcsec)],
    ])
    area_arcsec2 = abs(float(np.linalg.det(jacobian)))
    if not math.isfinite(area_arcsec2) or area_arcsec2 <= 0:
        raise ValueError("The local WCS pixel area could not be calculated.")
    omega = area_arcsec2 * u.arcsec.to(u.rad) ** 2
    return math.sqrt(area_arcsec2), omega


def _refine_peak(image, x_peak, y_peak, background, predicted=None, max_shift=None):
    """Bounded positive-signal moments, not a calibrated PSF centroid fit."""
    iy, ix = np.indices(image.shape)
    window = (abs(ix - x_peak) <= 2) & (abs(iy - y_peak) <= 2)
    if predicted is not None and max_shift is not None:
        window &= (ix - predicted[0]) ** 2 + (iy - predicted[1]) ** 2 <= max_shift ** 2
    weight = np.where(window & np.isfinite(image), np.maximum(image - background, 0), 0)
    total = float(weight.sum())
    if total <= 0:
        return float(x_peak), float(y_peak), None
    x = float((weight * ix).sum() / total)
    y = float((weight * iy).sum() / total)
    width = math.sqrt(max(float((weight * ((ix - x) ** 2 + (iy - y) ** 2)).sum() / (2 * total)), 0))
    return x, y, width


def detect_sources(path, region=None, max_sources=30, threshold_sigma=5.0):
    """Return tentative local maxima as selectable candidates.

    Each dict has id, ra_deg, dec_deg, x, y, peak_snr and status. Neither a
    local maximum nor its infrared colour establishes the object's identity.
    ``region`` is accepted for the viewer API; positions come from native WCS.
    """
    from scipy.ndimage import maximum_filter

    if threshold_sigma <= 0 or not 1 <= int(max_sources) <= 200:
        raise ValueError("Use a positive threshold and 1-200 source candidates.")
    image, header, variance, pixel_flags, flag_header = _read_native(path)
    bad, _, _ = _quality_masks(pixel_flags, flag_header, image.shape)
    image = np.where(bad, np.nan, image)
    if not np.isfinite(image).any():
        return []
    wcs = WCS(header).celestial
    background, noise = _background(image, variance)
    excess = np.where(np.isfinite(image), image - background, -np.inf)
    peaks = (excess == maximum_filter(excess, size=3, mode="constant", cval=-np.inf))
    peaks &= excess > threshold_sigma * noise
    # Edge peaks cannot support a small centroid window.
    peaks[:2, :] = peaks[-2:, :] = False
    peaks[:, :2] = peaks[:, -2:] = False
    yy, xx = np.nonzero(peaks)
    order = np.argsort(excess[yy, xx])[::-1]
    candidates = []
    for number in order:
        px, py = int(xx[number]), int(yy[number])
        x, y, _ = _refine_peak(image, px, py, background)
        scale, _ = _local_geometry(wcs, x, y)
        gy, gx = np.indices(image.shape)
        # Candidate defaults should support the viewer's default 12-arcsec aperture.
        if np.any(bad & ((gx - x) ** 2 + (gy - y) ** 2 <= (12.0 / scale + 0.5) ** 2)):
            continue
        if any((x - old["x"]) ** 2 + (y - old["y"]) ** 2 < 4 for old in candidates):
            continue
        sky = wcs.pixel_to_world(x, y).icrs
        candidates.append({
            "id": len(candidates) + 1,
            "ra_deg": float(sky.ra.deg), "dec_deg": float(sky.dec.deg),
            "x": x, "y": y,
            "peak_snr": float(excess[py, px] / noise),
            "status": "tentative local maximum",
        })
        if len(candidates) >= int(max_sources):
            break
    return candidates


def _wavelength(path, header, x, y):
    try:
        spectral_header = header.copy()
        for name in list(spectral_header):
            if re.fullmatch(r"(A|B|AP|BP)_(ORDER|\d+_\d+)", name):
                del spectral_header[name]
        with fits.open(path, memmap=False) as hdul:
            spectral = WCS(spectral_header, fobj=hdul, key="W")
            spectral.sip = None
            wavelength, bandwidth = spectral.pixel_to_world(x, y)
            wave = float(wavelength.to_value(u.um))
            width = float(bandwidth.to_value(u.um))
        if wave > 0 and width > 0 and math.isfinite(wave) and math.isfinite(width):
            return wave, width
    except (KeyError, ValueError, TypeError, AttributeError, OSError, u.UnitConversionError):
        pass
    return None, None


def _base_result(path, ra, dec):
    return {
        "path": str(path), "input_ra_deg": float(ra), "input_dec_deg": float(dec),
        "status": "unavailable", "method": "native uncorrected aperture flux",
        "method_note": METHOD_NOTE, "mjd": None, "date": "Unknown", "detector": "Unknown",
        "flux_ujy": None, "flux_err_ujy": None, "snr": None, "SNR": None,
        "upper_limit_ujy": None, "upper_limit_kind": None,
        "wavelength_um": None, "central_wavelength_um": None, "bandwidth_um": None,
        "source_ra_deg": None, "source_dec_deg": None,
        "centroid_x": None, "centroid_y": None,
        "centroid_offset_arcsec": None, "association_uncertain": False,
        "blended_source": False, "neighbour_count": 0,
        "psf_fwhm_arcsec": None, "psf_method": "unavailable",
        "background_systematic_proxy_ujy": None,
        "centroid_valid": False, "usable_for_astrometry": False,
        "position_error_arcsec": None, "centroid_error_arcsec_approx": None,
        "astrometric_error_calibrated": False, "detected": False, "usable_flux": False,
        "pixel_flags_or": None, "flagged_aperture_fraction": None,
        "quality_flag_names": [], "flags": [],
        "quality_checked": False, "bad_aperture_fraction": None,
        "background_mode": None, "background_contamination_risk": False,
        "aperture_coverage": None, "annulus_coverage": None,
        "target_x": None, "target_y": None,
        "aperture_x": None, "aperture_y": None,
        "warnings": [],
    }


def measure_source(path, ra, dec, aperture_arcsec=12.0, annulus_inner=18.0,
                   annulus_outer=30.0, follow_centroid=True, search_radius_arcsec=12.0):
    """Measure a selected position in one native SPHEREx cutout.

    Aperture and annulus radii are arcseconds. ``follow_centroid`` finds a
    significant nearby peak within a bounded search radius. Ambiguous peaks
    retain the predicted position and are excluded from astrometry. Missing
    detections retain their measured forced flux when possible, with a labelled
    conservative 3-sigma upper-limit estimate, rather than an invented zero.
    """
    from scipy.ndimage import maximum_filter
    from photutils.aperture import CircularAperture, CircularAnnulus

    if not (0 < aperture_arcsec < annulus_inner < annulus_outer):
        raise ValueError("Use 0 < aperture radius < annulus inner radius < annulus outer radius.")
    if not (0 < search_radius_arcsec <= 60):
        raise ValueError("The centroid search radius must be between 0 and 60 arcseconds.")
    sky = SkyCoord(float(ra), float(dec), unit="deg", frame="icrs")
    row = _base_result(path, sky.ra.deg, sky.dec.deg)
    image, header, variance, pixel_flags, flag_header = _read_native(path)
    bad_pixels, source_pixels, definitions = _quality_masks(pixel_flags, flag_header, image.shape)
    row["quality_checked"] = bool(pixel_flags is not None and definitions)
    row["date"] = str(header.get("DATE-OBS", "Unknown"))
    row["mjd"] = _finite_float(header.get("MJD-OBS"))
    if row["mjd"] is None and row["date"] != "Unknown":
        try:
            row["mjd"] = float(Time(row["date"]).mjd)
        except ValueError:
            pass
    try:
        brightness_unit = u.Unit(header.get("BUNIT", ""))
        brightness_factor = float((1 * brightness_unit).to_value(u.MJy / u.sr))
    except (ValueError, TypeError, u.UnitConversionError):
        row["status"] = "unsupported_brightness_unit"
        row["warnings"].append("Source flux requires a calibrated surface-brightness unit such as MJy/sr.")
        return row
    image *= brightness_factor
    if variance is not None:
        variance *= brightness_factor ** 2
    wcs = WCS(header).celestial
    px, py = wcs.world_to_pixel(sky)
    px, py = float(px), float(py)
    row["target_x"], row["target_y"] = px, py
    if not (math.isfinite(px) and math.isfinite(py) and 0 <= px < image.shape[1] and 0 <= py < image.shape[0]):
        row["status"] = "outside_image"
        row["warnings"].append("The selected object position is outside this native image.")
        return row
    scale, omega = _local_geometry(wcs, px, py)
    row["pixel_scale_arcsec"] = scale
    row["pixel_solid_angle_sr_approx"] = omega
    clean_image = np.where(bad_pixels, np.nan, image)
    if not np.isfinite(clean_image).any():
        row["status"] = "bad_quality_flags"
        row["warnings"].append("All pixels have unusable or unknown quality flags.")
        return row
    background, noise = _background(clean_image, variance)
    psf = estimate_psf_width(image, header, bad_pixels)
    row["psf_fwhm_arcsec"] = psf["fwhm_arcsec"]
    row["psf_method"] = psf["method"]
    yy, xx = np.indices(image.shape)
    cx, cy, moment_width = px, py, None
    peak_found, ambiguous = False, False
    excess = np.where(np.isfinite(image) & ~bad_pixels, image-background, -np.inf)
    all_peaks = (excess == maximum_filter(excess, size=3, mode="constant", cval=-np.inf)) & (excess > 3*noise)
    all_ys, all_xs = np.nonzero(all_peaks)
    if follow_centroid:
        radius = max(search_radius_arcsec / scale, 0.5)
        excess = np.where(np.isfinite(image) & ~bad_pixels, image - background, -np.inf)
        peaks = (excess == maximum_filter(excess, size=3, mode="constant", cval=-np.inf))
        peaks &= excess > 3 * noise
        peaks &= (xx - px) ** 2 + (yy - py) ** 2 <= radius ** 2
        ys, xs = np.nonzero(peaks)
        if len(xs) == 1:
            cx, cy, moment_width = _refine_peak(clean_image, int(xs[0]), int(ys[0]), background, (px, py), radius)
            peak_found = True
            offset = math.hypot(cx-px, cy-py)*scale
            row["centroid_offset_arcsec"] = offset
            association_limit = min(.8*search_radius_arcsec, psf["fwhm_arcsec"] or search_radius_arcsec)
            if offset > association_limit:
                row["association_uncertain"] = True
                row["warnings"].append("The nearest peak moved too far from the supplied position for a secure association; the aperture stays fixed.")
                cx, cy, moment_width, peak_found = px, py, None, False
        elif len(xs) > 1:
            ambiguous = True
            row["warnings"].append("Multiple nearby peaks: the aperture stays at the predicted position; no motion point is reported.")
        else:
            row["warnings"].append("No significant nearby peak: this is a forced aperture measurement at the selected position.")
    else:
        row["warnings"].append("Fixed-position aperture: no centroid position or motion measurement is inferred.")
    peak_distances = np.hypot(all_xs-cx, all_ys-cy)*scale
    core_radius = max(.75*scale, .5*(psf["fwhm_arcsec"] or scale))
    blend_radius = aperture_arcsec + .5*(psf["fwhm_arcsec"] or scale)
    row["neighbour_count"] = int(np.sum((peak_distances > core_radius) & (peak_distances < blend_radius)))
    row["blended_source"] = bool(row["neighbour_count"] > 0 or ambiguous)
    if row["blended_source"]:
        row["warnings"].append("A second significant peak can contaminate this source aperture. Individual-source flux and motion are withheld without PSF deblending.")
    row["aperture_x"], row["aperture_y"] = cx, cy
    wavelength, bandwidth = _wavelength(path, header, cx, cy)
    row["wavelength_um"] = row["central_wavelength_um"] = wavelength
    row["bandwidth_um"] = bandwidth
    # Exact circular-overlap weights; use a local equivalent pixel scale.
    aperture = CircularAperture((cx, cy), r=aperture_arcsec / scale)
    annulus = CircularAnnulus((cx, cy), r_in=annulus_inner / scale, r_out=annulus_outer / scale)
    aw = aperture.to_mask(method="exact").to_image(image.shape)
    bw = annulus.to_mask(method="exact").to_image(image.shape)
    if aw is None or bw is None:
        row["status"] = "insufficient_aperture_coverage"
        return row
    combined, flagged_fraction, names = _flag_summary(pixel_flags, definitions, aw)
    row["pixel_flags_or"] = combined
    row["flagged_aperture_fraction"] = flagged_fraction
    row["quality_flag_names"] = row["flags"] = names
    bad_fraction = float(np.sum(aw[bad_pixels]) / aperture.area)
    row["bad_aperture_fraction"] = bad_fraction
    if bad_fraction > 1e-8:
        row["status"] = "bad_quality_flags"
        row["warnings"].append("The source aperture includes unusable quality flags: " + ", ".join(name for name in names if name not in {"SOURCE", "FULLSAMPLE"}) + ". Flux and motion are withheld.")
        return row
    valid = np.isfinite(image)
    aperture_area = float(np.sum(aw[valid]))
    aperture_coverage = aperture_area / float(aperture.area)
    background_valid = valid & ~bad_pixels & ~source_pixels
    annulus_coverage = float(np.sum(bw[background_valid])) / float(annulus.area)
    row["background_mode"] = "source-masked sigma-clipped annulus"
    row["background_contamination_risk"] = False
    # SOURCE can cover essentially an entire crowded Galactic field. Retain
    # such pixels only in a clearly labelled diagnostic fallback, never defects.
    if annulus_coverage < 0.75 or np.sum(background_valid & (bw > 0.5)) < 20:
        background_valid = valid & ~bad_pixels
        annulus_coverage = float(np.sum(bw[background_valid])) / float(annulus.area)
        row["background_mode"] = "SOURCE-retaining sigma-clipped annulus (diagnostic)"
        row["background_contamination_risk"] = True
        row["warnings"].append("Crowded-field background: too few SOURCE-free pixels. A clipped annulus retaining SOURCE is used; blending/background systematics are not quantified.")
    row["aperture_coverage"] = aperture_coverage
    row["annulus_coverage"] = annulus_coverage
    row["aperture_radius_arcsec"] = float(aperture_arcsec)
    if aperture_coverage < 0.98:
        row["status"] = "aperture_truncated"
        row["warnings"].append("Missing aperture pixels would bias the flux. Choose a larger field or a position farther from the edge.")
        return row
    annulus_values = image[background_valid & (bw > 0.5)]
    clipped = sigma_clip(annulus_values, sigma=3, maxiters=5).compressed()
    if annulus_coverage < 0.75 or clipped.size < 20:
        row["status"] = "insufficient_background"
        row["warnings"].append("Too little background remains after source/quality masking; choose a larger field or adjust the aperture/annulus.")
        return row
    local_background = float(np.median(clipped))
    local_noise = float(np.std(clipped, ddof=1))
    background_error = 1.253314 * local_noise / math.sqrt(clipped.size)
    row["background_mjy_sr"] = local_background
    row["background_err_mjy_sr_approx"] = background_error
    row["background_pixels"] = int(clipped.size)
    # MJy/sr * sr -> MJy; 1 MJy = 1e12 microJy.
    conversion = omega * 1e12
    flux = float(np.sum(aw[valid] * (image[valid] - local_background))) * conversion
    selection = valid & (aw > 0)
    if variance is not None and np.all(np.isfinite(variance[selection]) & (variance[selection] >= 0)):
        pixel_variance = float(np.sum(aw[selection] ** 2 * variance[selection]))
        row["uncertainty_kind"] = "VARIANCE plus estimated background error; independent pixels"
    else:
        pixel_variance = float(np.sum(aw[selection] ** 2)) * local_noise ** 2
        row["uncertainty_kind"] = "background-scatter error estimate; independent pixels"
        row["warnings"].append("A usable VARIANCE image was unavailable; flux uncertainty is estimated from background scatter.")
    variance_flux = (pixel_variance + aperture_area ** 2 * background_error ** 2) * conversion ** 2
    error = math.sqrt(max(variance_flux, 0))
    if not math.isfinite(error) or error <= 0:
        row["status"] = "uncertainty_unavailable"
        row["flux_ujy"] = flux
        row["warnings"].append("A positive flux uncertainty could not be estimated.")
        return row
    snr = flux / error
    row.update(flux_ujy=flux, flux_err_ujy=error, snr=snr, SNR=snr, usable_flux=True)
    confirmed_fixed_peak = bool(np.any(peak_distances < core_radius))
    row["detected"] = bool(snr >= 3 and not ambiguous and not row["association_uncertain"]
                           and (peak_found or (not follow_centroid and confirmed_fixed_peak)))
    row["status"] = "ok" if row["detected"] else "low_snr_or_unconfirmed"
    # Annulus sectors expose nonuniform backgrounds as a diagnostic systematic
    # proxy. This is not a calibrated one-sigma uncertainty.
    sector_values = []
    angle = np.arctan2(yy-cy, xx-cx)
    for lower in [-math.pi, -.5*math.pi, 0, .5*math.pi]:
        values = image[background_valid & (bw > .5) & (angle >= lower) & (angle < lower+.5*math.pi)]
        clipped_sector = sigma_clip(values, sigma=3, maxiters=5).compressed()
        if clipped_sector.size >= 5:
            sector_values.append(float(np.median(clipped_sector)))
    if len(sector_values) >= 3:
        proxy = .5*(max(sector_values)-min(sector_values))*aperture_area*conversion
        row["background_systematic_proxy_ujy"] = proxy
        if proxy > .5*max(abs(flux), error):
            row["usable_flux"] = False
            row["status"] = "unstable_background"
            row["warnings"].append("Background sector differences are large relative to the source flux; the source measurement is withheld.")
    if row["blended_source"] or row["association_uncertain"]:
        row["usable_flux"] = False
        row["detected"] = False
        row["status"] = "blended_source" if row["blended_source"] else "uncertain_association"
    if not row["detected"]:
        row["upper_limit_ujy"] = max(0.0, flux) + 3 * error
        row["upper_limit_kind"] = "conservative max(measured flux, 0) + 3 sigma; Gaussian-noise approximation"
    if peak_found and not ambiguous and snr >= 5 and row["usable_flux"]:
        measured = wcs.pixel_to_world(cx, cy).icrs
        row.update(source_ra_deg=float(measured.ra.deg), source_dec_deg=float(measured.dec.deg),
                   centroid_x=cx, centroid_y=cy, centroid_valid=True, usable_for_astrometry=True)
        if moment_width is not None:
            sigma_pixels = max(moment_width, (psf["fwhm_pixels"] or 0)/2.354820045)
            row["centroid_error_arcsec_approx"] = float(sigma_pixels*scale/snr)
    elif peak_found and snr < 5:
        row["warnings"].append("Centroid not used for motion: aperture SNR is below 5.")
    if pixel_flags is None:
        row["warnings"].append("No FLAGS image is available for this measurement.")
    return row


def extract_series(frames, ra, dec, aperture_arcsec=12.0, annulus_inner=18.0,
                   annulus_outer=30.0, follow_centroid=True, search_radius_arcsec=12.0):
    """Return one result per native FITS frame, retaining unavailable rows.

    Frame dictionaries use the viewer's {path, record:{mjd,date,detector,...}}
    format. No reprojected array is accepted, preventing interpolation from
    being mistaken for native calibrated photometry.
    """
    rows = []
    for frame in frames:
        record = frame.get("record", {})
        path = frame.get("path", "")
        try:
            row = measure_source(path, ra, dec, aperture_arcsec, annulus_inner,
                                 annulus_outer, follow_centroid, search_radius_arcsec)
        except (OSError, ValueError, KeyError, TypeError) as error:
            row = _base_result(path, ra, dec)
            row["warnings"].append("Measurement unavailable: " + str(error))
        if row["mjd"] is None:
            row["mjd"] = _finite_float(record.get("mjd"))
        if row["date"] == "Unknown":
            row["date"] = str(record.get("date", "Unknown"))
        row["detector"] = str(record.get("detector", "Unknown"))
        row["obs_id"] = str(record.get("obs_id", ""))
        row["collection"] = str(record.get("collection", ""))
        row["source_url"] = str(record.get("url", ""))
        rows.append(row)
    return sorted(rows, key=lambda row: (row["mjd"] is None, row["mjd"] or 0))


def relative_ensemble_correction(target_rows, reference_series, min_references=3,
                                wavelength_tolerance=.01, max_reference_scatter=.20):
    """Optional relative transparency correction using independent field sources.

    reference_series is a list of per-reference extract_series row lists, all
    measured in the same exposures. Require comparable wavelengths and >=3
    usable epochs per reference. Variable/blended/flag-rejected references are
    removed. This assumes a majority of references are intrinsically constant;
    it is not absolute photometric calibration or proof of target variability.
    """
    result = {"available":False,"rows":[],"reference_stars":0,
              "rejected_references":[],"diagnostic_only":True,
              "method":"Robust median of normalized field-reference aperture fluxes.",
              "note":"Approximate independent-error propagation only; reference normalization, shared backgrounds, aperture/PSF effects and calibration covariance are not fully propagated."}
    if min_references<3 or not 0<wavelength_tolerance<=.05:
        raise ValueError("Use at least three reference stars and a 0-5% wavelength tolerance.")
    def key(row):
        time = _finite_float(row.get("mjd"))
        return (str(row.get("obs_id","")),str(row.get("detector","")),round(time,7)) if time is not None else None
    def usable(row):
        return (row.get("usable_flux") and row.get("detected") and not row.get("blended_source")
                and not row.get("association_uncertain") and (_finite_float(row.get("flux_ujy")) or 0)>0
                and (_finite_float(row.get("flux_err_ujy")) or 0)>0
                and (_finite_float(row.get("snr")) or 0)>=5)
    targets = [row for row in target_rows if usable(row) and key(row) is not None]
    if len({key(row) for row in targets})<3:
        return dict(result,reason="At least three usable target epochs are required.")
    waves = [_finite_float(row.get("wavelength_um")) for row in targets]
    widths = [_finite_float(row.get("bandwidth_um")) for row in targets]
    if any(v is None or v<=0 for v in waves+widths):
        return dict(result,reason="Every target epoch needs wavelength and bandwidth information.")
    centre = float(np.median(waves))
    if max(waves)-min(waves)>min(wavelength_tolerance*centre,.5*min(widths)) or max(widths)/min(widths)>1.25:
        return dict(result,reason="Target measurements do not have comparable effective bandpasses.")
    target_keys={key(row):row for row in targets}
    target_position=(targets[0].get("input_ra_deg"),targets[0].get("input_dec_deg"))
    target_radius=_finite_float(targets[0].get("aperture_radius_arcsec")) or 12.
    accepted=[]
    accepted_positions=[]
    for index,rows in enumerate(reference_series):
        selected={key(row):row for row in rows if usable(row) and key(row) in target_keys}
        if len(selected)<3:
            result["rejected_references"].append({"index":index,"reason":"fewer than three usable matching epochs"})
            continue
        first=next(iter(selected.values()))
        reference_position=(first.get("input_ra_deg"),first.get("input_dec_deg"))
        reference_radius=_finite_float(first.get("aperture_radius_arcsec")) or 12.
        if None not in reference_position:
            coordinate=SkyCoord(*reference_position,unit="deg")
            if None not in target_position and coordinate.separation(SkyCoord(*target_position,unit="deg")).arcsec<target_radius+reference_radius:
                result["rejected_references"].append({"index":index,"reason":"reference aperture overlaps the target aperture"})
                continue
            if any(coordinate.separation(SkyCoord(*position,unit="deg")).arcsec<radius+reference_radius for position,radius in accepted_positions):
                result["rejected_references"].append({"index":index,"reason":"reference aperture overlaps another reference"})
                continue
        compatible={}
        for identity,row in selected.items():
            wave,width=_finite_float(row.get("wavelength_um")),_finite_float(row.get("bandwidth_um"))
            target=target_keys[identity]
            if wave is not None and width is not None and width>0:
                tolerance=min(wavelength_tolerance*centre,.5*min(width,target["bandwidth_um"]))
                if abs(wave-target["wavelength_um"])<=tolerance and max(width,target["bandwidth_um"])/min(width,target["bandwidth_um"])<=1.25:
                    compatible[identity]=row
        if len(compatible)<3:
            result["rejected_references"].append({"index":index,"reason":"incompatible wavelength coverage"})
            continue
        values=np.asarray([row["flux_ujy"] for row in compatible.values()])
        baseline=float(np.median(values))
        scatter=float(1.4826*np.median(np.abs(values-baseline))/baseline)
        relative_noise=float(np.median([row["flux_err_ujy"]/baseline for row in compatible.values()]))
        excursion=float(np.max(np.abs(values/baseline-1)))
        if scatter>max_reference_scatter or excursion>max(max_reference_scatter,5*relative_noise):
            result["rejected_references"].append({"index":index,"reason":"reference scatter is too large"})
            continue
        accepted.append({identity:(row["flux_ujy"]/baseline,row["flux_err_ujy"]/baseline)
                         for identity,row in compatible.items()})
        if None not in reference_position:
            accepted_positions.append((reference_position,reference_radius))
    result["reference_stars"]=len(accepted)
    if len(accepted)<min_references:
        return dict(result,reason="Too few stable, independent, comparable-band reference stars remain.")
    output=[]
    for row in target_rows:
        copy=dict(row,relative_available=False,relative_flux_ujy=None,relative_flux_err_ujy=None,
                  reference_correction_factor=None,reference_correction_err_approx=None,reference_count=0)
        identity=key(row)
        points=[star[identity] for star in accepted if identity in star] if identity in target_keys else []
        if len(points)>=min_references:
            values=np.asarray([value for value,error in points])
            correction=float(np.median(values))
            statistical=1.253314*float(np.median([error for value,error in points]))/math.sqrt(len(points))
            between=1.4826*float(np.median(np.abs(values-correction)))/math.sqrt(len(points))
            correction_error=max(statistical,between)
            flux=float(row["flux_ujy"])
            error=float(row["flux_err_ujy"])
            copy.update(relative_available=True,relative_flux_ujy=flux/correction,
                        relative_flux_err_ujy=math.hypot(error/correction,flux*correction_error/correction**2),
                        reference_correction_factor=correction,reference_correction_err_approx=correction_error,
                        reference_count=len(points))
        output.append(copy)
    result["rows"]=output
    result["available"]=sum(row["relative_available"] for row in output)>=3
    result["reason"]="Relative comparison is available with diagnostic uncertainties." if result["available"] else "Fewer than three corrected epochs retain enough references."
    return result
