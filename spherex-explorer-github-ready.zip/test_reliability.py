"""Synthetic reliability checks, with an independent known source scene."""

from pathlib import Path
from tempfile import TemporaryDirectory
import math
import json

import numpy as np
from astropy.io import fits
from astropy.wcs import WCS

import photometry as photo
import sequence


REGION = {"ra":100.,"dec":30.,"fov_arcmin":80/60}
STARS = [(20.2,20.4,100.),(58.2,19.7,80.),(19.8,57.9,120.),(58.3,58.1,90.)]


def scene(sigma=1.0,shift=(0.,0.),noise=0.):
    yy,xx = np.indices((80,80))
    image = np.zeros((80,80),float)
    for x,y,flux in STARS:
        image += flux/(2*np.pi*sigma*sigma)*np.exp(-((xx-x-shift[0])**2+(yy-y-shift[1])**2)/(2*sigma*sigma))
    if noise:
        image += np.random.default_rng(125).normal(0,noise,image.shape)
    return image


def write_frame(path,image,sigma=1.,flagged=False,psf_header=True):
    grid=sequence.make_common_grid(REGION,pixel_scale_arcsec=1)
    header=grid["wcs"].to_header()
    header["BUNIT"]="MJy/sr"
    header["MJD-OBS"]=61000.
    header["DATE-OBS"]="2025-11-21T00:00:00"
    if psf_header:
        header["PSF_FWHM"]=(2.354820045*sigma,"[arcsec] synthetic circular PSF")
    flags=np.zeros(image.shape,np.int32)
    flags[20,20]=1
    if flagged:
        flags[40,40]=2
        flags[10,10]=8  # Unknown quality bit must not silently pass.
    fh=fits.Header()
    fh["MSKN0000"]="SOURCE";fh["MSKM0000"]=1
    fh["MSKN0001"]="BLOOM";fh["MSKM0001"]=2
    fits.HDUList([fits.PrimaryHDU(),fits.ImageHDU(image,header=header,name="IMAGE"),
                  fits.ImageHDU(np.full(image.shape,.0001),name="VARIANCE"),
                  fits.ImageHDU(flags,header=fh,name="FLAGS")]).writeto(path,overwrite=True)
    return {"path":str(path),"record":{"mjd":61000.,"detector":"D1","obs_id":path.stem},
            "meta":{"wavelength_um":1.,"bandwidth_um":.1}}


def run():
    with TemporaryDirectory() as folder:
        root=Path(folder)
        bad_image=scene()
        bad_image[40,40]=1e8
        bad=write_frame(root/'bad.fits',bad_image,flagged=True)
        native=sequence.load_native_frame(bad)
        assert not native['valid_mask'][40,40] and not native['valid_mask'][10,10]
        assert native['valid_mask'][20,20], 'SOURCE must remain valid'
        masked=sequence.align_sequence([bad],REGION,pixel_scale_arcsec=1)
        assert np.nanmax(masked['images'])<100
        assert not np.isfinite(masked['images'][0,40,40])
        assert masked['metadata'][0]['quality_mask_applied']
        # Different PSF widths, identical physical sources and identical WCS.
        narrow=write_frame(root/'narrow.fits',scene(1),sigma=1)
        broad=write_frame(root/'broad.fits',scene(2),sigma=2)
        cube=sequence.align_sequence([narrow,broad],REGION,pixel_scale_arcsec=1)
        raw=sequence.preview_difference(cube,0,1,subtract_background=False,match_psf=False)
        matched=sequence.preview_difference(cube,0,1,subtract_background=False)
        ratio=np.nanmax(np.abs(matched['image']))/np.nanmax(np.abs(raw['image']))
        assert ratio<.03,ratio
        prepared=sequence.prepare_comparison(cube,[0,1])
        fluxes=[float(np.nansum(image)) for image in prepared['images']]
        assert all(abs(value-390)/390<.005 for value in fluxes),fluxes
        assert matched['psf_matching']['applied']
        # Smoothing may not fill a missing region or claim its integrated flux.
        hole=np.ones((80,80),bool);hole[40,40]=False
        smooth,support=sequence.gaussian_match_image(scene(),hole,1.5)
        assert not support[40,40] and np.isnan(smooth[40,40])
        assert support.sum()<hole.sum()
        # Deliberate residual astrometric error must be reported and gated.
        shifted=write_frame(root/'shifted.fits',scene(1,shift=(1.3,0)),sigma=1)
        shifted_cube=sequence.align_sequence([narrow,shifted],REGION,pixel_scale_arcsec=1)
        registration=shifted_cube['registration']['frames'][1]
        assert registration['available'] and not registration['reliable'],registration
        assert abs(registration['dx_pixels']-1.3)<.15,registration
        try:
            sequence.preview_difference(shifted_cube,0,1)
        except ValueError as error:
            assert 'Registration' in str(error)
        else:
            raise AssertionError('An unvalidated difference must be refused')
        # Robust clipping and missing-data denominators are independent tests.
        images=np.ones((3,80,80))
        images[2,40,40]=100
        images[0,15,15]=np.nan
        images[:,5,5]=np.nan
        metadata=[{'wavelength_um':1.,'bandwidth_um':.1,'median_native_variance':.01,
                   'psf_fwhm_arcsec':2.35,'quality_mask_applied':True} for _ in range(3)]
        manual={'images':images,'footprints':np.isfinite(images).astype(float),
                'metadata':metadata,'pixel_scale_arcsec':1.}
        stack=sequence.preview_stack(manual,require_registration=False)
        assert stack['image'][40,40]==1 and stack['count'][40,40]==2
        assert stack['rejected_count'][40,40]==1
        assert stack['image'][15,15]==1 and stack['count'][15,15]==2
        assert np.isnan(stack['image'][5,5]) and stack['count'][5,5]==0
        # Width estimation fallback must agree with known synthetic widths.
        measured=photo.estimate_psf_width(scene(1.3,noise=.01),cube['header'])
        assert measured['available'] and measured['n_stars']>=3,measured
        assert abs(measured['fwhm_arcsec']-2.354820045*1.3)<.1,measured
        # Blended object aperture is withheld, while fixed unblended flux remains.
        yy,xx=np.indices((80,80))
        blend=np.random.default_rng(9).normal(0,.01,(80,80))
        for x in [37.,43.]:
            blend+=5*np.exp(-((xx-x)**2+(yy-40)**2)/2)
        blend_frame=write_frame(root/'blend.fits',blend)
        sky=WCS(cube['header']).celestial.pixel_to_world(37.,40.)
        blended=photo.measure_source(blend_frame['path'],sky.ra.deg,sky.dec.deg,
                                    aperture_arcsec=8,annulus_inner=12,annulus_outer=18,
                                    search_radius_arcsec=3)
        assert blended['blended_source'] and not blended['usable_flux'],blended
        fixed_sky=WCS(cube['header']).celestial.pixel_to_world(20.2,20.4)
        fixed=photo.measure_source(narrow['path'],fixed_sky.ra.deg,fixed_sky.dec.deg,
                                  aperture_arcsec=4,annulus_inner=7,annulus_outer=11,
                                  follow_centroid=False)
        assert fixed['usable_flux'] and not fixed['centroid_valid'],fixed
        # A relative ensemble removes a common multiplicative throughput change,
        # preserving the independently injected target-only variation.
        factors=[.9,1.,1.1,.95,1.05]
        variable=[1.,1.2,1.,.9,1.]
        def rows(baseline,position,variability=None):
            return [{'mjd':61000.+i,'obs_id':str(i),'detector':'D1','usable_flux':True,
                     'detected':True,'snr':100.,'flux_ujy':baseline*factor*(variability[i] if variability else 1),
                     'flux_err_ujy':.5,'wavelength_um':1.,'bandwidth_um':.1,
                     'input_ra_deg':position,'input_dec_deg':30.} for i,factor in enumerate(factors)]
        target=rows(100,100,variable)
        references=[rows(200,101),rows(300,102),rows(400,103),target]
        corrected=photo.relative_ensemble_correction(target,references)
        assert corrected['available'] and corrected['reference_stars']==3,corrected
        values=[row['relative_flux_ujy'] for row in corrected['rows']]
        assert np.allclose(values,100*np.asarray(variable),rtol=.001),values
        assert all(row['relative_flux_err_ujy']>0 for row in corrected['rows'])
        print(json.dumps({'psf_residual_ratio':ratio,'matched_interior_fluxes':fluxes,
                          'recovered_shift_pixels':registration['dx_pixels'],
                          'measured_fwhm_arcsec':measured['fwhm_arcsec'],
                          'ensemble_corrected_flux':values}))
        print('PASS: bad-flag movie masks, SOURCE preservation, PSF interior-flux conservation, hole support, registration gate, robust stack, blend/fixed-position gates and relative ensemble')


if __name__=='__main__':
    run()
