"""Verified benchmark astrometry with catalogue provenance and epoch handling."""
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urlencode
import csv
from io import StringIO
import json
import math
import re
import warnings

import numpy as np
import requests
import astropy.units as u
from astropy.coordinates import SkyCoord, Distance
from astropy.time import Time

TARGETS = [
    {"key":"barnard","label":"Barnard's Star","identifier":"Barnard's Star","kind":"high-proper-motion star","source_url":"https://simbad.harvard.edu/simbad/sim-id?Ident=Barnard%27s+Star"},
    {"key":"epsilon_indi_b","label":"Epsilon Indi B (Ba/Bb blend)","identifier":"eps Ind B","kind":"brown-dwarf binary blend","source_url":"https://simbad.harvard.edu/simbad/sim-id?Ident=eps+Ind+B"},
    {"key":"wise_0855","label":"WISE 0855−0714","identifier":"WISE J085510.83-071442.5","kind":"very faint, high-proper-motion brown dwarf","source_url":"https://simbad.harvard.edu/simbad/sim-id?Ident=WISE+J085510.83-071442.5"},
    {"key":"rw_aur","label":"RW Aurigae","identifier":"RW Aur","kind":"variable T Tauri system","source_url":"https://simbad.harvard.edu/simbad/sim-id?Ident=RW+Aur"},
    {"key":"r_dra","label":"R Draconis","identifier":"R Dra","kind":"Mira variable star","source_url":"https://simbad.harvard.edu/simbad/sim-id?Ident=R+Dra"},
]


def _num(text):
    try:
        value=float(str(text).strip())
        return value if math.isfinite(value) else None
    except (ValueError,TypeError):return None


def _line(text,prefix):
    return next((line for line in text.splitlines() if line.startswith(prefix)),"")


def parse_simbad_ascii(text,target,source_url):
    coordinate=re.search(r"Coordinates\(ICRS,ep=J([\d.]+),eq=[^)]*\):\s*(\d+\s+\d+\s+[\d.]+)\s+([+-]\d+\s+\d+\s+[\d.]+)",text)
    if coordinate is None:raise ValueError("SIMBAD did not return epoch-tagged ICRS coordinates for this identifier.")
    sky=SkyCoord(coordinate[2],coordinate[3],unit=(u.hourangle,u.deg),frame="icrs")
    pm=_line(text,"Proper motions:")
    m=re.search(r"Proper motions:\s*([+-]?[\d.]+)\s+([+-]?[\d.]+)\s+\[([\d.~+-]+)\s+([\d.~+-]+)",pm)
    parallax_line=_line(text,"Parallax:")
    p=re.search(r"Parallax:\s*([+-]?[\d.]+)\s+\[([\d.~+-]+)\]",parallax_line)
    rv_line=_line(text,"Radial Velocity:")
    rv=re.search(r"Radial Velocity:\s*([+-]?[\d.]+)\s+\[([\d.~+-]+)\]\s+([A-E])",rv_line)
    ids=sorted(set(re.findall(r"\bGaia DR3\s+(\d+)\b",text)))
    main=_line(text,"Object ")
    result={**target,"available":True,"status":"resolved","source_catalogue":"SIMBAD (Harvard mirror)",
        "source_id":main.split("  ---")[0].removeprefix("Object ").strip(),"source_url":source_url,
        "ra_deg":float(sky.ra.deg),"dec_deg":float(sky.dec.deg),"epoch_jyear":float(coordinate[1]),
        "pmra_mas_per_year":_num(m[1]) if m else None,"pmdec_mas_per_year":_num(m[2]) if m else None,
        "pmra_error_mas_per_year":_num(m[3]) if m else None,"pmdec_error_mas_per_year":_num(m[4]) if m else None,
        "parallax_mas":_num(p[1]) if p else None,"parallax_error_mas":_num(p[2]) if p else None,
        "radial_velocity_kms":_num(rv[1]) if rv and rv[3] in ("A","B") else None,
        "radial_velocity_error_kms":_num(rv[2]) if rv and rv[3] in ("A","B") else None,
        "raw_simbad_radial_velocity_kms":_num(rv[1]) if rv else None,
        "radial_velocity_quality":rv[3] if rv else None,"gaia_dr3_ids":ids,
        "fetched_at":datetime.now(timezone.utc).isoformat(),"notes":[],
        "field_provenance":{"coordinates":_line(text,"Coordinates(ICRS"),"proper_motion":pm,"parallax":parallax_line,"radial_velocity":rv_line},
    }
    if rv and rv[3] not in ("A","B"):
        result["notes"].append("SIMBAD radial velocity has low quality and is retained as raw provenance, not prefilled as a reliable velocity.")
    if target["key"]=="epsilon_indi_b":
        result["notes"].append("This is the B brown-dwarf pair, not epsilon Indi A. SPHEREx does not resolve Ba/Bb; component motion/blending can affect the centroid.")
    if target["key"]=="wise_0855":
        result["notes"].append("The challenge's RA08h55m10.831s/Dec−07d14m42.53s is a discovery/name coordinate. The catalogue supplies a different epoch-J2000 position; propagate the epoch-tagged astrometry before selecting current observations.")
    if result["parallax_mas"] is not None and result["parallax_error_mas"]:
        result["parallax_snr"]=result["parallax_mas"]/result["parallax_error_mas"]
        if result["parallax_snr"]<10:result["notes"].append("Parallax S/N is below10: do not estimate distance by a simple reciprocal.")
    return result


def position_at_epoch(target,reference_epoch=2025.5):
    """Propagate actual catalogue astrometry; this omits observer parallax."""
    ra,dec=target["ra_deg"],target["dec_deg"]
    epoch=target["epoch_jyear"]
    pmra,pmdec=target.get("pmra_mas_per_year"),target.get("pmdec_mas_per_year")
    if pmra is None or pmdec is None:
        return {"ra_deg":ra,"dec_deg":dec,"epoch_jyear":epoch,"method":"Catalogue position; proper motion unavailable, not propagated"}
    kwargs={"ra":ra*u.deg,"dec":dec*u.deg,"pm_ra_cosdec":pmra*u.mas/u.yr,
            "pm_dec":pmdec*u.mas/u.yr,"obstime":Time(epoch,format="jyear"),"frame":"icrs"}
    p,e=target.get("parallax_mas"),target.get("parallax_error_mas")
    if p is not None and e and p>0 and p/e>=10:
        kwargs["distance"]=Distance(parallax=p*u.mas)
        if target.get("radial_velocity_kms") is not None:kwargs["radial_velocity"]=target["radial_velocity_kms"]*u.km/u.s
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore",message=".*distance overridden.*")
        coord=SkyCoord(**kwargs).apply_space_motion(new_obstime=Time(reference_epoch,format="jyear"))
    return {"ra_deg":float(coord.ra.deg),"dec_deg":float(coord.dec.deg),"epoch_jyear":float(reference_epoch),
            "method":"Catalogue proper-motion propagation; observer-dependent annual parallax is not applied"}


def fetch_gaia_source(source_id,timeout=40):
    """Read an exact Gaia DR3 identifier through the authoritative VizieR mirror."""
    source_id=str(source_id)
    if not source_id.isdigit():raise ValueError("A numeric exact Gaia DR3 source identifier is required.")
    columns="Source,RA_ICRS,DE_ICRS,Plx,e_Plx,pmRA,e_pmRA,pmDE,e_pmDE,RV,e_RV,RUWE,Gmag"
    response=requests.get("https://vizier.cfa.harvard.edu/viz-bin/asu-tsv",params={
        "-source":"I/355/gaiadr3","Source":source_id,"-out":columns,"-out.max":"2"},timeout=(10,timeout))
    response.raise_for_status()
    lines=[line for line in response.text.splitlines() if line.strip() and not line.startswith("#")]
    if not lines or "Source" not in lines[0].split("\t"):raise ValueError("Gaia DR3 did not return the expected table schema.")
    header=[s.strip() for s in lines[0].split("\t")]
    rows=[]
    for line in lines[1:]:
        fields=[s.strip() for s in line.split("\t")]
        if len(fields)!=len(header):continue
        row=dict(zip(header,fields))
        if row.get("Source")==source_id:rows.append(row)
    if len(rows)!=1:raise ValueError("An unambiguous exact Gaia DR3 source was not returned.")
    return {"source_id":source_id,"source_catalogue":"Gaia DR3 via VizieR I/355/gaiadr3",
            "source_url":response.url,"epoch_jyear":2016.0,"values":rows[0],
            "fetched_at":datetime.now(timezone.utc).isoformat()}


def resolve_target(key,cache_dir,reference_epoch=2025.5,allow_network=True):
    """Return cached or live catalogue astrometry, with no invented quantities."""
    target=next((row for row in TARGETS if row["key"]==key),None)
    if target is None:raise ValueError("Unknown benchmark target.")
    cache_dir=Path(cache_dir);cache_dir.mkdir(parents=True,exist_ok=True)
    path=cache_dir/(key+".json")
    if not path.is_file() and (cache_dir/"catalogue_cache"/(key+".json")).is_file():
        path=cache_dir/"catalogue_cache"/(key+".json")
    if path.is_file():
        result=json.loads(path.read_text(encoding="utf-8"))
    elif allow_network:
        errors=[];result=None
        for base in ("https://simbad.harvard.edu/simbad/sim-id","https://simbad.cds.unistra.fr/simbad/sim-id"):
            try:
                response=requests.get(base,params={"Ident":target["identifier"],"output.format":"ASCII"},timeout=(10,45))
                response.raise_for_status()
                result=parse_simbad_ascii(response.text,target,response.url)
                (cache_dir/(key+"-simbad.txt")).write_text(response.text,encoding="utf-8")
                break
            except (requests.RequestException,ValueError) as error:errors.append(str(error)[:180])
        if result is None:return {**target,"available":False,"status":"catalogue_unavailable","notes":errors}
        if len(result["gaia_dr3_ids"])==1:
            try:
                gaia=fetch_gaia_source(result["gaia_dr3_ids"][0])
                result["gaia_dr3"]=gaia
                (cache_dir/(key+"-gaia.json")).write_text(json.dumps(gaia,indent=2),encoding="utf-8")
            except (requests.RequestException,ValueError) as error:
                result["notes"].append("Exact Gaia DR3 retrieval unavailable; retained actual SIMBAD values and references. "+str(error)[:120])
        path.write_text(json.dumps(result,indent=2,allow_nan=False),encoding="utf-8")
    else:
        return {**target,"available":False,"status":"catalogue_not_cached","notes":["No cached catalogue measurement is available."]}
    if result.get("available"):
        parallax,error=result.get("parallax_mas"),result.get("parallax_error_mas")
        snr=parallax/error if parallax is not None and error and error>0 else None
        gaia_values=result.get("gaia_dr3",{}).get("values",{})
        ruwe=_num(gaia_values.get("RUWE"))
        quality=[]
        if snr is None or parallax<=0 or snr<10:
            quality.append("The parallax does not meet the chosen positive, S/N≥10 inverse-distance gate.")
        if ruwe is not None and ruwe>1.4:
            quality.append(f"Gaia DR3 RUWE={ruwe:g} exceeds the app's conservative 1.4 quality gate; a single-star astrometric fit may be inadequate.")
        if key=="epsilon_indi_b":
            quality.append("The brown-dwarf pair is blended; component orbital motion affects interpretation.")
        result["distance_eligible"]=bool(snr is not None and parallax>0 and snr>=10 and (ruwe is None or ruwe<=1.4))
        result["astrometry_reliable"]=result["distance_eligible"]
        result["astrometry_warning"]=" ".join(quality) or "Passed the app's limited parallax/RUWE checks; catalogue systematics are not eliminated."
        result["astrometry_quality"]={"parallax_snr":snr,"ruwe":ruwe,"duplicated_source":None,"non_single_star_solution":None,
            "policy":"Conservative application gate: positive parallax, S/N≥10 and RUWE≤1.4 when available. This is not a guarantee of accuracy."}
        for note in quality:
            if note not in result["notes"]:result["notes"].append(note)
        propagated=position_at_epoch(result,reference_epoch)
        result={**result,"query_ra_deg":propagated["ra_deg"],"query_dec_deg":propagated["dec_deg"],
                "query_epoch_jyear":propagated["epoch_jyear"],"coordinate_method":propagated["method"]}
    return result


def load_benchmark_report(project_root):
    path=Path(project_root)/"data"/"targets"/"validation.json"
    try:return json.loads(path.read_text(encoding="utf-8"))
    except (OSError,ValueError):return None


def load_catalogue(project_root):
    path=Path(project_root)/"data"/"targets"/"catalogue.json"
    try:return json.loads(path.read_text(encoding="utf-8"))
    except (OSError,ValueError):return {"targets":[]}
