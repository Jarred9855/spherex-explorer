# SPHEREx Explorer: time player and analysis update

## Start on Windows

Open the spherex-viewer folder in VS Code. In its PowerShell terminal, stop the old app with Ctrl+C, then run:

```powershell
Set-Location "$env:USERPROFILE\spherex-viewer"
.\.venv\Scripts\python.exe -m streamlit run .\app.py
```

Open the localhost link printed by Streamlit and refresh the page. Existing data and saved archive queries are preserved. No virtual-environment activation is needed when using this command.

For a fresh installation, first create a virtual environment and install requirements-web.txt using that environment's python.exe. The update was checked using Python3.13 and Streamlit1.67.

## First use

1. Keep the saved tutorial region for the first demonstration. Its archive search results are already available locally.
2. Open **Time player**, keep **SPHEREx-D1**, **6** observations and the spectrum checkbox, then select **Prepare time viewer**.
3. Use **Play**, **Pause** or the frame slider. Each frame shows its actual observation date and estimated wavelength. Playback uses equally spaced screen intervals, although the real intervals differ.
4. Click a turquoise reference circle, then open **Source measurements**. Alternatively choose a candidate from its dropdown or enter source coordinates manually.
5. Select **Measure selected source**. The app measures native FITS images and displays the available graphs. Candidate numbers identify image features, not catalogue objects or planets.
6. Select a spectrum or light-curve point, then open **Sky image** to inspect its original exposure.
7. Open **Physical estimates** for calculations using independently obtained information about that same source. Inputs start empty. A catalogue source reference can be recorded alongside a supplied parallax.

Preparing a sequence reuses validated cached cutouts and downloads only the requested missing files. Existing cached observations for the chosen detector can supply extra measurements. Increasing Movie observations can improve sampling but does not guarantee matching wavelength coverage. The prepared sequence and selected measurements are kept for the browser session; after a full browser reload or server restart, prepare and measure again. Downloaded FITS files remain cached on disk.

## Included analyses and their inputs

| Result | Input and method | Display / constraint |
| --- | --- | --- |
| Observation intervals | Actual FITS/archive times; dt=t2-t1 | Date and interval table; archive rows are not independent dates |
| Angular displacement | Reliable native-image centroids; spherical coordinate offsets | Sky track, first-to-last angular separation |
| Apparent angular motion | Positions at distinct times; fitted east/north slopes | Position-time graph; not automatically true proper motion |
| Distance | User-supplied positive parallax and uncertainty; d_pc=1000/p_mas | pc and light-years; reciprocal approximation requires SNR>=10 |
| Transverse speed | Reliable distance and both published proper-motion components; vt=4.74047*mu_arcsec_per_year*d_pc | km/s; image-centroid slope is not silently substituted |
| Brightness change | Approximately compatible passbands; dm=-2.5*log10(F2/F1) | Aperture-flux light curve and relative-magnitude graph |
| Formal change/noise | Flux errors; (F2-F1)/sqrt(error1^2+error2^2) | Formal score; excludes common systematics and is not a discovery probability |
| Spectral shape | Native aperture flux density, wavelength and date | Flux versus wavelength with error bars and date colour |
| Joint time/wavelength behaviour | Actual measurements (time, wavelength, flux) | Scatter diagram; unobserved gaps are not interpolated |
| Difference preview | Aligned images; D=I2-k*I1 with background adjustment | Approximate passband and registration checks; optional median-Gaussian sharpness matching |
| Weighted stack | Compatible aligned images and inverse-variance weights | Quality-masked robust display stack; interpolation covariance is not propagated |
| Candidate repeating period | >=12 distinct compatible measurements and adequate cadence/baseline | Lomb-Scargle periodogram and folded curve when checks pass; aliases remain possible |
| Radial velocity | Identified, calibrated external rest and observed spectral lines; vr~c*(lambda_obs-lambda0)/lambda0 | Low-redshift calculator; ordinary precise stellar velocities are unsuitable for SPHEREx alone |
| Luminosity | Distance plus supplied bolometric flux, or explicitly limited spectral-band integration | L=4*pi*d^2*F; aperture-band integral is never called total luminosity |
| Thermal temperature | Adequate spectral range/SNR with a bracketed F_nu peak and a declared stable-source assumption | Exploratory Planck F_nu fit; Wien's2898/T relation is specifically the B_lambda peak |
| Known-orbit relationships | Independent mass and semimajor axis or period; Kepler's third law | Period/size, circular illustration and orbital position/speed-time models; no orbit is inferred from two image points |

Additional displays include a predicted annual parallax track from supplied astrometry and a full speed magnitude when compatible transverse and radial velocities are supplied. These are models or catalogue-assisted calculations, not new parallax or radial-velocity measurements from these images. The parallax model uses Earth's barycentric position; it is not an exact low-Earth-orbit spacecraft prediction.

## Scientific interpretation

- The animation is reprojected onto one fixed north-up, east-left sky grid. Blank coverage remains missing. A common display stretch avoids automatic per-frame rescaling.
- SPHEREx's linear-variable filters mean even images from the same detector can sample different wavelengths at the source. Changes in the movie can therefore be spectral or instrumental. Approximate wavelength/bandwidth matching is enforced for light curves; it is not a full response-function match.
- Quantitative measurements use native images, not resampled movie pixels. Apertures use fractional pixels, local pixel solid angle, a background annulus, variance and quality masks. MJy/sr surface brightness is converted to aperture flux density in microJy.
- These are preliminary aperture measurements. The optional Gaussian comparison smoothing is not spatial ePSF fitting/deblending; there is no total-flux aperture correction or calibrated absolute astrometric error budget. Crowded-field background fallback and other quality failures are explicitly reported. Formal errors do not include all systematic effects.
- WCS-WAVE supplies visualization-level wavelength estimates. Precision spectral analysis needs the official calibration products and suitable photometry.
- SOURCE/FULLSAMPLE mask annotations are not automatically treated as bad pixels; known bad and unknown mask bits are rejected. Missing, ambiguous or contaminated measurements can be unavailable rather than replaced with invented values.
- Long-interval or fast-moving targets can leave an aperture/search region. Inspect original exposures and choose the appropriate source coordinate; this version is not a general moving-object association or orbit-solving engine.
- The current five-target coverage and quality outcomes are recorded in data/targets/validation.json and RELEASE_VALIDATION.md. Displaying all analysis modules does not establish a new discovery.

## Archive availability

The live IRSA search service returned HTTP502 during development. Matching saved queries can be used, and cached/direct cutout URLs can still work. An unrelated region is never labelled with the tutorial region's data. Retry live searches when the service recovers. This app cannot repair IRSA's upstream service.

## Source files

- app.py: search, individual FITS viewer and tab integration
- data_access.py: archive queries, matching-query recovery, validated cutout caching
- sequence.py: common-grid alignment, frame selection, comparison previews
- photometry.py: candidate detection and native-image source measurements
- physics.py: equations, unit conversions and availability checks
- explorer_ui.py: interactive charts, source selection and physical calculators
- requirements-web.txt: dependencies

The test_*.py files exercise synthetic numerical cases only; synthetic data are not shown as observations. Measurement CSV/evidence JSON include dates, source URLs and quality notes. The update package excludes the virtual environment, backups and browser-session state.

## Primary references and acknowledgement

- [IRSA SPHEREx tutorials](https://caltech-ipac.github.io/irsa-tutorials/spherex/)
- [SPHEREx data products](https://caltech-ipac.github.io/spherex-archive-documentation/spherex-data-products/)
- [SPHEREx spectrophotometry](https://irsa.ipac.caltech.edu/onlinehelp/spherex/spherex/sp.html)
- [Astropy Lomb-Scargle documentation](https://docs.astropy.org/en/stable/timeseries/lombscargle.html)

This publication makes use of data products from the Spectro-Photometer for the History of the Universe, Epoch of Reionization and Ices Explorer (SPHEREx), which is a joint project of the Jet Propulsion Laboratory and the California Institute of Technology, and is funded by the National Aeronautics and Space Administration.
