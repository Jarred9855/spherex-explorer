"""Local SPHEREx viewer with aligned playback and preliminary source analysis."""

from pathlib import Path
from dataclasses import asdict
import csv
from io import StringIO
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from astropy.visualization import AsinhStretch, ImageNormalize, ZScaleInterval
from astropy.wcs import WCS

import data_access as archive
import explorer_ui
import advanced_analysis
import sky_context
import target_ui
import targets


def image_figure(image, header, stretch=True):
    low, high = ZScaleInterval().get_limits(image[np.isfinite(image)])
    if high <= low:
        high = low + max(abs(float(low)) * 1e-6, 1.0)
    normalization = ImageNormalize(vmin=low, vmax=high, stretch=AsinhStretch()) if stretch else ImageNormalize(vmin=low, vmax=high)
    fig = plt.figure(figsize=(7.4, 6.2), layout="constrained")
    ax = fig.add_subplot(111, projection=WCS(header).celestial)
    display = ax.imshow(image, origin="lower", cmap="gray", norm=normalization, interpolation="nearest")
    ax.set_xlabel("Right Ascension")
    ax.set_ylabel("Declination")
    ax.set_title("SPHEREx spectral image cutout")
    fig.colorbar(display, ax=ax, label=header.get("BUNIT", "Image intensity"), pad=0.04)
    return fig


def coverage_figure(records):
    bands = sorted({r["detector"] for r in records})
    fig, ax = plt.subplots(figsize=(10, 3.4), layout="constrained")
    for number, band in enumerate(bands):
        times = [r["mjd"] for r in records if r["detector"] == band]
        ax.scatter(times, [number] * len(times), s=14, color="#147d92", alpha=0.65)
    ax.set_yticks(range(len(bands)), bands)
    ax.set_xlabel("Observation start time (MJD, days)")
    ax.set_ylabel("Detector")
    ax.grid(axis="x", alpha=0.2)
    ax.set_title("Available archive records by observation time")
    return fig


def csv_text(records):
    output = StringIO()
    rows = archive.public_rows(records)
    if rows:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return output.getvalue()


def main():
    import streamlit as st

    st.set_page_config(page_title="SPHEREx Explorer", page_icon="✨", layout="wide")
    st.title("SPHEREx Explorer")
    st.write("Search a sky position, choose an observation and explore its infrared image.")
    root = Path(os.environ.get("SPHEREX_PROJECT_DIR", Path(__file__).resolve().parent))
    cache_dir = Path(os.environ.get("SPHEREX_CACHE_DIR", root / "data" / "cutout_cache"))
    query_cache_dir = Path(os.environ.get("SPHEREX_QUERY_CACHE_DIR", root / "data" / "query_cache"))
    if "shared_region_initialized" not in st.session_state:
        st.session_state.shared_region_initialized=True
        try:
            shared=sky_context.parse_region_query(st.query_params)
            if shared is not None:
                requested_collections=tuple(c for c in st.query_params.get("collections",",").split(",") if c in archive.COLLECTIONS) or archive.COLLECTIONS
                st.session_state.draft_ra=shared.ra;st.session_state.draft_dec=shared.dec;st.session_state.draft_fov=shared.fov_arcmin
                st.session_state.draft_collections=list(requested_collections)
                saved=archive.load_saved_query(shared.ra,shared.dec,requested_collections,query_cache_dir)
                if saved is not None:
                    st.session_state.sky_dataset=dict(saved,region=asdict(shared),source="saved")
                    st.session_state.sky_frame=None
                else:
                    st.session_state.sky_dataset=None;st.session_state.sky_frame=None
                    st.session_state.shared_search_pending=shared
                target_key=st.query_params.get("target")
                if target_key in {t["key"] for t in targets.TARGETS}:
                    resolved=targets.resolve_target(target_key,root/"data"/"targets",allow_network=False)
                    if resolved.get("available"):
                        from measurement_workflow import catalogue_matches_source
                        if catalogue_matches_source(resolved,shared.ra,shared.dec):st.session_state.active_target_catalogue=dict(resolved,target_key=target_key)
        except ValueError as error:st.warning(str(error))

    pending_sample=st.session_state.pop("pending_target_sample",None)
    if pending_sample is not None:
        st.session_state.pop("analysis_bundle",None)
        st.session_state.pop("source_measurements",None)
        try:
            frames=[]
            for stored in pending_sample["frames"]:
                frame=dict(stored);path=Path(frame["path"])
                if not path.is_absolute():path=root/path
                frame["path"]=str(path)
                archive.inspect_fits(path,archive.Region(**frame["region"]))
                frames.append(frame)
            catalogue=dict(pending_sample["resolved"],target_key=pending_sample["key"])
            region=archive.Region(**frames[0]["region"])
            records=sorted([frame["record"] for frame in frames],key=lambda r:(r["mjd"],r["detector"]))
            collections=sorted({record["collection"] for record in records})
            st.session_state.sky_dataset={"region":asdict(region),"records":records,"collections":collections,"raw_count":len(records),"source":"saved","sample_subset":True,"target_key":pending_sample["key"],"source_notice":"Downloaded validation subset only; this is not the full archive result."}
            st.session_state.sky_frame=next(frame for frame in frames if frame["record"]["url"]==records[0]["url"])
            st.session_state.active_target_catalogue=catalogue
            st.session_state.draft_ra=region.ra;st.session_state.draft_dec=region.dec;st.session_state.draft_fov=region.fov_arcmin;st.session_state.draft_collections=collections
            st.session_state.analysis_bundle=explorer_ui.bundle_from_frames(frames,catalogue)
            st.session_state.pop("source_measurements",None)
            st.query_params.update(dict(target=pending_sample["key"],ra=f"{region.ra:.8f}",dec=f"{region.dec:.8f}",fov=str(region.fov_arcmin),collections=",".join(collections)))
        except (ValueError,OSError,KeyError) as error:st.warning("The downloaded sample could not be prepared: "+str(error))

    @st.cache_data(ttl=3600, max_entries=24, show_spinner=False)
    def search(ra, dec, collections, cache_version="recovery-1"):
        return archive.query_archive(ra, dec, collections)

    shared_pending=st.session_state.pop("shared_search_pending",None)
    if shared_pending is not None:
        try:
            with st.spinner("Opening the sky region from the shared URL..."):
                shared_collections=tuple(st.session_state.get("draft_collections",archive.COLLECTIONS))
                result=archive.search_with_recovery(shared_pending.ra,shared_pending.dec,shared_collections,query_cache_dir,live_query=search)
                st.session_state.sky_dataset=dict(result,region=asdict(shared_pending))
        except Exception as error:st.warning("The shared region could not be loaded: "+str(error))

    if "sky_dataset" not in st.session_state:
        st.session_state.sky_dataset = None
        st.session_state.sky_frame = None
        original_table = root / "spherex_observations.ecsv"
        if original_table.is_file():
            try:
                dataset = archive.load_saved_query(
                    archive.DEFAULT_RA, archive.DEFAULT_DEC,
                    archive.COLLECTIONS, query_cache_dir,
                )
                if dataset is None:
                    dataset = archive.load_local_dataset(original_table)
                dataset = dict(dataset, source="saved")
                st.session_state.sky_dataset = dataset
                local_image = root / "data" / "first_cutout.fits"
                if dataset["records"] and local_image.is_file():
                    region = archive.Region(**dataset["region"])
                    _, _, meta = archive.inspect_fits(local_image, region)
                    # The saved starter cutout was downloaded from the first original query row.
                    from astropy.table import Table
                    first = archive.normalise_records(Table.read(original_table)[:1])[0]
                    st.session_state.sky_frame = {
                        "key": archive.frame_key(first, region), "path": str(local_image),
                        "meta": meta, "record": first, "region": asdict(region),
                    }
            except (OSError, ValueError, KeyError, IndexError) as error:
                st.warning(f"The saved example could not be opened: {error}. You can search below.")

    target_ui.render_target_picker(root,query_cache_dir)
    st.subheader("1. Choose a sky region")
    st.caption("Enter decimal degrees. Field of view is the requested cutout width. Search finds images covering the centre.")
    for name,value in (("draft_ra",archive.DEFAULT_RA),("draft_dec",archive.DEFAULT_DEC),("draft_fov",6.),("draft_collections",list(archive.COLLECTIONS))):st.session_state.setdefault(name,value)
    with st.form("region_search"):
        fields = st.columns(3)
        ra = fields[0].number_input("Right Ascension (degrees)", min_value=0.0, max_value=360.0, value=None, format="%.8f", key="draft_ra")
        dec = fields[1].number_input("Declination (degrees)", min_value=-90.0, max_value=90.0, value=None, format="%.8f", key="draft_dec")
        size = fields[2].number_input("Field of view (arcminutes)", min_value=1.0, max_value=30.0, value=None, step=1.0, key="draft_fov")
        collections = st.multiselect("Data collections", list(archive.COLLECTIONS), default=None, key="draft_collections")
        submitted = st.form_submit_button("Search SPHEREx", type="primary")
    if submitted:
        try:
            requested = archive.Region(float(ra), float(dec), float(size))
            with st.spinner("Searching the IRSA archive..."):
                dataset = archive.search_with_recovery(
                    requested.ra, requested.dec, tuple(sorted(collections)),
                    query_cache_dir, live_query=search,
                )
            dataset = dict(dataset, region=asdict(requested))
            st.session_state.sky_dataset = dataset
            catalogue=st.session_state.get("active_target_catalogue")
            from measurement_workflow import catalogue_matches_source
            if not catalogue_matches_source(catalogue,requested.ra,requested.dec):st.session_state.pop("active_target_catalogue",None)
            previous_frame = st.session_state.sky_frame
            if previous_frame is None or not any(
                archive.frame_key(record, requested) == previous_frame["key"]
                for record in dataset["records"]
            ):
                st.session_state.sky_frame = None
            if not dataset["records"]:
                st.info("No image records cover this centre in the selected collections. Try another position.")
        except (archive.ArchiveUnavailable, ValueError) as error:
            st.warning(str(error))
            st.caption("The active region below has not changed. Its previous results remain available.")
        except Exception:
            st.error("The search could not be completed. The previous active region has been kept.")

    dataset = st.session_state.sky_dataset
    if dataset is None:
        st.info("Enter coordinates and select Search SPHEREx to begin.")
        target_ui.render_validation(root)
        return
    region = archive.Region(**dataset["region"])
    records = dataset["records"]
    st.write(f"**Active region:** RA {region.ra:.8f}°, Dec {region.dec:+.8f}° · {region.fov_arcmin:g} arcmin field")
    st.caption("Changing the form updates the active region only after you select Search SPHEREx.")
    sky_context.render_share(region,dataset["collections"],dataset.get("target_key"))
    if dataset.get("source") == "saved":
        message = "Showing a downloaded validation sample for this target. It is a subset of the available observations." if dataset.get("sample_subset") else "Showing saved archive results for this sky position. They have not been refreshed by a live search."
        if dataset.get("archive_notice"):
            message = dataset["archive_notice"] + " " + message
        st.info(message + " You can still select an observation and try Load selected image.")
        if dataset.get("fetched_at"):
            st.caption("Last successful archive query: " + dataset["fetched_at"])
    elif dataset.get("source") == "live":
        st.caption("Results from a successful live IRSA search" + (" at " + dataset["fetched_at"] if dataset.get("fetched_at") else "") + ".")
    if dataset.get("cache_notice"):
        st.caption(dataset["cache_notice"])
    if dataset.get("source_notice"):
        st.info(dataset["source_notice"])
    if not records:
        st.info("There are no observations for this active search.")
        return
    metrics = st.columns(3)
    metrics[0].metric("Image records", len(records))
    metrics[1].metric("Time baseline", f"{records[-1]['mjd'] - records[0]['mjd']:.1f} days")
    current_frame = st.session_state.sky_frame
    metrics[2].metric("Loaded cutouts", int(current_frame is not None))
    st.caption(f"{dataset['raw_count']} archive rows before duplicate filtering. Separate detectors remain separate; DR1 is preferred when the same exposure/detector appears in both releases. Records are not object detections or independent dates.")

    image_tab, time_tab, measurements_tab, physics_tab, advanced_tab,atlas_tab,validation_tab,coverage_tab, data_tab = st.tabs(
        ["Sky image", "Time player", "Source measurements", "Physical estimates", "Advanced graphs","Sky context","Target validation","Observation coverage", "Observation data"]
    )
    identity = archive.digest({"region": dataset["region"], "collections": dataset["collections"], "records": [(r["obs_id"],r["detector"],r["collection"]) for r in records]})
    pending_frame = st.session_state.pop("pending_plot_frame", None)
    if pending_frame is not None and pending_frame.get("region") == asdict(region):
        pending_index = next((i for i, record in enumerate(records) if record["url"] == pending_frame["record"]["url"]), None)
        if pending_index is not None:
            st.session_state[f"detector_{identity}"] = "All"
            st.session_state[f"observation_{identity}_All"] = pending_index
            st.session_state.sky_frame = pending_frame
    with image_tab:
        st.subheader("2. Choose and load an observation")
        detector = st.selectbox("Detector", ["All"] + sorted({r["detector"] for r in records}), key=f"detector_{identity}")
        options = [r for r in records if detector == "All" or r["detector"] == detector]
        index = st.selectbox("Observation", range(len(options)), format_func=lambda i: f"{options[i]['date']} | {options[i]['detector']} | {options[i]['obs_id']} | {options[i]['collection']}", key=f"observation_{identity}_{detector}")
        selected = options[index]
        desired_key = archive.frame_key(selected, region)
        if st.button("Load selected image", type="primary"):
            try:
                with st.spinner("Downloading and validating the cutout; the archive may take a few minutes..."):
                    frame = archive.download_cutout(selected, region, cache_dir)
                st.session_state.sky_frame = frame
                st.rerun()
            except Exception as error:
                st.error(f"The image could not be loaded: {error}")
        frame = st.session_state.sky_frame
        if frame is None or frame["key"] != desired_key:
            st.info("Select Load selected image to display this observation. A selection alone does not download an image.")
        else:
            try:
                image, header, meta = archive.inspect_fits(frame["path"], region)
                record = frame["record"]
                st.write(f"**Displayed:** {meta['date']} · {record['detector']} · {record['collection']}")
                if meta.get("compact_derived"):
                    st.caption("Compact derived demonstration cutout: science arrays and wavelength metadata are unchanged; the large ePSF model extension is omitted. Use the original product for ePSF fitting.")
                    st.link_button("Original IRSA product with ePSF models",record["url"])
                wavelength = meta["wavelength_um"]
                if wavelength is not None:
                    st.caption(f"Estimated wavelength at the requested centre: {wavelength:.4f} μm · bandwidth {meta['bandwidth_um']:.4f} μm. WCS-WAVE is for visualization; precision analysis needs calibration products.")
                else:
                    st.caption("Wavelength information at the centre is unavailable for this image.")
                stretch = st.checkbox("Enhance faint structure with an asinh display stretch", value=True)
                figure = image_figure(image, header, stretch)
                st.pyplot(figure)
                plt.close(figure)
                st.caption(f"Image size: {meta['width']} × {meta['height']} pixels. Surface brightness: {meta['unit']}. Individual-object flux requires photometry.")
                if not meta["centre_finite"]:
                    st.warning("This image has no finite pixel value at the requested centre. Some surrounding pixels may still have coverage.")
                actions = st.columns(2)
                actions[0].download_button("Download this FITS cutout", Path(frame["path"]).read_bytes(), file_name=f"{record['obs_id']}_{record['detector']}_cutout.fits", mime="application/fits")
                actions[1].download_button("Download observation details", json.dumps({k:v for k,v in frame.items() if k != "path"}, indent=2), file_name="spherex_observation_details.json", mime="application/json")
                st.info("This view shows one observation. Motion analysis needs multiple aligned epochs; brightness comparisons also need compatible wavelengths.")
            except (OSError, ValueError, KeyError) as error:
                st.error(f"The loaded cutout could not be displayed: {error}")
    with time_tab:
        analysis_bundle = explorer_ui.render_time_player(region, records, cache_dir, identity)
    with measurements_tab:
        measured_source = explorer_ui.render_measurements(analysis_bundle)
    with physics_tab:
        explorer_ui.render_physics(analysis_bundle, measured_source)
    with advanced_tab:
        catalogue=analysis_bundle.get("catalogue") if analysis_bundle else None
        if not measured_source or not measured_source.get("catalogue_identity"):catalogue=None
        advanced_analysis.render_advanced(analysis_bundle,measured_source,catalogue=catalogue)
    with atlas_tab:
        sky_context.render_atlas(region,measured_source)
    with validation_tab:
        target_ui.render_validation(root)
    with coverage_tab:
        st.subheader("When observations are available")
        st.write(f"From {records[0]['date']} to {records[-1]['date']}.")
        figure = coverage_figure(records)
        st.pyplot(figure)
        plt.close(figure)
        st.caption("Each mark is an image record. A detector covers a wavelength range; it does not guarantee the same wavelength at the target in different observations.")
    with data_tab:
        st.subheader("Observation records for the active region")
        st.dataframe(archive.public_rows(records), hide_index=True)
        st.download_button("Download records as CSV", csv_text(records), file_name="spherex_observation_records.csv", mime="text/csv")
        st.write("Data source: [NASA/IPAC Infrared Science Archive](https://irsa.ipac.caltech.edu/Missions/spherex.html).")
    with st.expander("SPHEREx data acknowledgement"):
        st.write("This publication makes use of data products from the Spectro-Photometer for the History of the Universe, Epoch of Reionization and Ices Explorer (SPHEREx), which is a joint project of the Jet Propulsion Laboratory and the California Institute of Technology, and is funded by the National Aeronautics and Space Administration.")


if __name__ == "__main__":
    main()
