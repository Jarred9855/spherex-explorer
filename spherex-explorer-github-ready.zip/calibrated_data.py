"""Strict import of exported spectrophotometry, without relabelling it as image-derived."""
import csv
from io import StringIO
import math

from astropy.coordinates import SkyCoord
from astropy.time import Time
import astropy.units as u


def _number(value):
    try:
        result=float(value)
        return result if math.isfinite(result) else None
    except (ValueError,TypeError):return None


def parse_photometry_csv(content,ra,dec,provenance,maximum_rows=50000):
    """Return canonical measurement rows from official-export or explicitly calibrated CSV.

    Mandatory units are microns, microJy and MJD days. Unknown flags are rejected.
    Provided source coordinates must fall within 3arcsec of the selected source.
    """
    if not str(provenance).strip():raise ValueError("Record the data provenance or official job/export identifier.")
    if len(content)>5*1024*1024:raise ValueError("The CSV must be no larger than 5MB.")
    try:text=content.decode("utf-8-sig") if isinstance(content,bytes) else str(content)
    except UnicodeError:raise ValueError("Use a UTF-8 CSV export.")
    table=csv.DictReader(StringIO(text))
    aliases={"wavelength_um":("wavelength_um","wavelength","central_wavelength_um"),
             "flux_ujy":("flux_ujy","flux"),"flux_err_ujy":("flux_err_ujy","flux_err"),
             "mjd":("mjd",),"bandwidth_um":("bandwidth_um","lambda_width"),
             "ra":("ra_deg","ra"),"dec":("dec_deg","dec"),"detector":("detector","det_id")}
    headers={str(h).strip().lower():h for h in (table.fieldnames or [])}
    columns={key:next((headers[a] for a in choices if a in headers),None) for key,choices in aliases.items()}
    for required in ("wavelength_um","flux_ujy","flux_err_ujy","mjd"):
        if columns[required] is None:raise ValueError(f"Missing column: {required} (wavelength in μm, flux/error in μJy, time in MJD days).")
    source=SkyCoord(float(ra),float(dec),unit="deg")
    rows=[]
    for index,raw in enumerate(table):
        if index>=maximum_rows:raise ValueError("Too many CSV rows.")
        value={key:_number(raw.get(column)) if column else None for key,column in columns.items() if key!="detector"}
        if any(value[key] is None for key in ("wavelength_um","flux_ujy","flux_err_ujy","mjd")):
            raise ValueError(f"Row {index+2}: required measurement values must be finite numbers.")
        if value["wavelength_um"]<=0 or value["flux_err_ujy"]<=0:
            raise ValueError(f"Row {index+2}: wavelength and flux uncertainty must be positive.")
        if not 30000<value["mjd"]<100000:raise ValueError(f"Row {index+2}: time must be an MJD in days, not a calendar year or Unix timestamp.")
        if (value["ra"] is None)!=(value["dec"] is None):raise ValueError("Supply both RA and Dec, or neither.")
        if value["ra"] is not None:
            if not 0<=value["ra"]<360 or not -90<=value["dec"]<=90:raise ValueError(f"Row {index+2}: RA/Dec are outside decimal-degree bounds.")
            position=SkyCoord(value["ra"],value["dec"],unit="deg")
            if source.separation(position)>3*u.arcsec:raise ValueError(f"Row {index+2}: exported source coordinates do not match the selected source within 3arcsec.")
        flags=0
        if "flags" in headers and str(raw.get(headers["flags"],"")).strip():
            try:flags=int(str(raw[headers["flags"]]).strip(),0)
            except ValueError:raise ValueError(f"Row {index+2}: flags must be an integer bitmask.")
        if flags<0:raise ValueError("Negative quality flags are not supported.")
        clean=(flags & ~((1<<12)|(1<<21)))==0
        detector=raw.get(columns["detector"],"Unknown") if columns["detector"] else "Unknown"
        if str(detector).isdigit():detector=f"SPHEREx-D{detector}"
        snr=value["flux_ujy"]/value["flux_err_ujy"]
        rows.append(dict(value,date=Time(value["mjd"],format="mjd").isot,detector=str(detector),
                    obs_id=raw.get("lvf_id",raw.get("obs_id",f"import-{index+1}")),collection=raw.get("data_collection","Imported calibrated table"),
                    source_ra_deg=None,source_dec_deg=None,source_url=raw.get("source_url",""),
                    provenance=str(provenance).strip(),method="Imported calibrated spectrophotometry; not remeasured by this app",
                    snr=snr,SNR=snr,detected=clean and snr>=3,usable_flux=clean,
                    upper_limit_ujy=max(0.,value["flux_ujy"])+3*value["flux_err_ujy"] if snr<3 else None,
                    usable_for_astrometry=False,astrometric_error_calibrated=False,centroid_valid=False,
                    status="imported_calibrated" if clean else "rejected_imported_flags",flags=flags,
                    warnings=[] if clean else ["Non-informational or unknown quality bits are set in the imported measurement."],
                    quality_checked=True,background_contamination_risk=False))
    if not rows:raise ValueError("The CSV has no measurements.")
    return rows
